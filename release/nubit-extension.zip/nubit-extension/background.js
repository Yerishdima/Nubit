var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/@anthropic-ai/sdk/internal/errors.mjs
function isAbortError(err) {
  return typeof err === "object" && err !== null && // Spec-compliant fetch implementations
  ("name" in err && err.name === "AbortError" || // Expo fetch
  "message" in err && String(err.message).includes("FetchRequestCanceledException"));
}
var castToError;
var init_errors = __esm({
  "node_modules/@anthropic-ai/sdk/internal/errors.mjs"() {
    castToError = (err) => {
      if (err instanceof Error)
        return err;
      if (typeof err === "object" && err !== null) {
        try {
          const tag = Object.prototype.toString.call(err);
          if (tag === "[object Error]" || tag === "[object DOMException]") {
            const error = new Error(err.message, err.cause ? { cause: err.cause } : {});
            if (err.stack)
              error.stack = err.stack;
            if (err.cause && !error.cause)
              error.cause = err.cause;
            if (err.name)
              error.name = err.name;
            return error;
          }
        } catch {
        }
        try {
          return new Error(JSON.stringify(err));
        } catch {
        }
      }
      return new Error(err);
    };
  }
});

// node_modules/@anthropic-ai/sdk/core/error.mjs
var AnthropicError, APIError, APIUserAbortError, APIConnectionError, APIConnectionTimeoutError, RetryableError, BadRequestError, AuthenticationError, PermissionDeniedError, NotFoundError, ConflictError, UnprocessableEntityError, RateLimitError, InternalServerError;
var init_error = __esm({
  "node_modules/@anthropic-ai/sdk/core/error.mjs"() {
    init_errors();
    AnthropicError = /* @__PURE__ */ (() => {
      class AnthropicError2 extends Error {
      }
      return AnthropicError2;
    })();
    APIError = class _APIError extends AnthropicError {
      constructor(status, error, message, headers, type) {
        super(`${_APIError.makeMessage(status, error, message)}`);
        this.status = status;
        this.headers = headers;
        this.requestID = headers?.get("request-id");
        this.workspaceID = headers?.get("anthropic-workspace-id");
        this.error = error;
        this.type = type ?? null;
      }
      static makeMessage(status, error, message) {
        const msg = error?.message ? typeof error.message === "string" ? error.message : JSON.stringify(error.message) : error ? JSON.stringify(error) : message;
        if (status && msg) {
          return `${status} ${msg}`;
        }
        if (status) {
          return `${status} status code (no body)`;
        }
        if (msg) {
          return msg;
        }
        return "(no status code or body)";
      }
      static generate(status, errorResponse, message, headers) {
        if (!status || !headers) {
          return new APIConnectionError({ message, cause: castToError(errorResponse) });
        }
        const error = errorResponse;
        const type = error?.["error"]?.["type"];
        if (status === 400) {
          return new BadRequestError(status, error, message, headers, type);
        }
        if (status === 401) {
          return new AuthenticationError(status, error, message, headers, type);
        }
        if (status === 403) {
          return new PermissionDeniedError(status, error, message, headers, type);
        }
        if (status === 404) {
          return new NotFoundError(status, error, message, headers, type);
        }
        if (status === 409) {
          return new ConflictError(status, error, message, headers, type);
        }
        if (status === 422) {
          return new UnprocessableEntityError(status, error, message, headers, type);
        }
        if (status === 429) {
          return new RateLimitError(status, error, message, headers, type);
        }
        if (status >= 500) {
          return new InternalServerError(status, error, message, headers, type);
        }
        return new _APIError(status, error, message, headers, type);
      }
    };
    APIUserAbortError = class extends APIError {
      constructor({ message } = {}) {
        super(void 0, void 0, message || "Request was aborted.", void 0);
      }
    };
    APIConnectionError = class extends APIError {
      constructor({ message, cause }) {
        super(void 0, void 0, message || "Connection error.", void 0);
        if (cause)
          this.cause = cause;
      }
    };
    APIConnectionTimeoutError = class extends APIConnectionError {
      constructor({ message } = {}) {
        super({ message: message ?? "Request timed out." });
      }
    };
    RetryableError = class extends AnthropicError {
      constructor(message, { cause } = {}) {
        super(message ?? "Retryable error.");
        if (cause !== void 0)
          this.cause = cause;
      }
    };
    BadRequestError = class extends APIError {
    };
    AuthenticationError = class extends APIError {
    };
    PermissionDeniedError = class extends APIError {
    };
    NotFoundError = class extends APIError {
    };
    ConflictError = class extends APIError {
    };
    UnprocessableEntityError = class extends APIError {
    };
    RateLimitError = class extends APIError {
    };
    InternalServerError = class extends APIError {
    };
  }
});

// node_modules/@anthropic-ai/sdk/internal/node.browser.mjs
var node_browser_exports = {};
__export(node_browser_exports, {
  child_process: () => child_process,
  crypto: () => crypto,
  fs: () => fs,
  os: () => os,
  path: () => path,
  stream: () => stream,
  util: () => util
});
function unavailable(module) {
  return new Proxy({}, {
    get(_target, property) {
      if (typeof property === "symbol")
        return void 0;
      throw new AnthropicError(`\`${module}.${property}\` is not available in this environment; it needs a Node.js-compatible runtime`);
    }
  });
}
var child_process, crypto, fs, os, path, stream, util;
var init_node_browser = __esm({
  "node_modules/@anthropic-ai/sdk/internal/node.browser.mjs"() {
    init_error();
    child_process = /* @__PURE__ */ unavailable("child_process");
    crypto = /* @__PURE__ */ unavailable("crypto");
    fs = /* @__PURE__ */ unavailable("fs");
    os = /* @__PURE__ */ unavailable("os");
    path = /* @__PURE__ */ unavailable("path");
    stream = /* @__PURE__ */ unavailable("stream");
    util = /* @__PURE__ */ unavailable("util");
  }
});

// node_modules/@stablelib/base64/lib/base64.js
var require_base64 = __commonJS({
  "node_modules/@stablelib/base64/lib/base64.js"(exports) {
    "use strict";
    var __extends = exports && exports.__extends || /* @__PURE__ */ (function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
          d2.__proto__ = b2;
        } || function(d2, b2) {
          for (var p in b2) if (b2.hasOwnProperty(p)) d2[p] = b2[p];
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    })();
    Object.defineProperty(exports, "__esModule", { value: true });
    var INVALID_BYTE = 256;
    var Coder = (
      /** @class */
      (function() {
        function Coder2(_paddingCharacter) {
          if (_paddingCharacter === void 0) {
            _paddingCharacter = "=";
          }
          this._paddingCharacter = _paddingCharacter;
        }
        Coder2.prototype.encodedLength = function(length) {
          if (!this._paddingCharacter) {
            return (length * 8 + 5) / 6 | 0;
          }
          return (length + 2) / 3 * 4 | 0;
        };
        Coder2.prototype.encode = function(data) {
          var out = "";
          var i = 0;
          for (; i < data.length - 2; i += 3) {
            var c = data[i] << 16 | data[i + 1] << 8 | data[i + 2];
            out += this._encodeByte(c >>> 3 * 6 & 63);
            out += this._encodeByte(c >>> 2 * 6 & 63);
            out += this._encodeByte(c >>> 1 * 6 & 63);
            out += this._encodeByte(c >>> 0 * 6 & 63);
          }
          var left = data.length - i;
          if (left > 0) {
            var c = data[i] << 16 | (left === 2 ? data[i + 1] << 8 : 0);
            out += this._encodeByte(c >>> 3 * 6 & 63);
            out += this._encodeByte(c >>> 2 * 6 & 63);
            if (left === 2) {
              out += this._encodeByte(c >>> 1 * 6 & 63);
            } else {
              out += this._paddingCharacter || "";
            }
            out += this._paddingCharacter || "";
          }
          return out;
        };
        Coder2.prototype.maxDecodedLength = function(length) {
          if (!this._paddingCharacter) {
            return (length * 6 + 7) / 8 | 0;
          }
          return length / 4 * 3 | 0;
        };
        Coder2.prototype.decodedLength = function(s) {
          return this.maxDecodedLength(s.length - this._getPaddingLength(s));
        };
        Coder2.prototype.decode = function(s) {
          if (s.length === 0) {
            return new Uint8Array(0);
          }
          var paddingLength = this._getPaddingLength(s);
          var length = s.length - paddingLength;
          var out = new Uint8Array(this.maxDecodedLength(length));
          var op = 0;
          var i = 0;
          var haveBad = 0;
          var v0 = 0, v1 = 0, v2 = 0, v3 = 0;
          for (; i < length - 4; i += 4) {
            v0 = this._decodeChar(s.charCodeAt(i + 0));
            v1 = this._decodeChar(s.charCodeAt(i + 1));
            v2 = this._decodeChar(s.charCodeAt(i + 2));
            v3 = this._decodeChar(s.charCodeAt(i + 3));
            out[op++] = v0 << 2 | v1 >>> 4;
            out[op++] = v1 << 4 | v2 >>> 2;
            out[op++] = v2 << 6 | v3;
            haveBad |= v0 & INVALID_BYTE;
            haveBad |= v1 & INVALID_BYTE;
            haveBad |= v2 & INVALID_BYTE;
            haveBad |= v3 & INVALID_BYTE;
          }
          if (i < length - 1) {
            v0 = this._decodeChar(s.charCodeAt(i));
            v1 = this._decodeChar(s.charCodeAt(i + 1));
            out[op++] = v0 << 2 | v1 >>> 4;
            haveBad |= v0 & INVALID_BYTE;
            haveBad |= v1 & INVALID_BYTE;
          }
          if (i < length - 2) {
            v2 = this._decodeChar(s.charCodeAt(i + 2));
            out[op++] = v1 << 4 | v2 >>> 2;
            haveBad |= v2 & INVALID_BYTE;
          }
          if (i < length - 3) {
            v3 = this._decodeChar(s.charCodeAt(i + 3));
            out[op++] = v2 << 6 | v3;
            haveBad |= v3 & INVALID_BYTE;
          }
          if (haveBad !== 0) {
            throw new Error("Base64Coder: incorrect characters for decoding");
          }
          return out;
        };
        Coder2.prototype._encodeByte = function(b) {
          var result = b;
          result += 65;
          result += 25 - b >>> 8 & 0 - 65 - 26 + 97;
          result += 51 - b >>> 8 & 26 - 97 - 52 + 48;
          result += 61 - b >>> 8 & 52 - 48 - 62 + 43;
          result += 62 - b >>> 8 & 62 - 43 - 63 + 47;
          return String.fromCharCode(result);
        };
        Coder2.prototype._decodeChar = function(c) {
          var result = INVALID_BYTE;
          result += (42 - c & c - 44) >>> 8 & -INVALID_BYTE + c - 43 + 62;
          result += (46 - c & c - 48) >>> 8 & -INVALID_BYTE + c - 47 + 63;
          result += (47 - c & c - 58) >>> 8 & -INVALID_BYTE + c - 48 + 52;
          result += (64 - c & c - 91) >>> 8 & -INVALID_BYTE + c - 65 + 0;
          result += (96 - c & c - 123) >>> 8 & -INVALID_BYTE + c - 97 + 26;
          return result;
        };
        Coder2.prototype._getPaddingLength = function(s) {
          var paddingLength = 0;
          if (this._paddingCharacter) {
            for (var i = s.length - 1; i >= 0; i--) {
              if (s[i] !== this._paddingCharacter) {
                break;
              }
              paddingLength++;
            }
            if (s.length < 4 || paddingLength > 2) {
              throw new Error("Base64Coder: incorrect padding");
            }
          }
          return paddingLength;
        };
        return Coder2;
      })()
    );
    exports.Coder = Coder;
    var stdCoder = new Coder();
    function encode2(data) {
      return stdCoder.encode(data);
    }
    exports.encode = encode2;
    function decode(s) {
      return stdCoder.decode(s);
    }
    exports.decode = decode;
    var URLSafeCoder = (
      /** @class */
      (function(_super) {
        __extends(URLSafeCoder2, _super);
        function URLSafeCoder2() {
          return _super !== null && _super.apply(this, arguments) || this;
        }
        URLSafeCoder2.prototype._encodeByte = function(b) {
          var result = b;
          result += 65;
          result += 25 - b >>> 8 & 0 - 65 - 26 + 97;
          result += 51 - b >>> 8 & 26 - 97 - 52 + 48;
          result += 61 - b >>> 8 & 52 - 48 - 62 + 45;
          result += 62 - b >>> 8 & 62 - 45 - 63 + 95;
          return String.fromCharCode(result);
        };
        URLSafeCoder2.prototype._decodeChar = function(c) {
          var result = INVALID_BYTE;
          result += (44 - c & c - 46) >>> 8 & -INVALID_BYTE + c - 45 + 62;
          result += (94 - c & c - 96) >>> 8 & -INVALID_BYTE + c - 95 + 63;
          result += (47 - c & c - 58) >>> 8 & -INVALID_BYTE + c - 48 + 52;
          result += (64 - c & c - 91) >>> 8 & -INVALID_BYTE + c - 65 + 0;
          result += (96 - c & c - 123) >>> 8 & -INVALID_BYTE + c - 97 + 26;
          return result;
        };
        return URLSafeCoder2;
      })(Coder)
    );
    exports.URLSafeCoder = URLSafeCoder;
    var urlSafeCoder = new URLSafeCoder();
    function encodeURLSafe(data) {
      return urlSafeCoder.encode(data);
    }
    exports.encodeURLSafe = encodeURLSafe;
    function decodeURLSafe(s) {
      return urlSafeCoder.decode(s);
    }
    exports.decodeURLSafe = decodeURLSafe;
    exports.encodedLength = function(length) {
      return stdCoder.encodedLength(length);
    };
    exports.maxDecodedLength = function(length) {
      return stdCoder.maxDecodedLength(length);
    };
    exports.decodedLength = function(s) {
      return stdCoder.decodedLength(s);
    };
  }
});

// node_modules/fast-sha256/sha256.js
var require_sha256 = __commonJS({
  "node_modules/fast-sha256/sha256.js"(exports, module) {
    (function(root, factory) {
      var exports2 = {};
      factory(exports2);
      var sha256 = exports2["default"];
      for (var k in exports2) {
        sha256[k] = exports2[k];
      }
      if (typeof module === "object" && typeof module.exports === "object") {
        module.exports = sha256;
      } else if (typeof define === "function" && define.amd) {
        define(function() {
          return sha256;
        });
      } else {
        root.sha256 = sha256;
      }
    })(exports, function(exports2) {
      "use strict";
      exports2.__esModule = true;
      exports2.digestLength = 32;
      exports2.blockSize = 64;
      var K = new Uint32Array([
        1116352408,
        1899447441,
        3049323471,
        3921009573,
        961987163,
        1508970993,
        2453635748,
        2870763221,
        3624381080,
        310598401,
        607225278,
        1426881987,
        1925078388,
        2162078206,
        2614888103,
        3248222580,
        3835390401,
        4022224774,
        264347078,
        604807628,
        770255983,
        1249150122,
        1555081692,
        1996064986,
        2554220882,
        2821834349,
        2952996808,
        3210313671,
        3336571891,
        3584528711,
        113926993,
        338241895,
        666307205,
        773529912,
        1294757372,
        1396182291,
        1695183700,
        1986661051,
        2177026350,
        2456956037,
        2730485921,
        2820302411,
        3259730800,
        3345764771,
        3516065817,
        3600352804,
        4094571909,
        275423344,
        430227734,
        506948616,
        659060556,
        883997877,
        958139571,
        1322822218,
        1537002063,
        1747873779,
        1955562222,
        2024104815,
        2227730452,
        2361852424,
        2428436474,
        2756734187,
        3204031479,
        3329325298
      ]);
      function hashBlocks(w, v, p, pos, len) {
        var a, b, c, d, e, f, g, h, u, i, j, t1, t2;
        while (len >= 64) {
          a = v[0];
          b = v[1];
          c = v[2];
          d = v[3];
          e = v[4];
          f = v[5];
          g = v[6];
          h = v[7];
          for (i = 0; i < 16; i++) {
            j = pos + i * 4;
            w[i] = (p[j] & 255) << 24 | (p[j + 1] & 255) << 16 | (p[j + 2] & 255) << 8 | p[j + 3] & 255;
          }
          for (i = 16; i < 64; i++) {
            u = w[i - 2];
            t1 = (u >>> 17 | u << 32 - 17) ^ (u >>> 19 | u << 32 - 19) ^ u >>> 10;
            u = w[i - 15];
            t2 = (u >>> 7 | u << 32 - 7) ^ (u >>> 18 | u << 32 - 18) ^ u >>> 3;
            w[i] = (t1 + w[i - 7] | 0) + (t2 + w[i - 16] | 0);
          }
          for (i = 0; i < 64; i++) {
            t1 = (((e >>> 6 | e << 32 - 6) ^ (e >>> 11 | e << 32 - 11) ^ (e >>> 25 | e << 32 - 25)) + (e & f ^ ~e & g) | 0) + (h + (K[i] + w[i] | 0) | 0) | 0;
            t2 = ((a >>> 2 | a << 32 - 2) ^ (a >>> 13 | a << 32 - 13) ^ (a >>> 22 | a << 32 - 22)) + (a & b ^ a & c ^ b & c) | 0;
            h = g;
            g = f;
            f = e;
            e = d + t1 | 0;
            d = c;
            c = b;
            b = a;
            a = t1 + t2 | 0;
          }
          v[0] += a;
          v[1] += b;
          v[2] += c;
          v[3] += d;
          v[4] += e;
          v[5] += f;
          v[6] += g;
          v[7] += h;
          pos += 64;
          len -= 64;
        }
        return pos;
      }
      var Hash = (
        /** @class */
        (function() {
          function Hash2() {
            this.digestLength = exports2.digestLength;
            this.blockSize = exports2.blockSize;
            this.state = new Int32Array(8);
            this.temp = new Int32Array(64);
            this.buffer = new Uint8Array(128);
            this.bufferLength = 0;
            this.bytesHashed = 0;
            this.finished = false;
            this.reset();
          }
          Hash2.prototype.reset = function() {
            this.state[0] = 1779033703;
            this.state[1] = 3144134277;
            this.state[2] = 1013904242;
            this.state[3] = 2773480762;
            this.state[4] = 1359893119;
            this.state[5] = 2600822924;
            this.state[6] = 528734635;
            this.state[7] = 1541459225;
            this.bufferLength = 0;
            this.bytesHashed = 0;
            this.finished = false;
            return this;
          };
          Hash2.prototype.clean = function() {
            for (var i = 0; i < this.buffer.length; i++) {
              this.buffer[i] = 0;
            }
            for (var i = 0; i < this.temp.length; i++) {
              this.temp[i] = 0;
            }
            this.reset();
          };
          Hash2.prototype.update = function(data, dataLength) {
            if (dataLength === void 0) {
              dataLength = data.length;
            }
            if (this.finished) {
              throw new Error("SHA256: can't update because hash was finished.");
            }
            var dataPos = 0;
            this.bytesHashed += dataLength;
            if (this.bufferLength > 0) {
              while (this.bufferLength < 64 && dataLength > 0) {
                this.buffer[this.bufferLength++] = data[dataPos++];
                dataLength--;
              }
              if (this.bufferLength === 64) {
                hashBlocks(this.temp, this.state, this.buffer, 0, 64);
                this.bufferLength = 0;
              }
            }
            if (dataLength >= 64) {
              dataPos = hashBlocks(this.temp, this.state, data, dataPos, dataLength);
              dataLength %= 64;
            }
            while (dataLength > 0) {
              this.buffer[this.bufferLength++] = data[dataPos++];
              dataLength--;
            }
            return this;
          };
          Hash2.prototype.finish = function(out) {
            if (!this.finished) {
              var bytesHashed = this.bytesHashed;
              var left = this.bufferLength;
              var bitLenHi = bytesHashed / 536870912 | 0;
              var bitLenLo = bytesHashed << 3;
              var padLength = bytesHashed % 64 < 56 ? 64 : 128;
              this.buffer[left] = 128;
              for (var i = left + 1; i < padLength - 8; i++) {
                this.buffer[i] = 0;
              }
              this.buffer[padLength - 8] = bitLenHi >>> 24 & 255;
              this.buffer[padLength - 7] = bitLenHi >>> 16 & 255;
              this.buffer[padLength - 6] = bitLenHi >>> 8 & 255;
              this.buffer[padLength - 5] = bitLenHi >>> 0 & 255;
              this.buffer[padLength - 4] = bitLenLo >>> 24 & 255;
              this.buffer[padLength - 3] = bitLenLo >>> 16 & 255;
              this.buffer[padLength - 2] = bitLenLo >>> 8 & 255;
              this.buffer[padLength - 1] = bitLenLo >>> 0 & 255;
              hashBlocks(this.temp, this.state, this.buffer, 0, padLength);
              this.finished = true;
            }
            for (var i = 0; i < 8; i++) {
              out[i * 4 + 0] = this.state[i] >>> 24 & 255;
              out[i * 4 + 1] = this.state[i] >>> 16 & 255;
              out[i * 4 + 2] = this.state[i] >>> 8 & 255;
              out[i * 4 + 3] = this.state[i] >>> 0 & 255;
            }
            return this;
          };
          Hash2.prototype.digest = function() {
            var out = new Uint8Array(this.digestLength);
            this.finish(out);
            return out;
          };
          Hash2.prototype._saveState = function(out) {
            for (var i = 0; i < this.state.length; i++) {
              out[i] = this.state[i];
            }
          };
          Hash2.prototype._restoreState = function(from, bytesHashed) {
            for (var i = 0; i < this.state.length; i++) {
              this.state[i] = from[i];
            }
            this.bytesHashed = bytesHashed;
            this.finished = false;
            this.bufferLength = 0;
          };
          return Hash2;
        })()
      );
      exports2.Hash = Hash;
      var HMAC = (
        /** @class */
        (function() {
          function HMAC2(key) {
            this.inner = new Hash();
            this.outer = new Hash();
            this.blockSize = this.inner.blockSize;
            this.digestLength = this.inner.digestLength;
            var pad = new Uint8Array(this.blockSize);
            if (key.length > this.blockSize) {
              new Hash().update(key).finish(pad).clean();
            } else {
              for (var i = 0; i < key.length; i++) {
                pad[i] = key[i];
              }
            }
            for (var i = 0; i < pad.length; i++) {
              pad[i] ^= 54;
            }
            this.inner.update(pad);
            for (var i = 0; i < pad.length; i++) {
              pad[i] ^= 54 ^ 92;
            }
            this.outer.update(pad);
            this.istate = new Uint32Array(8);
            this.ostate = new Uint32Array(8);
            this.inner._saveState(this.istate);
            this.outer._saveState(this.ostate);
            for (var i = 0; i < pad.length; i++) {
              pad[i] = 0;
            }
          }
          HMAC2.prototype.reset = function() {
            this.inner._restoreState(this.istate, this.inner.blockSize);
            this.outer._restoreState(this.ostate, this.outer.blockSize);
            return this;
          };
          HMAC2.prototype.clean = function() {
            for (var i = 0; i < this.istate.length; i++) {
              this.ostate[i] = this.istate[i] = 0;
            }
            this.inner.clean();
            this.outer.clean();
          };
          HMAC2.prototype.update = function(data) {
            this.inner.update(data);
            return this;
          };
          HMAC2.prototype.finish = function(out) {
            if (this.outer.finished) {
              this.outer.finish(out);
            } else {
              this.inner.finish(out);
              this.outer.update(out, this.digestLength).finish(out);
            }
            return this;
          };
          HMAC2.prototype.digest = function() {
            var out = new Uint8Array(this.digestLength);
            this.finish(out);
            return out;
          };
          return HMAC2;
        })()
      );
      exports2.HMAC = HMAC;
      function hash(data) {
        var h = new Hash().update(data);
        var digest = h.digest();
        h.clean();
        return digest;
      }
      exports2.hash = hash;
      exports2["default"] = hash;
      function hmac(key, data) {
        var h = new HMAC(key).update(data);
        var digest = h.digest();
        h.clean();
        return digest;
      }
      exports2.hmac = hmac;
      function fillBuffer(buffer, hmac2, info, counter) {
        var num = counter[0];
        if (num === 0) {
          throw new Error("hkdf: cannot expand more");
        }
        hmac2.reset();
        if (num > 1) {
          hmac2.update(buffer);
        }
        if (info) {
          hmac2.update(info);
        }
        hmac2.update(counter);
        hmac2.finish(buffer);
        counter[0]++;
      }
      var hkdfSalt = new Uint8Array(exports2.digestLength);
      function hkdf(key, salt, info, length) {
        if (salt === void 0) {
          salt = hkdfSalt;
        }
        if (length === void 0) {
          length = 32;
        }
        var counter = new Uint8Array([1]);
        var okm = hmac(salt, key);
        var hmac_ = new HMAC(okm);
        var buffer = new Uint8Array(hmac_.digestLength);
        var bufpos = buffer.length;
        var out = new Uint8Array(length);
        for (var i = 0; i < length; i++) {
          if (bufpos === buffer.length) {
            fillBuffer(buffer, hmac_, info, counter);
            bufpos = 0;
          }
          out[i] = buffer[bufpos++];
        }
        hmac_.clean();
        buffer.fill(0);
        counter.fill(0);
        return out;
      }
      exports2.hkdf = hkdf;
      function pbkdf2(password, salt, iterations, dkLen) {
        var prf = new HMAC(password);
        var len = prf.digestLength;
        var ctr = new Uint8Array(4);
        var t = new Uint8Array(len);
        var u = new Uint8Array(len);
        var dk = new Uint8Array(dkLen);
        for (var i = 0; i * len < dkLen; i++) {
          var c = i + 1;
          ctr[0] = c >>> 24 & 255;
          ctr[1] = c >>> 16 & 255;
          ctr[2] = c >>> 8 & 255;
          ctr[3] = c >>> 0 & 255;
          prf.reset();
          prf.update(salt);
          prf.update(ctr);
          prf.finish(u);
          for (var j = 0; j < len; j++) {
            t[j] = u[j];
          }
          for (var j = 2; j <= iterations; j++) {
            prf.reset();
            prf.update(u).finish(u);
            for (var k = 0; k < len; k++) {
              t[k] ^= u[k];
            }
          }
          for (var j = 0; j < len && i * len + j < dkLen; j++) {
            dk[i * len + j] = t[j];
          }
        }
        for (var i = 0; i < len; i++) {
          t[i] = u[i] = 0;
        }
        for (var i = 0; i < 4; i++) {
          ctr[i] = 0;
        }
        prf.clean();
        return dk;
      }
      exports2.pbkdf2 = pbkdf2;
    });
  }
});

// node_modules/standardwebhooks/dist/timing_safe_equal.js
var require_timing_safe_equal = __commonJS({
  "node_modules/standardwebhooks/dist/timing_safe_equal.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.timingSafeEqual = timingSafeEqual;
    function assert(expr, msg = "") {
      if (!expr) {
        throw new Error(msg);
      }
    }
    function timingSafeEqual(a, b) {
      if (a.byteLength !== b.byteLength) {
        return false;
      }
      if (!(a instanceof DataView)) {
        a = new DataView(ArrayBuffer.isView(a) ? a.buffer : a);
      }
      if (!(b instanceof DataView)) {
        b = new DataView(ArrayBuffer.isView(b) ? b.buffer : b);
      }
      assert(a instanceof DataView);
      assert(b instanceof DataView);
      const length = a.byteLength;
      let out = 0;
      let i = -1;
      while (++i < length) {
        out |= a.getUint8(i) ^ b.getUint8(i);
      }
      return out === 0;
    }
  }
});

// node_modules/standardwebhooks/dist/index.js
var require_dist = __commonJS({
  "node_modules/standardwebhooks/dist/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Webhook = exports.WebhookVerificationError = void 0;
    var base64 = require_base64();
    var sha256 = require_sha256();
    var timing_safe_equal_1 = require_timing_safe_equal();
    var WEBHOOK_TOLERANCE_IN_SECONDS = 5 * 60;
    var ExtendableError = class _ExtendableError extends Error {
      constructor(message) {
        super(message);
        Object.setPrototypeOf(this, _ExtendableError.prototype);
        this.name = "ExtendableError";
        this.stack = new Error(message).stack;
      }
    };
    var WebhookVerificationError = class _WebhookVerificationError extends ExtendableError {
      constructor(message) {
        super(message);
        Object.setPrototypeOf(this, _WebhookVerificationError.prototype);
        this.name = "WebhookVerificationError";
      }
    };
    exports.WebhookVerificationError = WebhookVerificationError;
    var Webhook2 = class _Webhook {
      constructor(secret, options) {
        if ((options === null || options === void 0 ? void 0 : options.format) === "raw") {
          if (secret instanceof Uint8Array) {
            this.key = secret;
          } else {
            this.key = Uint8Array.from(secret, (c) => c.charCodeAt(0));
          }
        } else {
          if (typeof secret !== "string") {
            throw new Error("Expected secret to be of type string");
          }
          if (secret.startsWith(_Webhook.prefix)) {
            secret = secret.substring(_Webhook.prefix.length);
          }
          this.key = base64.decode(secret);
        }
        if (this.key.length === 0) {
          throw new Error("Secret can't be empty.");
        }
      }
      verify(payload, headers, options) {
        var _a2;
        const jsonParse = (_a2 = options === null || options === void 0 ? void 0 : options.jsonParse) !== null && _a2 !== void 0 ? _a2 : true;
        const normalizedHeaders = {};
        for (const key of Object.keys(headers)) {
          normalizedHeaders[key.toLowerCase()] = headers[key];
        }
        const msgId = normalizedHeaders["webhook-id"];
        const msgSignature = normalizedHeaders["webhook-signature"];
        const msgTimestamp = normalizedHeaders["webhook-timestamp"];
        if (!msgSignature || !msgId || !msgTimestamp) {
          throw new WebhookVerificationError("Missing required headers");
        }
        const timestamp = this.verifyTimestamp(msgTimestamp);
        const computedSignature = this.sign(msgId, timestamp, payload);
        const expectedSignature = computedSignature.split(",")[1];
        const passedSignatures = msgSignature.split(" ");
        const encoder = new globalThis.TextEncoder();
        for (const versionedSignature of passedSignatures) {
          const [version, signature] = versionedSignature.split(",");
          if (version !== "v1") {
            continue;
          }
          if ((0, timing_safe_equal_1.timingSafeEqual)(encoder.encode(signature), encoder.encode(expectedSignature))) {
            const payloadString = payload.toString();
            if (payloadString === "") {
              return void 0;
            }
            if (jsonParse) {
              return JSON.parse(payloadString);
            } else {
              return void 0;
            }
          }
        }
        throw new WebhookVerificationError("No matching signature found");
      }
      sign(msgId, timestamp, payload) {
        if (typeof payload === "string") {
        } else if (payload.constructor.name === "Buffer") {
          payload = payload.toString();
        } else {
          throw new Error("Expected payload to be of type string or Buffer.");
        }
        const encoder = new TextEncoder();
        const timestampNumber = Math.floor(timestamp.getTime() / 1e3);
        const toSign = encoder.encode(`${msgId}.${timestampNumber}.${payload}`);
        const expectedSignature = base64.encode(sha256.hmac(this.key, toSign));
        return `v1,${expectedSignature}`;
      }
      verifyTimestamp(timestampHeader) {
        const now = Math.floor(Date.now() / 1e3);
        const timestamp = parseInt(timestampHeader, 10);
        if (Number.isNaN(timestamp)) {
          throw new WebhookVerificationError("Invalid Signature Headers");
        }
        if (now - timestamp > WEBHOOK_TOLERANCE_IN_SECONDS) {
          throw new WebhookVerificationError("Message timestamp too old");
        }
        if (timestamp > now + WEBHOOK_TOLERANCE_IN_SECONDS) {
          throw new WebhookVerificationError("Message timestamp too new");
        }
        return new Date(timestamp * 1e3);
      }
    };
    exports.Webhook = Webhook2;
    Webhook2.prefix = "whsec_";
  }
});

// node_modules/@anthropic-ai/sdk/tools/agent-toolset/sync-interval.mjs
function checkMemorySyncInterval(ms, option) {
  if (!(ms >= MIN_MEMORY_SYNC_INTERVAL_MS)) {
    throw new AnthropicError(`${option} must be at least ${MIN_MEMORY_SYNC_INTERVAL_MS}ms (got ${ms}); to run without memory sync, pass \`memorySyncIntervalMs: null\` to the worker instead`);
  }
}
var DEFAULT_MEMORY_SYNC_INTERVAL_MS, MIN_MEMORY_SYNC_INTERVAL_MS;
var init_sync_interval = __esm({
  "node_modules/@anthropic-ai/sdk/tools/agent-toolset/sync-interval.mjs"() {
    init_error();
    DEFAULT_MEMORY_SYNC_INTERVAL_MS = 15e3;
    MIN_MEMORY_SYNC_INTERVAL_MS = 5e3;
  }
});

// node_modules/@anthropic-ai/sdk/tools/agent-toolset/node.browser.mjs
var node_browser_exports2 = {};
__export(node_browser_exports2, {
  BashSession: () => BashSession,
  BashTimeoutError: () => BashTimeoutError,
  DEFAULT_MEMORY_SYNC_INTERVAL_MS: () => DEFAULT_MEMORY_SYNC_INTERVAL_MS,
  MARKER_PATH: () => MARKER_PATH,
  MEMORY_FLUSH_TIMEOUT_MS: () => MEMORY_FLUSH_TIMEOUT_MS,
  MIN_MEMORY_SYNC_INTERVAL_MS: () => MIN_MEMORY_SYNC_INTERVAL_MS,
  SessionMemoryError: () => SessionMemoryError,
  SessionMemoryStores: () => SessionMemoryStores,
  betaAgentToolset20260401: () => betaAgentToolset20260401,
  betaBashTool: () => betaBashTool,
  betaEditTool: () => betaEditTool,
  betaGlobTool: () => betaGlobTool,
  betaGrepTool: () => betaGrepTool,
  betaReadTool: () => betaReadTool,
  betaWriteTool: () => betaWriteTool,
  extractSkillArchive: () => extractSkillArchive,
  resolvePath: () => resolvePath,
  setupSkills: () => setupSkills
});
function nodeOnly(name) {
  throw new AnthropicError(`${name} requires Node.js or a Node-compatible runtime`);
}
function setupSkills(_ctx) {
  return nodeOnly("setupSkills");
}
function extractSkillArchive(_resp, _dest) {
  return nodeOnly("extractSkillArchive");
}
function betaAgentToolset20260401(_ctx) {
  return nodeOnly("betaAgentToolset20260401");
}
function resolvePath(_ctx, _p) {
  return nodeOnly("resolvePath");
}
function betaBashTool(_ctx) {
  return nodeOnly("betaBashTool");
}
function betaReadTool(_ctx) {
  return nodeOnly("betaReadTool");
}
function betaWriteTool(_ctx) {
  return nodeOnly("betaWriteTool");
}
function betaEditTool(_ctx) {
  return nodeOnly("betaEditTool");
}
function betaGlobTool(_ctx) {
  return nodeOnly("betaGlobTool");
}
function betaGrepTool(_ctx) {
  return nodeOnly("betaGrepTool");
}
var MEMORY_FLUSH_TIMEOUT_MS, MARKER_PATH, SessionMemoryError, SessionMemoryStores, BashTimeoutError, BashSession;
var init_node_browser2 = __esm({
  "node_modules/@anthropic-ai/sdk/tools/agent-toolset/node.browser.mjs"() {
    init_error();
    init_sync_interval();
    MEMORY_FLUSH_TIMEOUT_MS = 3e4;
    MARKER_PATH = ".anthropic-memory-store";
    SessionMemoryError = class extends AnthropicError {
      constructor(message, cause) {
        super(message);
        this.name = "SessionMemoryError";
        if (cause !== void 0)
          this.cause = cause;
      }
    };
    SessionMemoryStores = class {
      constructor(_client, _opts) {
        nodeOnly("SessionMemoryStores");
      }
      get roots() {
        return nodeOnly("SessionMemoryStores");
      }
      get readOnlyRoots() {
        return nodeOnly("SessionMemoryStores");
      }
      download(_session) {
        return nodeOnly("SessionMemoryStores");
      }
      finish() {
        return nodeOnly("SessionMemoryStores");
      }
      /** @internal */
      syncAll(_final) {
        return nodeOnly("SessionMemoryStores");
      }
      syncIfDue() {
        return nodeOnly("SessionMemoryStores");
      }
      flushWrites(_signal) {
        return nodeOnly("SessionMemoryStores");
      }
      dispose() {
        return nodeOnly("SessionMemoryStores");
      }
    };
    BashTimeoutError = class extends AnthropicError {
      constructor(timeoutMs) {
        super(`bash command timed out after ${timeoutMs}ms`);
        this.name = "BashTimeoutError";
        this.timeoutMs = timeoutMs;
      }
    };
    BashSession = class {
      constructor(_dir, _env) {
        nodeOnly("BashSession");
      }
      get closed() {
        return nodeOnly("BashSession");
      }
      exec(_command, _opts = {}) {
        return nodeOnly("BashSession");
      }
      close() {
        nodeOnly("BashSession");
      }
    };
  }
});

// src/shared/settings.ts
var DEFAULT_LOCAL_TOOLS = [
  {
    name: "yt-dlp",
    path: "",
    description: "Downloads video metadata and subtitles. Used for transcripts when the page has no caption tracks."
  },
  {
    name: "ffmpeg",
    path: "",
    description: "Audio/video processing (extract audio, cut clips, probe files)."
  }
];
var DEFAULT_SETTINGS = {
  language: "ru",
  provider: "anthropic",
  anthropicApiKey: "",
  anthropicModel: "claude-opus-5-5",
  openaiApiKey: "",
  openaiModel: "gpt-5",
  openaiBaseUrl: "https://api.openai.com/v1",
  geminiApiKey: "",
  geminiModel: "gemini-2.5-pro",
  ollamaBaseUrl: "http://localhost:11434/v1",
  ollamaModel: "llama3.1",
  customProviders: [],
  activeCustomProviderId: "",
  effort: "medium",
  youtubeApiKey: "",
  showOverlay: true,
  showBadges: true,
  computeOutliers: true,
  customApis: [],
  localTools: DEFAULT_LOCAL_TOOLS,
  nativeHostName: "com.nubit.host",
  tagTemplates: [],
  competitors: []
};
var KEY = "settings";
async function loadSettings() {
  const stored = await chrome.storage.local.get(KEY);
  const s = stored[KEY] ?? {};
  const merged = { ...DEFAULT_SETTINGS, ...s };
  const names = new Set(merged.localTools.map((t) => t.name));
  for (const t of DEFAULT_LOCAL_TOOLS) if (!names.has(t.name)) merged.localTools.push({ ...t });
  return merged;
}
async function saveSettings(settings) {
  await chrome.storage.local.set({ [KEY]: settings });
}
function activeCustomProvider(s) {
  return s.customProviders.find((p) => p.id === s.activeCustomProviderId) ?? s.customProviders[0];
}

// src/shared/metrics.ts
var SUFFIX = {
  k: 1e3,
  m: 1e6,
  b: 1e9,
  \u0442\u044B\u0441: 1e3,
  \u043C\u043B\u043D: 1e6,
  \u043C\u043B\u0440\u0434: 1e9,
  \u0442\u0438\u0441: 1e3
};
function parseCompactNumber(text) {
  if (!text) return void 0;
  const t = text.replace(/ | /g, " ").trim().toLowerCase();
  if (!t) return void 0;
  if (new RegExp("^(no|\u043D\u0435\u0442|\u043D\u0435\u043C\u0430\u0454)(?!\\p{L})", "u").test(t)) return 0;
  const m = t.match(/(\d[\d\s.,]*)\s*(k|m|b|тыс|млн|млрд|тис)?(?![a-zа-яіїє])/);
  if (!m) return void 0;
  const numStr = m[1].replace(/\s/g, "").replace(/[.,]$/, "");
  const suffix = m[2];
  let num;
  if (suffix) {
    num = parseFloat(numStr.replace(",", "."));
  } else {
    num = parseInt(numStr.replace(/[.,]/g, ""), 10);
  }
  if (!isFinite(num)) return void 0;
  return Math.round(num * (suffix ? SUFFIX[suffix] : 1));
}
var UNIT_HOURS = [
  [/sec|сек/, 1 / 3600],
  [/min|мин|хв/, 1 / 60],
  [/hour|годин|час/, 1],
  [/day|дн|день|дні/, 24],
  [/week|нед|тиж/, 168],
  [/month|мес|міс/, 730],
  [/year|год|лет|рік|рок/, 8760]
];
var COMPACT_HOURS = { s: 1 / 3600, m: 1 / 60, h: 1, d: 24, w: 168, mo: 730, y: 8760 };
function parseRelativeTimeHours(text) {
  if (!text) return void 0;
  const t = text.toLowerCase();
  const n = t.match(/(\d+)/);
  if (!n) return void 0;
  for (const [re, h] of UNIT_HOURS) if (re.test(t)) return parseInt(n[1], 10) * h;
  const c = t.match(/(\d+)\s*(mo|s|m|h|d|w|y)(?![a-z])/);
  if (c) return parseInt(c[1], 10) * COMPACT_HOURS[c[2]];
  return void 0;
}
function parseDuration(text) {
  if (!text) return void 0;
  const parts = text.trim().split(":").map((p) => parseInt(p, 10));
  if (parts.some((p) => !isFinite(p))) return void 0;
  return parts.reduce((acc, p) => acc * 60 + p, 0);
}
function parseIsoDuration(iso) {
  if (!iso) return void 0;
  const m = iso.match(/P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!m) return void 0;
  return +(m[1] || 0) * 86400 + +(m[2] || 0) * 3600 + +(m[3] || 0) * 60 + +(m[4] || 0);
}
function ageHoursFromIso(iso, now = Date.now()) {
  if (!iso) return void 0;
  const t = Date.parse(iso);
  if (!isFinite(t)) return void 0;
  return Math.max(0, (now - t) / 36e5);
}
function computeVph(views, ageHours) {
  if (views === void 0 || ageHours === void 0) return void 0;
  return views / Math.max(ageHours, 1);
}
function median(values) {
  const v = values.filter((x) => isFinite(x)).sort((a, b) => a - b);
  if (v.length === 0) return void 0;
  const mid = Math.floor(v.length / 2);
  return v.length % 2 ? v[mid] : (v[mid - 1] + v[mid]) / 2;
}
function computeOutlier(views, channelViews, excludeSelf) {
  if (views === void 0) return void 0;
  const others = excludeSelf === void 0 ? channelViews : channelViews.filter((v) => v !== excludeSelf);
  if (others.length < 3) return void 0;
  const med = median(others);
  if (!med) return void 0;
  return views / med;
}
function hasChapters(description) {
  if (!description) return false;
  const lines = description.split("\n").filter((l) => /^\s*\(?\d{1,2}:\d{2}(?::\d{2})?\)?\s*[-–—:]?\s*\S/.test(l));
  return lines.length >= 3 && lines.some((l) => /^\s*\(?0?0:00/.test(l));
}
var STOP = new Set(
  "the a an and or of to in on for with at by from is are was were be this that it \u043A\u0430\u043A \u0438 \u0432 \u043D\u0430 \u0441 \u043F\u043E \u0434\u043B\u044F \u043E\u0442 \u0434\u043E \u0438\u0437 \u043D\u0435 \u0447\u0442\u043E \u044D\u0442\u043E \u0438\u043B\u0438 \u0443 \u043E \u0430 \u043D\u043E \u0437\u0430 \u0436\u0435 \u043A \u0442\u044B \u0432\u044B \u043C\u044B \u044F".split(" ")
);
function words(text) {
  return text.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").split(/\s+/).filter((w) => w.length > 2 && !STOP.has(w));
}
function overlap(a, b) {
  if (a.length === 0) return 0;
  const hay = b.toLowerCase();
  const hit = a.filter((w) => hay.includes(w)).length;
  return hit / a.length;
}
var SEO_LABELS = {
  title_len: {
    ru: ["\u0414\u043B\u0438\u043D\u0430 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F 30\u201370 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432", "\u041A\u043E\u0440\u043E\u0442\u043A\u0438\u0435 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u0445\u0443\u0436\u0435 \u043E\u0431\u044A\u044F\u0441\u043D\u044F\u044E\u0442 \u0442\u0435\u043C\u0443, \u0434\u043B\u0438\u043D\u043D\u044B\u0435 \u043E\u0431\u0440\u0435\u0437\u0430\u044E\u0442\u0441\u044F \u0432 \u0432\u044B\u0434\u0430\u0447\u0435."],
    en: ["Title is 30\u201370 characters", "Short titles under-explain; long ones get cut off in results."]
  },
  title_caps: {
    ru: ["\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043D\u0435 \u043A\u0430\u043F\u0441\u043E\u043C", "\u0421\u043F\u043B\u043E\u0448\u043D\u044B\u0435 \u0437\u0430\u0433\u043B\u0430\u0432\u043D\u044B\u0435 \u0441\u043D\u0438\u0436\u0430\u044E\u0442 \u0434\u043E\u0432\u0435\u0440\u0438\u0435 \u0438 CTR."],
    en: ["Title is not ALL CAPS", "All-caps titles reduce trust and CTR."]
  },
  desc_len: {
    ru: ["\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u2265 250 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432", "\u041F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0434\u0430\u0451\u0442 YouTube \u0431\u043E\u043B\u044C\u0448\u0435 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0430 \u0434\u043B\u044F \u0440\u0430\u043D\u0436\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F."],
    en: ["Description \u2265 250 characters", "A fuller description gives YouTube more ranking context."]
  },
  desc_keywords: {
    ru: ["\u0421\u043B\u043E\u0432\u0430 \u0438\u0437 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u0435\u0441\u0442\u044C \u0432 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0438", "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u0441\u043B\u043E\u0432\u0430 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u0432 \u043F\u0435\u0440\u0432\u044B\u0445 \u0441\u0442\u0440\u043E\u043A\u0430\u0445 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u044F."],
    en: ["Title keywords appear in the description", "Repeat the title keywords in the first lines of the description."]
  },
  tags_count: {
    ru: ["5\u201330 \u0442\u0435\u0433\u043E\u0432", "\u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0442\u0435\u0433\u0438: \u0442\u043E\u0447\u043D\u044B\u0435, \u0448\u0438\u0440\u043E\u043A\u0438\u0435 \u0438 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B \u043D\u0430\u043F\u0438\u0441\u0430\u043D\u0438\u044F."],
    en: ["5\u201330 tags", "Add tags: exact, broad, and spelling variants."]
  },
  tags_keywords: {
    ru: ["\u0421\u043B\u043E\u0432\u0430 \u0438\u0437 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u0435\u0441\u0442\u044C \u0432 \u0442\u0435\u0433\u0430\u0445", "\u041F\u0435\u0440\u0432\u044B\u0435 \u0442\u0435\u0433\u0438 \u0434\u043E\u043B\u0436\u043D\u044B \u043F\u043E\u0432\u0442\u043E\u0440\u044F\u0442\u044C \u0433\u043B\u0430\u0432\u043D\u044B\u0439 \u0437\u0430\u043F\u0440\u043E\u0441 \u0438\u0437 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F."],
    en: ["Title keywords appear in tags", "The first tags should repeat the main query from the title."]
  },
  chapters: {
    ru: ["\u0415\u0441\u0442\u044C \u0433\u043B\u0430\u0432\u044B (\u0442\u0430\u0439\u043C\u043A\u043E\u0434\u044B)", "\u0413\u043B\u0430\u0432\u044B \u043F\u043E\u043F\u0430\u0434\u0430\u044E\u0442 \u0432 \u043F\u043E\u0438\u0441\u043A \u0438 \u0443\u043B\u0443\u0447\u0448\u0430\u044E\u0442 \u0443\u0434\u0435\u0440\u0436\u0430\u043D\u0438\u0435."],
    en: ["Has chapters (timestamps)", "Chapters surface in search and improve retention."]
  },
  hashtags: {
    ru: ["\u0415\u0441\u0442\u044C \u0445\u044D\u0448\u0442\u0435\u0433\u0438", "1\u20133 \u0445\u044D\u0448\u0442\u0435\u0433\u0430 \u0432 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0438 \u043F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u044E\u0442\u0441\u044F \u043D\u0430\u0434 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435\u043C."],
    en: ["Has hashtags", "1\u20133 hashtags in the description show above the title."]
  },
  duration: {
    ru: ["\u0414\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u2265 8 \u043C\u0438\u043D\u0443\u0442", "\u041E\u0442 8 \u043C\u0438\u043D\u0443\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B mid-roll \u0440\u0435\u043A\u043B\u0430\u043C\u043D\u044B\u0435 \u0432\u0441\u0442\u0430\u0432\u043A\u0438."],
    en: ["Duration \u2265 8 minutes", "From 8 minutes mid-roll ads become available."]
  },
  links: {
    ru: ["\u0415\u0441\u0442\u044C \u0441\u0441\u044B\u043B\u043A\u0438 / \u043F\u0440\u0438\u0437\u044B\u0432 \u043A \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044E", "\u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0441\u0441\u044B\u043B\u043A\u0438 \u043D\u0430 \u043F\u043B\u0435\u0439\u043B\u0438\u0441\u0442\u044B, \u0441\u043E\u0446\u0441\u0435\u0442\u0438 \u0438\u043B\u0438 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u0448\u0430\u0433 \u0434\u043B\u044F \u0437\u0440\u0438\u0442\u0435\u043B\u044F."],
    en: ["Has links / call to action", "Add links to playlists, socials or the next step for the viewer."]
  }
};
function seoScore(video, lang = "ru") {
  const title = video.title ?? "";
  const desc = video.description ?? "";
  const tags = video.tags ?? [];
  const tw = words(title);
  const letters = title.replace(/[^\p{L}]/gu, "");
  const capsRatio = letters.length ? letters.replace(/[^\p{Lu}]/gu, "").length / letters.length : 0;
  const raw = [
    ["title_len", title.length >= 30 && title.length <= 70, 12],
    ["title_caps", capsRatio < 0.6, 5],
    ["desc_len", desc.length >= 250, 13],
    ["desc_keywords", overlap(tw, desc) >= 0.5, 15],
    ["tags_count", tags.length >= 5 && tags.length <= 30, 12],
    ["tags_keywords", overlap(tw, tags.join(" ")) >= 0.5, 15],
    ["chapters", video.hasChapters ?? hasChapters(desc), 10],
    ["hashtags", new RegExp("#\\p{L}", "u").test(desc), 5],
    ["links", /https?:\/\//.test(desc), 8]
  ];
  if (video.durationSec !== void 0) raw.push(["duration", video.durationSec >= 480, 5]);
  const checks = raw.map(([id, ok, weight]) => ({
    id,
    ok,
    weight,
    label: SEO_LABELS[id][lang][0],
    hint: SEO_LABELS[id][lang][1]
  }));
  const total = checks.reduce((s, c) => s + c.weight, 0);
  const got = checks.reduce((s, c) => s + (c.ok ? c.weight : 0), 0);
  return { score: Math.round(got / total * 100), checks };
}
function computeMetrics(video, lang = "ru", channelViews, now = Date.now()) {
  const ageHours = ageHoursFromIso(video.publishedAt, now);
  const vph = computeVph(video.views, ageHours);
  const views = video.views;
  const likeRate = views && video.likes !== void 0 ? video.likes / views : void 0;
  const commentRate = views && video.comments !== void 0 ? video.comments / views : void 0;
  const engagementRate = views && (video.likes !== void 0 || video.comments !== void 0) ? ((video.likes ?? 0) + (video.comments ?? 0)) / views : void 0;
  const m = { ageHours, vph, likeRate, commentRate, engagementRate, seo: seoScore(video, lang) };
  if (channelViews && channelViews.length >= 3) {
    m.channelMedianViews = median(channelViews);
    m.channelSampleSize = channelViews.length;
    m.outlier = computeOutlier(views, channelViews);
  }
  return m;
}
function analyzeKeyword(query, results) {
  const q = query.toLowerCase().trim();
  const vids = results.filter((r) => r.views !== void 0);
  const viewsArr = vids.map((r) => r.views);
  const ages = vids.map((r) => r.ageHours ?? ageHoursFromIso(r.publishedAt)).filter((x) => x !== void 0);
  const exactInTitle = results.filter((r) => r.title.toLowerCase().includes(q)).length;
  const recent = ages.filter((h) => h < 24 * 180).length;
  const recentShare = ages.length ? recent / ages.length : 0;
  const withSubs = results.filter((r) => r.subscribers !== void 0);
  const bigChannelShare = withSubs.length ? withSubs.filter((r) => r.subscribers >= 1e5).length / withSubs.length : void 0;
  const avgViews = viewsArr.length ? viewsArr.reduce((a, b) => a + b, 0) / viewsArr.length : void 0;
  const medViews = median(viewsArr);
  const medAge = median(ages);
  const smallChannelWinners = results.filter((r) => r.subscribers !== void 0 && r.subscribers < 5e4 && (r.views ?? 0) > 1e4).slice(0, 5);
  const logViews = medViews ? Math.log10(Math.max(medViews, 1)) : 0;
  let competition = Math.min(100, logViews / 6 * 60);
  if (bigChannelShare !== void 0) competition += bigChannelShare * 25;
  else competition += 10;
  competition += exactInTitle / Math.max(results.length, 1) * 15;
  competition = Math.round(Math.min(100, competition));
  let demand = 0;
  if (avgViews) demand += Math.min(60, Math.log10(Math.max(avgViews, 1)) / 6 * 60);
  demand += recentShare * 25;
  demand += Math.min(15, exactInTitle * 1.5);
  demand = Math.round(Math.min(100, demand));
  return {
    query,
    resultCount: results.length,
    exactInTitle,
    avgViews,
    medianViews: medViews,
    medianAgeDays: medAge !== void 0 ? medAge / 24 : void 0,
    recentShare,
    bigChannelShare,
    smallChannelWinners,
    competition,
    demand
  };
}
function extractVideoId(input) {
  const s = input.trim();
  if (/^[\w-]{11}$/.test(s)) return s;
  try {
    const u = new URL(s);
    if (u.hostname === "youtu.be") return u.pathname.slice(1, 12) || void 0;
    const v = u.searchParams.get("v");
    if (v) return v.slice(0, 11);
    const m2 = u.pathname.match(/\/(?:shorts|embed|live|v)\/([\w-]{11})/);
    if (m2) return m2[1];
  } catch {
  }
  const m = s.match(/(?:v=|\/)([\w-]{11})(?:[?&#]|$)/);
  return m?.[1];
}

// src/background/ytparse.ts
function extractJsonVar(html, varName) {
  const re = new RegExp(`(?:var\\s+)?${varName}\\s*=\\s*`, "g");
  let m;
  while (m = re.exec(html)) {
    const start = m.index + m[0].length;
    if (html[start] !== "{") continue;
    const end = matchBrace(html, start);
    if (end < 0) continue;
    try {
      return JSON.parse(html.slice(start, end + 1));
    } catch {
      continue;
    }
  }
  return void 0;
}
function matchBrace(s, start) {
  let depth = 0;
  let inStr = false;
  for (let i = start; i < s.length; i++) {
    const c = s[i];
    if (inStr) {
      if (c === "\\") i++;
      else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') inStr = true;
    else if (c === "{") depth++;
    else if (c === "}") {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}
function deepFind(obj, key, maxDepth = 40, limit2 = 500) {
  const out = [];
  const stack = [[obj, 0]];
  while (stack.length && out.length < limit2) {
    const [cur, d] = stack.pop();
    if (!cur || typeof cur !== "object" || d > maxDepth) continue;
    if (Array.isArray(cur)) {
      for (let i = cur.length - 1; i >= 0; i--) stack.push([cur[i], d + 1]);
      continue;
    }
    const rec = cur;
    if (key in rec) out.push(rec[key]);
    const keys = Object.keys(rec);
    for (let i = keys.length - 1; i >= 0; i--) stack.push([rec[keys[i]], d + 1]);
  }
  return out;
}
function deepFindFirst(obj, key) {
  return deepFind(obj, key, 40, 1)[0];
}
function collectStrings(obj, limit2 = 2e3) {
  const out = [];
  const stack = [obj];
  while (stack.length && out.length < limit2) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      out.push(cur);
      continue;
    }
    if (!cur || typeof cur !== "object") continue;
    if (Array.isArray(cur)) for (const v of cur) stack.push(v);
    else for (const v of Object.values(cur)) stack.push(v);
  }
  return out;
}
function runsText(x) {
  if (!x) return void 0;
  if (typeof x === "string") return x;
  if (typeof x.simpleText === "string") return x.simpleText;
  if (Array.isArray(x.runs)) return x.runs.map((r) => r.text ?? "").join("");
  if (typeof x.content === "string") return x.content;
  return void 0;
}
function videoFromPlayerResponse(pr, pageUrl) {
  const d = pr?.videoDetails;
  if (!d?.videoId) return void 0;
  const mf = pr?.microformat?.playerMicroformatRenderer;
  const thumbs = d.thumbnail?.thumbnails;
  const tracks = pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
  const description = d.shortDescription ?? mf?.description?.simpleText;
  const video = {
    videoId: d.videoId,
    url: pageUrl ?? `https://www.youtube.com/watch?v=${d.videoId}`,
    title: d.title ?? "",
    channelId: d.channelId,
    channelName: d.author,
    views: d.viewCount !== void 0 ? Number(d.viewCount) : void 0,
    durationSec: d.lengthSeconds !== void 0 ? Number(d.lengthSeconds) : void 0,
    tags: Array.isArray(d.keywords) ? d.keywords : [],
    description,
    isLive: !!d.isLiveContent,
    publishedAt: mf?.publishDate ?? mf?.uploadDate,
    category: mf?.category,
    thumbnailUrl: Array.isArray(thumbs) && thumbs.length ? thumbs[thumbs.length - 1].url : void 0,
    hasChapters: hasChapters(description)
  };
  if (Array.isArray(tracks)) {
    video.captionTracks = tracks.filter((t) => t?.baseUrl).map((t) => ({
      lang: t.languageCode ?? "",
      name: runsText(t.name) ?? t.languageCode ?? "",
      url: t.baseUrl,
      auto: t.kind === "asr"
    }));
  }
  if (mf?.ownerProfileUrl) {
    const m = String(mf.ownerProfileUrl).match(/\/(@[^/?]+)/);
    if (m) video.channelHandle = m[1];
  }
  return video;
}
function listVideoFromVideoRenderer(r) {
  if (!r?.videoId) return void 0;
  const owner = r.ownerText?.runs?.[0] ?? r.longBylineText?.runs?.[0] ?? r.shortBylineText?.runs?.[0];
  const browse = owner?.navigationEndpoint?.browseEndpoint;
  const viewText = runsText(r.viewCountText) ?? runsText(r.shortViewCountText);
  const publishedText = runsText(r.publishedTimeText);
  const isLive = !!r.badges?.some((b) => /LIVE/.test(b?.metadataBadgeRenderer?.style ?? "")) || !!viewText && /watching|смотр|дивля/i.test(viewText);
  const v = {
    videoId: r.videoId,
    title: runsText(r.title) ?? "",
    channelName: owner?.text,
    channelId: browse?.browseId,
    channelHandle: browse?.canonicalBaseUrl ? String(browse.canonicalBaseUrl).replace(/^\//, "") : void 0,
    views: isLive ? void 0 : parseCompactNumber(viewText),
    publishedText,
    ageHours: parseRelativeTimeHours(publishedText),
    durationSec: parseDuration(runsText(r.lengthText)),
    isLive,
    verified: !!r.ownerBadges?.some((b) => /VERIFIED/.test(b?.metadataBadgeRenderer?.style ?? "")),
    description: r.detailedMetadataSnippets?.[0]?.snippetText ? runsText(r.detailedMetadataSnippets[0].snippetText) : void 0
  };
  if (v.views !== void 0 && v.ageHours !== void 0) v.vph = v.views / Math.max(v.ageHours, 1);
  return v;
}
function listVideoFromLockup(l) {
  if (!l?.contentId) return void 0;
  if (l.contentType && !/VIDEO|SHORTS/.test(l.contentType)) return void 0;
  const meta = l.metadata?.lockupMetadataViewModel;
  const title = runsText(meta?.title) ?? "";
  const rows = meta?.metadata?.contentMetadataViewModel?.metadataRows ?? [];
  const parts = rows.flatMap((row) => row?.metadataParts ?? []);
  const texts = parts.map((p) => p?.accessibilityLabel || runsText(p?.text) || "").filter(Boolean);
  const browseIds = deepFind(meta, "browseEndpoint", 24, 3);
  const viewText = texts.find((t) => /view|просмотр|перегляд/i.test(t));
  const ageText = texts.find((t) => /ago|назад|тому/i.test(t));
  const channelName = texts.find((t) => t !== viewText && t !== ageText && !/view|просмотр|перегляд|ago|назад|тому/i.test(t));
  const badges = deepFind(l.contentImage, "thumbnailBadgeViewModel", 12, 10);
  const lengthText = badges.map((b) => runsText(b?.text)).find((t) => t && /^\d+:\d\d/.test(t));
  const isLive = !!viewText && /watching|смотр|дивля/i.test(viewText);
  const v = {
    videoId: l.contentId,
    title,
    channelName,
    channelId: browseIds[0]?.browseId,
    channelHandle: browseIds[0]?.canonicalBaseUrl ? String(browseIds[0].canonicalBaseUrl).replace(/^\//, "") : void 0,
    views: isLive ? void 0 : parseCompactNumber(viewText),
    publishedText: ageText,
    ageHours: parseRelativeTimeHours(ageText),
    durationSec: parseDuration(lengthText),
    isLive,
    isShort: /SHORTS/.test(l.contentType ?? "")
  };
  if (v.views !== void 0 && v.ageHours !== void 0) v.vph = v.views / Math.max(v.ageHours, 1);
  return v;
}
function listVideoFromCompact(r) {
  if (!r?.videoId) return void 0;
  const owner = r.longBylineText?.runs?.[0] ?? r.shortBylineText?.runs?.[0];
  const browse = owner?.navigationEndpoint?.browseEndpoint;
  const viewText = runsText(r.viewCountText);
  const publishedText = runsText(r.publishedTimeText);
  const isLive = !!viewText && /watching|смотр|дивля/i.test(viewText);
  const v = {
    videoId: r.videoId,
    title: runsText(r.title) ?? "",
    channelName: owner?.text,
    channelId: browse?.browseId,
    channelHandle: browse?.canonicalBaseUrl ? String(browse.canonicalBaseUrl).replace(/^\//, "") : void 0,
    views: isLive ? void 0 : parseCompactNumber(viewText),
    publishedText,
    ageHours: parseRelativeTimeHours(publishedText),
    durationSec: parseDuration(runsText(r.lengthText)),
    isLive
  };
  if (v.views !== void 0 && v.ageHours !== void 0) v.vph = v.views / Math.max(v.ageHours, 1);
  return v;
}
function listVideosFromData(data) {
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  const push = (v) => {
    if (v && !seen.has(v.videoId)) {
      seen.add(v.videoId);
      out.push(v);
    }
  };
  for (const r of deepFind(data, "videoRenderer")) push(listVideoFromVideoRenderer(r));
  for (const r of deepFind(data, "gridVideoRenderer")) push(listVideoFromVideoRenderer(r));
  for (const r of deepFind(data, "compactVideoRenderer")) push(listVideoFromCompact(r));
  for (const r of deepFind(data, "lockupViewModel")) push(listVideoFromLockup(r));
  return out;
}
function searchResultsFromData(data) {
  const root = data?.contents?.twoColumnSearchResultsRenderer ?? data;
  return listVideosFromData(root);
}
var LIKE_WORD = /like|нравится|лайк|подоба|вподоба/i;
function parseLikesFromStrings(strings) {
  for (const s of strings) {
    if (s.length > 160 || !LIKE_WORD.test(s)) continue;
    const m = s.match(/(\d[\d,.\s ]*)/);
    if (!m) continue;
    const n = parseCompactNumber(m[1]);
    if (n !== void 0 && n > 0) return n;
  }
  return void 0;
}
function watchExtrasFromData(data) {
  const results = data?.contents?.twoColumnWatchNextResults?.results?.results ?? data;
  const primary = deepFindFirst(results, "videoPrimaryInfoRenderer");
  const secondary = deepFindFirst(results, "videoSecondaryInfoRenderer");
  const extras = { related: [] };
  if (primary) extras.likes = parseLikesFromStrings(collectStrings(primary, 600));
  const commentCount = deepFindFirst(data, "commentCount");
  if (commentCount) extras.comments = parseCompactNumber(runsText(commentCount));
  const subText = deepFindFirst(secondary ?? data, "subscriberCountText");
  if (subText) extras.subscribers = parseCompactNumber(runsText(subText));
  const owner = deepFindFirst(secondary ?? data, "videoOwnerRenderer");
  const base = owner?.navigationEndpoint?.browseEndpoint?.canonicalBaseUrl;
  if (base) extras.channelHandle = String(base).replace(/^\//, "");
  const sec = data?.contents?.twoColumnWatchNextResults?.secondaryResults;
  if (sec) extras.related = listVideosFromData(sec).slice(0, 30);
  return extras;
}
function channelFromData(data, url) {
  const meta = data?.metadata?.channelMetadataRenderer;
  const ch = {
    channelId: meta?.externalId,
    name: meta?.title,
    description: meta?.description,
    url: meta?.channelUrl ?? url
  };
  const vanity = meta?.vanityChannelUrl;
  if (vanity) {
    const m = vanity.match(/\/(@[^/?]+)/);
    if (m) ch.handle = m[1];
  }
  if (typeof meta?.keywords === "string" && meta.keywords.trim()) ch.keywords = parseChannelKeywords(meta.keywords);
  const header = data?.header ?? {};
  const strings = collectStrings(header, 400);
  for (const s of strings) {
    if (ch.subscribers === void 0 && /subscriber|подписчик|підписник/i.test(s)) ch.subscribers = parseCompactNumber(s);
    else if (ch.videoCount === void 0 && /\bvideos?\b|видео|відео/i.test(s) && /^\s*[\d.,\s]+\s*(k|m|тыс|млн)?\.?\s*\S+$/i.test(s))
      ch.videoCount = parseCompactNumber(s);
    else if (!ch.handle && /^@[\w.-]+$/.test(s)) ch.handle = s;
  }
  return ch;
}
function parseChannelKeywords(raw) {
  const out = [];
  const re = /"([^"]+)"|(\S+)/g;
  let m;
  while (m = re.exec(raw)) out.push((m[1] ?? m[2]).trim());
  return out.filter(Boolean);
}
function transcriptFromJson3(json2, groupSec = 30) {
  const events = json2?.events ?? [];
  const lines = [];
  let bucketStart = -1;
  let buf = [];
  const flush = () => {
    if (buf.length) lines.push(`[${fmt(bucketStart)}] ${buf.join(" ").replace(/\s+/g, " ").trim()}`);
    buf = [];
  };
  for (const ev of events) {
    if (!Array.isArray(ev?.segs)) continue;
    const text = ev.segs.map((s) => s?.utf8 ?? "").join("").replace(/\n/g, " ").trim();
    if (!text) continue;
    const t = Math.floor((ev.tStartMs ?? 0) / 1e3);
    if (bucketStart < 0 || t - bucketStart >= groupSec) {
      flush();
      bucketStart = t;
    }
    buf.push(text);
  }
  flush();
  return lines.join("\n");
}
function fmt(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor(sec % 3600 / 60);
  const s = sec % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}

// src/background/store.ts
var SNAP_KEY = "snapshots";
var MAX_VIDEOS = 400;
var MAX_PER_VIDEO = 24;
var MAX_AGE_MS = 7 * 24 * 3600 * 1e3;
var snapWriteChain = Promise.resolve();
function recordSnapshot(videoId, views) {
  const run = async () => {
    const now = Date.now();
    const all = (await chrome.storage.local.get(SNAP_KEY))[SNAP_KEY] ?? {};
    const list = (all[videoId] ?? []).filter((s) => now - s.t < MAX_AGE_MS);
    const last = list[list.length - 1];
    if (!last || now - last.t > 5 * 60 * 1e3 || last.v !== views) list.push({ t: now, v: views });
    while (list.length > MAX_PER_VIDEO) list.shift();
    all[videoId] = list;
    const ids = Object.keys(all);
    if (ids.length > MAX_VIDEOS) {
      ids.sort((a, b) => (all[a][all[a].length - 1]?.t ?? 0) - (all[b][all[b].length - 1]?.t ?? 0)).slice(0, ids.length - MAX_VIDEOS).forEach((id) => delete all[id]);
    }
    await chrome.storage.local.set({ [SNAP_KEY]: all });
    return recentVph(list);
  };
  const p = snapWriteChain.then(run, run);
  snapWriteChain = p.then(
    () => void 0,
    () => void 0
  );
  return p;
}
function recentVph(list) {
  if (list.length < 2) return void 0;
  const last = list[list.length - 1];
  const candidates = list.filter((s) => last.t - s.t >= 20 * 60 * 1e3 && last.t - s.t <= 24 * 3600 * 1e3);
  if (!candidates.length) return void 0;
  const first = candidates[0];
  const hours = (last.t - first.t) / 36e5;
  if (hours <= 0) return void 0;
  return Math.max(0, (last.v - first.v) / hours);
}
var CH_KEY = "channelCache";
var CH_TTL = 12 * 3600 * 1e3;
async function getCachedChannel(key) {
  const all = (await chrome.storage.session.get(CH_KEY))[CH_KEY] ?? {};
  const hit = all[key];
  if (hit && Date.now() - hit.fetchedAt < CH_TTL) return hit;
  return void 0;
}
async function setCachedChannel(keys, stats) {
  const all = (await chrome.storage.session.get(CH_KEY))[CH_KEY] ?? {};
  for (const k of keys) if (k) all[k] = stats;
  const ids = Object.keys(all);
  if (ids.length > 300) {
    ids.sort((a, b) => all[a].fetchedAt - all[b].fetchedAt).slice(0, ids.length - 300).forEach((id) => delete all[id]);
  }
  await chrome.storage.session.set({ [CH_KEY]: all });
}

// src/background/native.ts
var NativeHostError = class extends Error {
};
function friendly(err) {
  const msg = err instanceof Error ? err.message : String(err);
  if (/not found|Specified native messaging host/i.test(msg)) {
    return "Native host is not installed (run native-host/install.bat and reload the extension).";
  }
  if (/Access to the specified native messaging host is forbidden/i.test(msg)) {
    return "Native host manifest does not allow this extension ID (re-run install.bat with the current extension ID).";
  }
  if (/Native host has exited/i.test(msg)) {
    return "Native host exited unexpectedly (is Node.js installed? check native-host/host.log).";
  }
  return msg;
}
async function nativeCall(host, message) {
  try {
    const res = await chrome.runtime.sendNativeMessage(host, message);
    if (res && typeof res === "object" && res.ok === false) throw new NativeHostError(res.error ?? "native host error");
    return res;
  } catch (err) {
    if (err instanceof NativeHostError) throw err;
    throw new NativeHostError(friendly(err));
  }
}
function nativePing(host) {
  return nativeCall(host, { cmd: "ping" });
}
function nativeWhich(host, name) {
  return nativeCall(host, { cmd: "which", name });
}
function nativeExec(host, path3, args, opts = {}) {
  return nativeCall(host, { cmd: "exec", path: path3, args, timeoutMs: opts.timeoutMs ?? 12e4, maxOutput: opts.maxOutput ?? 2e5 });
}
function nativeSubtitles(host, ytdlpPath, videoUrl, langs) {
  return nativeCall(host, { cmd: "ytdlp_subs", path: ytdlpPath, url: videoUrl, langs, timeoutMs: 18e4 });
}

// src/background/youtube.ts
var YouTubeError = class extends Error {
};
var API = "https://www.googleapis.com/youtube/v3";
var YouTube = class {
  getSettings;
  constructor(getSettings) {
    this.getSettings = getSettings;
  }
  // ---- HTTP helpers -----------------------------------------------------
  async fetchHtml(url) {
    const u = new URL(url);
    u.searchParams.set("hl", "en");
    const res = await fetch(u.toString(), {
      credentials: "include",
      headers: { "Accept-Language": "en-US,en;q=0.9" }
    });
    if (!res.ok) throw new YouTubeError(`YouTube returned HTTP ${res.status} for ${u.pathname}`);
    const html = await res.text();
    if (/consent\.youtube\.com|action="https:\/\/consent\./.test(html) && !/ytInitialData/.test(html)) {
      throw new YouTubeError("YouTube asks for cookie consent. Open youtube.com in a tab, accept the consent dialog and retry.");
    }
    return html;
  }
  async api(path3, params) {
    const s = await this.getSettings();
    if (!s.youtubeApiKey) throw new YouTubeError("YouTube Data API key is not configured");
    const u = new URL(`${API}/${path3}`);
    for (const [k, v] of Object.entries(params)) if (v !== void 0 && v !== "") u.searchParams.set(k, String(v));
    u.searchParams.set("key", s.youtubeApiKey);
    const res = await fetch(u.toString());
    const json2 = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = json2?.error?.message ?? `HTTP ${res.status}`;
      if (/quota/i.test(msg)) throw new YouTubeError("YouTube Data API quota exceeded for today (falling back to page parsing where possible).");
      throw new YouTubeError(`YouTube Data API error: ${msg}`);
    }
    return json2;
  }
  async hasKey() {
    return !!(await this.getSettings()).youtubeApiKey;
  }
  // ---- videos -----------------------------------------------------------
  async getVideo(idOrUrl) {
    const id = extractVideoId(idOrUrl);
    if (!id) throw new YouTubeError(`Cannot find a video id in "${idOrUrl}"`);
    if (await this.hasKey()) {
      try {
        const [v] = await this.apiVideos([id]);
        if (v) {
          return v;
        }
      } catch (err) {
        if (!(err instanceof YouTubeError) || !/quota/i.test(err.message)) throw err;
      }
    }
    return this.pageVideo(id);
  }
  /** Full video details from the watch page (no API key needed). */
  async pageVideo(id) {
    const url = `https://www.youtube.com/watch?v=${id}`;
    const html = await this.fetchHtml(url);
    const pr = extractJsonVar(html, "ytInitialPlayerResponse");
    const video = videoFromPlayerResponse(pr, url);
    if (!video) throw new YouTubeError(`Could not read video data for ${id} (private, removed or blocked?)`);
    const data = extractJsonVar(html, "ytInitialData");
    if (data) {
      const extras = watchExtrasFromData(data);
      video.likes = extras.likes;
      video.comments = extras.comments;
      video.subscribers = extras.subscribers;
      if (extras.channelHandle) video.channelHandle = extras.channelHandle;
    }
    return video;
  }
  /** Batch video details via the Data API (up to 50 ids). */
  async apiVideos(ids) {
    const out = [];
    for (let i = 0; i < ids.length; i += 50) {
      const chunk = ids.slice(i, i + 50);
      const json2 = await this.api("videos", { part: "snippet,statistics,contentDetails", id: chunk.join(",") });
      for (const it of json2.items ?? []) {
        const sn = it.snippet ?? {};
        const st = it.statistics ?? {};
        const description = sn.description;
        out.push({
          videoId: it.id,
          url: `https://www.youtube.com/watch?v=${it.id}`,
          title: sn.title ?? "",
          channelId: sn.channelId,
          channelName: sn.channelTitle,
          publishedAt: sn.publishedAt,
          description,
          tags: sn.tags ?? [],
          category: sn.categoryId,
          views: st.viewCount !== void 0 ? Number(st.viewCount) : void 0,
          likes: st.likeCount !== void 0 ? Number(st.likeCount) : void 0,
          comments: st.commentCount !== void 0 ? Number(st.commentCount) : void 0,
          durationSec: parseIsoDuration(it.contentDetails?.duration),
          isLive: sn.liveBroadcastContent === "live",
          thumbnailUrl: sn.thumbnails?.maxres?.url ?? sn.thumbnails?.high?.url,
          hasChapters: hasChapters(description)
        });
      }
    }
    const chIds = [...new Set(out.map((v) => v.channelId).filter((x) => !!x))];
    if (chIds.length) {
      const subs = await this.apiChannelSubs(chIds).catch(() => ({}));
      for (const v of out) {
        const c = v.channelId ? subs[v.channelId] : void 0;
        if (c) {
          v.subscribers = c.subscribers;
          v.channelVideoCount = c.videoCount;
          v.channelHandle = c.handle;
        }
      }
    }
    return out;
  }
  async apiChannelSubs(ids) {
    const out = {};
    for (let i = 0; i < ids.length; i += 50) {
      const json2 = await this.api("channels", { part: "snippet,statistics", id: ids.slice(i, i + 50).join(",") });
      for (const it of json2.items ?? []) {
        out[it.id] = {
          subscribers: it.statistics?.subscriberCount !== void 0 ? Number(it.statistics.subscriberCount) : void 0,
          videoCount: it.statistics?.videoCount !== void 0 ? Number(it.statistics.videoCount) : void 0,
          handle: it.snippet?.customUrl
        };
      }
    }
    return out;
  }
  toList(v) {
    const ageHours = ageHoursFromIso(v.publishedAt);
    return {
      videoId: v.videoId,
      title: v.title,
      channelName: v.channelName,
      channelId: v.channelId,
      channelHandle: v.channelHandle,
      views: v.views,
      likes: v.likes,
      comments: v.comments,
      publishedAt: v.publishedAt,
      ageHours,
      durationSec: v.durationSec,
      vph: v.views !== void 0 && ageHours !== void 0 ? v.views / Math.max(ageHours, 1) : void 0,
      isLive: v.isLive,
      subscribers: v.subscribers,
      description: v.description?.slice(0, 200)
    };
  }
  // ---- search -----------------------------------------------------------
  async search(query, maxResults = 15, order = "relevance") {
    maxResults = Math.max(1, Math.min(50, maxResults));
    if (await this.hasKey()) {
      try {
        const json2 = await this.api("search", { part: "snippet", type: "video", q: query, maxResults, order });
        const ids = (json2.items ?? []).map((it) => it.id?.videoId).filter(Boolean);
        const vids = await this.apiVideos(ids);
        const byId = new Map(vids.map((v) => [v.videoId, v]));
        return ids.map((id) => byId.get(id)).filter(Boolean).map((v) => this.toList(v));
      } catch (err) {
        if (!(err instanceof YouTubeError) || !/quota/i.test(err.message)) throw err;
      }
    }
    const sp = order === "date" ? "&sp=CAI%253D" : order === "viewCount" ? "&sp=CAM%253D" : "";
    const html = await this.fetchHtml(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}${sp}`);
    const data = extractJsonVar(html, "ytInitialData");
    if (!data) throw new YouTubeError("Could not parse search results page");
    return searchResultsFromData(data).slice(0, maxResults);
  }
  /** Search through the public results page only (no API quota). */
  async searchPage(query, maxResults = 20) {
    const html = await this.fetchHtml(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`);
    const data = extractJsonVar(html, "ytInitialData");
    if (!data) throw new YouTubeError("Could not parse search results page");
    return searchResultsFromData(data).slice(0, maxResults);
  }
  /** Position of `videoId` in YouTube search for each tag (vidIQ's "ranked tags"); cached for the session. */
  async tagRanks(videoId, tags) {
    const key = "tagRanks";
    const all = (await chrome.storage.session.get(key))[key] ?? {};
    const out = [];
    for (const tag of tags.slice(0, 8)) {
      const ck = `${videoId}|${tag.toLowerCase()}`;
      const hit = all[ck];
      if (hit && Date.now() - hit.t < 6 * 3600 * 1e3) {
        out.push({ tag, rank: hit.rank, checked: hit.checked });
        continue;
      }
      try {
        const res = await this.searchPage(tag, 20);
        const idx = res.findIndex((v) => v.videoId === videoId);
        const r = { tag, rank: idx >= 0 ? idx + 1 : null, checked: res.length };
        all[ck] = { ...r, t: Date.now() };
        out.push(r);
      } catch (err) {
        out.push({ tag, rank: null, checked: 0 });
        if (err instanceof YouTubeError && /consent|HTTP 429/.test(err.message)) break;
      }
      await new Promise((r) => setTimeout(r, 250));
    }
    const keys = Object.keys(all);
    if (keys.length > 500) keys.sort((a, b) => all[a].t - all[b].t).slice(0, keys.length - 500).forEach((k) => delete all[k]);
    await chrome.storage.session.set({ [key]: all });
    return out;
  }
  // ---- channels ---------------------------------------------------------
  /** Accepts "UC…", "@handle", or any channel/video URL. */
  async channelStats(channelRef, maxVideos = 25, useCache = true) {
    const ref = normalizeChannelRef(channelRef);
    if (useCache) {
      const cached = await getCachedChannel(ref.key);
      if (cached && cached.videos.length >= Math.min(maxVideos, cached.videos.length)) return cached;
    }
    let stats;
    if (await this.hasKey()) {
      try {
        stats = await this.apiChannelStats(ref, maxVideos);
      } catch (err) {
        if (!(err instanceof YouTubeError) || !/quota/i.test(err.message)) throw err;
      }
    }
    if (!stats) stats = await this.pageChannelStats(ref, maxVideos);
    const keys = [ref.key, stats.channel.channelId ?? "", stats.channel.handle ?? ""].filter(Boolean);
    await setCachedChannel(keys, stats);
    return stats;
  }
  async apiChannelStats(ref, maxVideos) {
    const params = { part: "snippet,statistics,contentDetails" };
    if (ref.kind === "id") params.id = ref.value;
    else if (ref.kind === "handle") params.forHandle = ref.value;
    else {
      const html = await this.fetchHtml(`https://www.youtube.com/${ref.value}`);
      const data = extractJsonVar(html, "ytInitialData");
      const ch = channelFromData(data);
      if (!ch.channelId) throw new YouTubeError(`Could not resolve channel "${ref.value}"`);
      params.id = ch.channelId;
    }
    const json2 = await this.api("channels", params);
    const it = json2.items?.[0];
    if (!it) throw new YouTubeError(`Channel not found: ${ref.value}`);
    const channel = {
      channelId: it.id,
      name: it.snippet?.title,
      handle: it.snippet?.customUrl,
      description: it.snippet?.description,
      subscribers: it.statistics?.subscriberCount !== void 0 ? Number(it.statistics.subscriberCount) : void 0,
      videoCount: it.statistics?.videoCount !== void 0 ? Number(it.statistics.videoCount) : void 0,
      url: `https://www.youtube.com/channel/${it.id}`
    };
    const uploads = it.contentDetails?.relatedPlaylists?.uploads ?? `UU${String(it.id).slice(2)}`;
    const pl = await this.api("playlistItems", { part: "contentDetails", playlistId: uploads, maxResults: Math.min(50, maxVideos) });
    const ids = (pl.items ?? []).map((p) => p.contentDetails?.videoId).filter(Boolean);
    const vids = await this.apiVideos(ids);
    const videos = vids.map((v) => this.toList(v));
    return finishStats(channel, videos);
  }
  async pageChannelStats(ref, maxVideos) {
    const base = ref.kind === "id" ? `channel/${ref.value}` : ref.kind === "handle" ? ref.value : ref.value;
    const html = await this.fetchHtml(`https://www.youtube.com/${base}/videos`);
    const data = extractJsonVar(html, "ytInitialData");
    if (!data) throw new YouTubeError(`Could not parse channel page for ${ref.value}`);
    const channel = channelFromData(data, `https://www.youtube.com/${base}`);
    const videos = listVideosFromData(data).filter((v) => !v.isLive && !v.isShort).slice(0, maxVideos);
    return finishStats(channel, videos);
  }
  // ---- comments ---------------------------------------------------------
  async comments(idOrUrl, maxResults = 30) {
    const id = extractVideoId(idOrUrl);
    if (!id) throw new YouTubeError(`Cannot find a video id in "${idOrUrl}"`);
    if (!await this.hasKey()) throw new YouTubeError("Reading comments requires a YouTube Data API key (Settings \u2192 YouTube Data API).");
    const json2 = await this.api("commentThreads", {
      part: "snippet",
      videoId: id,
      maxResults: Math.max(1, Math.min(100, maxResults)),
      order: "relevance",
      textFormat: "plainText"
    });
    return (json2.items ?? []).map((it) => {
      const c = it.snippet?.topLevelComment?.snippet ?? {};
      return {
        author: c.authorDisplayName ?? "",
        text: c.textDisplay ?? c.textOriginal ?? "",
        likes: c.likeCount !== void 0 ? Number(c.likeCount) : void 0,
        publishedText: c.publishedAt,
        replies: it.snippet?.totalReplyCount !== void 0 ? Number(it.snippet.totalReplyCount) : void 0
      };
    });
  }
  // ---- suggestions ------------------------------------------------------
  async suggestions(query, lang = "en") {
    const u = new URL("https://suggestqueries.google.com/complete/search");
    u.searchParams.set("client", "firefox");
    u.searchParams.set("ds", "yt");
    u.searchParams.set("hl", lang);
    u.searchParams.set("q", query);
    const res = await fetch(u.toString());
    if (!res.ok) throw new YouTubeError(`Suggestions request failed (HTTP ${res.status})`);
    const json2 = await res.json();
    return Array.isArray(json2?.[1]) ? json2[1].map((x) => Array.isArray(x) ? x[0] : x).filter((x) => typeof x === "string") : [];
  }
  // ---- transcript -------------------------------------------------------
  async transcript(idOrUrl, preferredLangs = []) {
    const id = extractVideoId(idOrUrl);
    if (!id) throw new YouTubeError(`Cannot find a video id in "${idOrUrl}"`);
    const url = `https://www.youtube.com/watch?v=${id}`;
    let tracks = [];
    let pageErr;
    try {
      const html = await this.fetchHtml(url);
      const pr = extractJsonVar(html, "ytInitialPlayerResponse");
      tracks = videoFromPlayerResponse(pr, url)?.captionTracks ?? [];
    } catch (err) {
      pageErr = err instanceof Error ? err.message : String(err);
    }
    const available = tracks.map((t) => `${t.lang}${t.auto ? " (auto)" : ""}`);
    const pick = pickTrack(tracks, preferredLangs);
    if (pick) {
      try {
        const res = await fetch(pick.url + "&fmt=json3", { credentials: "include" });
        if (res.ok) {
          const text = (await res.text()).trim();
          if (text.startsWith("{")) {
            const t = transcriptFromJson3(JSON.parse(text));
            if (t) return { lang: pick.lang, auto: pick.auto, source: "page", text: t, available };
          }
        }
      } catch {
      }
    }
    const s = await this.getSettings();
    const ytdlp = s.localTools.find((t) => t.name === "yt-dlp" && t.path);
    if (ytdlp) {
      const r = await nativeSubtitles(s.nativeHostName, ytdlp.path, url, preferredLangs.length ? preferredLangs : ["en"]);
      if (r?.text) return { lang: r.lang, auto: r.auto, source: "yt-dlp", text: r.text, available: r.available ?? available };
      throw new YouTubeError("yt-dlp found no subtitles for this video");
    }
    if (pageErr) throw new YouTubeError(`Could not load the video page: ${pageErr}`);
    if (!tracks.length) throw new YouTubeError("This video has no caption tracks. Configure yt-dlp in Settings \u2192 Local tools to extract subtitles anyway.");
    throw new YouTubeError("Caption download was blocked by YouTube. Configure yt-dlp in Settings \u2192 Local tools as a fallback.");
  }
};
function normalizeChannelRef(input) {
  let s = input.trim();
  try {
    if (/^https?:\/\//.test(s)) {
      const u = new URL(s);
      s = u.pathname.replace(/^\/+|\/+$/g, "");
      s = s.split("/").slice(0, 2).join("/");
      if (/^(watch|shorts)/.test(s)) throw new YouTubeError("Pass a channel (UC\u2026, @handle or channel URL), not a video URL");
    }
  } catch (err) {
    if (err instanceof YouTubeError) throw err;
  }
  s = s.replace(/^\/+/, "");
  if (/^UC[\w-]{20,}$/.test(s)) return { kind: "id", value: s, key: s };
  const m = s.match(/^channel\/(UC[\w-]{20,})/);
  if (m) return { kind: "id", value: m[1], key: m[1] };
  if (/^@/.test(s)) {
    const h = s.split("/")[0];
    return { kind: "handle", value: h, key: h.toLowerCase() };
  }
  if (/^(c|user)\//.test(s)) return { kind: "path", value: s.split("/").slice(0, 2).join("/"), key: s.toLowerCase() };
  if (/^[\w.-]+$/.test(s)) return { kind: "handle", value: "@" + s, key: ("@" + s).toLowerCase() };
  throw new YouTubeError(`Unrecognized channel reference: ${input}`);
}
function finishStats(channel, videos) {
  const viewsArr = videos.map((v) => v.views).filter((x) => x !== void 0);
  const ages = videos.map((v) => v.ageHours ?? ageHoursFromIso(v.publishedAt)).filter((x) => x !== void 0);
  let uploadsPerWeek;
  if (ages.length >= 2) {
    const span = Math.max(...ages) - Math.min(...ages);
    if (span > 0) uploadsPerWeek = (ages.length - 1) / span * 168;
  }
  return {
    channel,
    videos,
    medianViews: median(viewsArr),
    avgViews: viewsArr.length ? viewsArr.reduce((a, b) => a + b, 0) / viewsArr.length : void 0,
    uploadsPerWeek,
    fetchedAt: Date.now()
  };
}
function pickTrack(tracks, preferred) {
  if (!tracks.length) return void 0;
  const prefs = preferred.map((p) => p.toLowerCase());
  for (const p of prefs) {
    const manual = tracks.find((t) => t.lang.toLowerCase().startsWith(p) && !t.auto);
    if (manual) return manual;
  }
  for (const p of prefs) {
    const auto = tracks.find((t) => t.lang.toLowerCase().startsWith(p));
    if (auto) return auto;
  }
  return tracks.find((t) => !t.auto) ?? tracks[0];
}

// node_modules/@anthropic-ai/sdk/internal/tslib.mjs
function __classPrivateFieldSet(receiver, state, value, kind, f) {
  if (kind === "m")
    throw new TypeError("Private method is not writable");
  if (kind === "a" && !f)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
}
function __classPrivateFieldGet(receiver, state, kind, f) {
  if (kind === "a" && !f)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}

// node_modules/@anthropic-ai/sdk/internal/utils/values.mjs
init_error();
var startsWithSchemeRegexp = /^[a-z][a-z0-9+.-]*:/i;
var isAbsoluteURL = (url) => {
  return startsWithSchemeRegexp.test(url);
};
var isArray = (val) => (isArray = Array.isArray, isArray(val));
var isReadonlyArray = isArray;
function maybeObj(x) {
  if (typeof x !== "object") {
    return {};
  }
  return x ?? {};
}
function isEmptyObj(obj) {
  if (!obj)
    return true;
  for (const _k in obj)
    return false;
  return true;
}
function hasOwn(obj, key) {
  return Object.prototype.hasOwnProperty.call(obj, key);
}
function isObj(obj) {
  return obj != null && typeof obj === "object" && !Array.isArray(obj);
}
var validatePositiveInteger = (name, n) => {
  if (typeof n !== "number" || !Number.isInteger(n)) {
    throw new AnthropicError(`${name} must be an integer`);
  }
  if (n < 0) {
    throw new AnthropicError(`${name} must be a positive integer`);
  }
  return n;
};
var safeJSON = (text) => {
  try {
    return JSON.parse(text);
  } catch (err) {
    return void 0;
  }
};
function checkNever(_value) {
}

// node_modules/@anthropic-ai/sdk/internal/utils/sleep.mjs
var sleep = (ms, signal) => new Promise((resolve) => {
  if (signal?.aborted)
    return resolve();
  const onAbort = () => {
    clearTimeout(timer);
    resolve();
  };
  const timer = setTimeout(() => {
    signal?.removeEventListener("abort", onAbort);
    resolve();
  }, ms);
  signal?.addEventListener("abort", onAbort, { once: true });
});

// node_modules/@anthropic-ai/sdk/client.mjs
init_errors();

// node_modules/@anthropic-ai/sdk/version.mjs
var VERSION = "0.133.0";

// node_modules/@anthropic-ai/sdk/internal/detect-platform.mjs
var isRunningInBrowser = () => {
  return (
    // @ts-ignore
    typeof window !== "undefined" && // @ts-ignore
    typeof window.document !== "undefined" && // @ts-ignore
    typeof navigator !== "undefined"
  );
};
function getDetectedPlatform() {
  if (typeof Deno !== "undefined" && Deno.build != null) {
    return "deno";
  }
  if (typeof EdgeRuntime !== "undefined") {
    return "edge";
  }
  if (Object.prototype.toString.call(typeof globalThis.process !== "undefined" ? globalThis.process : 0) === "[object process]") {
    return "node";
  }
  return "unknown";
}
var getPlatformProperties = () => {
  const detectedPlatform = getDetectedPlatform();
  if (detectedPlatform === "deno") {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": normalizePlatform(Deno.build.os),
      "X-Stainless-Arch": normalizeArch(Deno.build.arch),
      "X-Stainless-Runtime": "deno",
      "X-Stainless-Runtime-Version": typeof Deno.version === "string" ? Deno.version : Deno.version?.deno ?? "unknown"
    };
  }
  if (typeof EdgeRuntime !== "undefined") {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": "Unknown",
      "X-Stainless-Arch": `other:${EdgeRuntime}`,
      "X-Stainless-Runtime": "edge",
      "X-Stainless-Runtime-Version": globalThis.process?.version ?? "unknown"
    };
  }
  if (detectedPlatform === "node") {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": normalizePlatform(globalThis.process.platform ?? "unknown"),
      "X-Stainless-Arch": normalizeArch(globalThis.process.arch ?? "unknown"),
      "X-Stainless-Runtime": "node",
      "X-Stainless-Runtime-Version": globalThis.process.version ?? "unknown"
    };
  }
  const browserInfo = getBrowserInfo();
  if (browserInfo) {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": "Unknown",
      "X-Stainless-Arch": "unknown",
      "X-Stainless-Runtime": `browser:${browserInfo.browser}`,
      "X-Stainless-Runtime-Version": browserInfo.version
    };
  }
  return {
    "X-Stainless-Lang": "js",
    "X-Stainless-Package-Version": VERSION,
    "X-Stainless-OS": "Unknown",
    "X-Stainless-Arch": "unknown",
    "X-Stainless-Runtime": "unknown",
    "X-Stainless-Runtime-Version": "unknown"
  };
};
function getBrowserInfo() {
  if (typeof navigator === "undefined" || !navigator) {
    return null;
  }
  const browserPatterns = [
    { key: "edge", pattern: /Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "chrome", pattern: /Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "firefox", pattern: /Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "safari", pattern: /(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/ }
  ];
  for (const { key, pattern } of browserPatterns) {
    const match = pattern.exec(navigator.userAgent);
    if (match) {
      const major = match[1] || 0;
      const minor = match[2] || 0;
      const patch = match[3] || 0;
      return { browser: key, version: `${major}.${minor}.${patch}` };
    }
  }
  return null;
}
var normalizeArch = (arch) => {
  if (arch === "x32")
    return "x32";
  if (arch === "x86_64" || arch === "x64")
    return "x64";
  if (arch === "arm")
    return "arm";
  if (arch === "aarch64" || arch === "arm64")
    return "arm64";
  if (arch)
    return `other:${arch}`;
  return "unknown";
};
var normalizePlatform = (platform) => {
  platform = platform.toLowerCase();
  if (platform.includes("ios"))
    return "iOS";
  if (platform === "android")
    return "Android";
  if (platform === "darwin")
    return "MacOS";
  if (platform === "win32")
    return "Windows";
  if (platform === "freebsd")
    return "FreeBSD";
  if (platform === "openbsd")
    return "OpenBSD";
  if (platform === "linux")
    return "Linux";
  if (platform)
    return `Other:${platform}`;
  return "Unknown";
};
var _platformHeaders;
var getPlatformHeaders = () => {
  return _platformHeaders ?? (_platformHeaders = getPlatformProperties());
};

// node_modules/@anthropic-ai/sdk/internal/request-signal.mjs
var cleanups = /* @__PURE__ */ new WeakMap();
var registry = typeof globalThis.FinalizationRegistry === "function" ? new globalThis.FinalizationRegistry((controller) => releaseRequestSignal(controller)) : null;
function makeCleanup(signal, listener) {
  return () => signal.removeEventListener("abort", listener);
}
function registerRequestSignalCleanup(controller, signal, listener) {
  cleanups.set(controller, makeCleanup(signal, listener));
}
function armAbandonmentBackstop(body, controller) {
  if (cleanups.has(controller))
    registry?.register(body, controller, controller);
}
function releaseRequestSignal(controller) {
  const cleanup = cleanups.get(controller);
  if (cleanup) {
    cleanups.delete(controller);
    registry?.unregister(controller);
    cleanup();
  }
}

// node_modules/@anthropic-ai/sdk/internal/shims.mjs
function getDefaultFetch() {
  if (typeof fetch !== "undefined") {
    return fetch;
  }
  throw new Error("`fetch` is not defined as a global; Either pass `fetch` to the client, `new Anthropic({ fetch })` or polyfill the global, `globalThis.fetch = fetch`");
}
function makeReadableStream(...args) {
  const ReadableStream = globalThis.ReadableStream;
  if (typeof ReadableStream === "undefined") {
    throw new Error("`ReadableStream` is not defined as a global; You will need to polyfill it, `globalThis.ReadableStream = ReadableStream`");
  }
  return new ReadableStream(...args);
}
function ReadableStreamFrom(iterable) {
  let iter = Symbol.asyncIterator in iterable ? iterable[Symbol.asyncIterator]() : iterable[Symbol.iterator]();
  return makeReadableStream({
    start() {
    },
    async pull(controller) {
      const { done, value } = await iter.next();
      if (done) {
        controller.close();
      } else {
        controller.enqueue(value);
      }
    },
    async cancel() {
      await iter.return?.();
    }
  });
}
function ReadableStreamToAsyncIterable(stream2) {
  if (stream2[Symbol.asyncIterator])
    return stream2;
  const reader = stream2.getReader();
  return {
    async next() {
      try {
        const result = await reader.read();
        if (result?.done)
          reader.releaseLock();
        return result;
      } catch (e) {
        reader.releaseLock();
        throw e;
      }
    },
    async return() {
      const cancelPromise = reader.cancel();
      reader.releaseLock();
      await cancelPromise;
      return { done: true, value: void 0 };
    },
    [Symbol.asyncIterator]() {
      return this;
    }
  };
}
async function CancelReadableStream(stream2) {
  if (stream2 === null || typeof stream2 !== "object")
    return;
  if (stream2[Symbol.asyncIterator]) {
    await stream2[Symbol.asyncIterator]().return?.();
    return;
  }
  const reader = stream2.getReader();
  const cancelPromise = reader.cancel();
  reader.releaseLock();
  await cancelPromise;
}

// node_modules/@anthropic-ai/sdk/internal/request-options.mjs
var FallbackEncoder = ({ headers, body }) => {
  return {
    bodyHeaders: {
      "content-type": "application/json"
    },
    body: JSON.stringify(body)
  };
};

// node_modules/@anthropic-ai/sdk/internal/qs/formats.mjs
var default_format = "RFC3986";
var default_formatter = (v) => String(v);
var formatters = {
  RFC1738: (v) => String(v).replace(/%20/g, "+"),
  RFC3986: default_formatter
};
var RFC1738 = "RFC1738";

// node_modules/@anthropic-ai/sdk/internal/qs/utils.mjs
var has = (obj, key) => (has = Object.hasOwn ?? Function.prototype.call.bind(Object.prototype.hasOwnProperty), has(obj, key));
var hex_table = /* @__PURE__ */ (() => {
  const array = [];
  for (let i = 0; i < 256; ++i) {
    array.push("%" + ((i < 16 ? "0" : "") + i.toString(16)).toUpperCase());
  }
  return array;
})();
var limit = 1024;
var encode = (str, _defaultEncoder, charset, _kind, format) => {
  if (str.length === 0) {
    return str;
  }
  let string = str;
  if (typeof str === "symbol") {
    string = Symbol.prototype.toString.call(str);
  } else if (typeof str !== "string") {
    string = String(str);
  }
  if (charset === "iso-8859-1") {
    return escape(string).replace(/%u[0-9a-f]{4}/gi, function($0) {
      return "%26%23" + parseInt($0.slice(2), 16) + "%3B";
    });
  }
  let out = "";
  for (let j = 0; j < string.length; j += limit) {
    const segment = string.length >= limit ? string.slice(j, j + limit) : string;
    const arr = [];
    for (let i = 0; i < segment.length; ++i) {
      let c = segment.charCodeAt(i);
      if (c === 45 || // -
      c === 46 || // .
      c === 95 || // _
      c === 126 || // ~
      c >= 48 && c <= 57 || // 0-9
      c >= 65 && c <= 90 || // a-z
      c >= 97 && c <= 122 || // A-Z
      format === RFC1738 && (c === 40 || c === 41)) {
        arr[arr.length] = segment.charAt(i);
        continue;
      }
      if (c < 128) {
        arr[arr.length] = hex_table[c];
        continue;
      }
      if (c < 2048) {
        arr[arr.length] = hex_table[192 | c >> 6] + hex_table[128 | c & 63];
        continue;
      }
      if (c < 55296 || c >= 57344) {
        arr[arr.length] = hex_table[224 | c >> 12] + hex_table[128 | c >> 6 & 63] + hex_table[128 | c & 63];
        continue;
      }
      i += 1;
      c = 65536 + ((c & 1023) << 10 | segment.charCodeAt(i) & 1023);
      arr[arr.length] = hex_table[240 | c >> 18] + hex_table[128 | c >> 12 & 63] + hex_table[128 | c >> 6 & 63] + hex_table[128 | c & 63];
    }
    out += arr.join("");
  }
  return out;
};
function is_buffer(obj) {
  if (!obj || typeof obj !== "object") {
    return false;
  }
  return !!(obj.constructor && obj.constructor.isBuffer && obj.constructor.isBuffer(obj));
}
function maybe_map(val, fn) {
  if (isArray(val)) {
    const mapped = [];
    for (let i = 0; i < val.length; i += 1) {
      mapped.push(fn(val[i]));
    }
    return mapped;
  }
  return fn(val);
}

// node_modules/@anthropic-ai/sdk/internal/qs/stringify.mjs
var array_prefix_generators = {
  brackets(prefix) {
    return String(prefix) + "[]";
  },
  comma: "comma",
  indices(prefix, key) {
    return String(prefix) + "[" + key + "]";
  },
  repeat(prefix) {
    return String(prefix);
  }
};
var push_to_array = function(arr, value_or_array) {
  Array.prototype.push.apply(arr, isArray(value_or_array) ? value_or_array : [value_or_array]);
};
var toISOString;
var defaults = {
  addQueryPrefix: false,
  allowDots: false,
  allowEmptyArrays: false,
  arrayFormat: "indices",
  charset: "utf-8",
  charsetSentinel: false,
  delimiter: "&",
  encode: true,
  encodeDotInKeys: false,
  encoder: encode,
  encodeValuesOnly: false,
  format: default_format,
  formatter: default_formatter,
  /** @deprecated */
  indices: false,
  serializeDate(date) {
    return (toISOString ?? (toISOString = Function.prototype.call.bind(Date.prototype.toISOString)))(date);
  },
  skipNulls: false,
  strictNullHandling: false
};
function is_non_nullish_primitive(v) {
  return typeof v === "string" || typeof v === "number" || typeof v === "boolean" || typeof v === "symbol" || typeof v === "bigint";
}
var sentinel = {};
function inner_stringify(object, prefix, generateArrayPrefix, commaRoundTrip, allowEmptyArrays, strictNullHandling, skipNulls, encodeDotInKeys, encoder, filter, sort, allowDots, serializeDate, format, formatter, encodeValuesOnly, charset, sideChannel) {
  let obj = object;
  let tmp_sc = sideChannel;
  let step = 0;
  let find_flag = false;
  while ((tmp_sc = tmp_sc.get(sentinel)) !== void 0 && !find_flag) {
    const pos = tmp_sc.get(object);
    step += 1;
    if (typeof pos !== "undefined") {
      if (pos === step) {
        throw new RangeError("Cyclic object value");
      } else {
        find_flag = true;
      }
    }
    if (typeof tmp_sc.get(sentinel) === "undefined") {
      step = 0;
    }
  }
  if (typeof filter === "function") {
    obj = filter(prefix, obj);
  } else if (obj instanceof Date) {
    obj = serializeDate?.(obj);
  } else if (generateArrayPrefix === "comma" && isArray(obj)) {
    obj = maybe_map(obj, function(value) {
      if (value instanceof Date) {
        return serializeDate?.(value);
      }
      return value;
    });
  }
  if (obj === null) {
    if (strictNullHandling) {
      return encoder && !encodeValuesOnly ? (
        // @ts-expect-error
        encoder(prefix, defaults.encoder, charset, "key", format)
      ) : prefix;
    }
    obj = "";
  }
  if (is_non_nullish_primitive(obj) || is_buffer(obj)) {
    if (encoder) {
      const key_value = encodeValuesOnly ? prefix : encoder(prefix, defaults.encoder, charset, "key", format);
      return [
        formatter?.(key_value) + "=" + // @ts-expect-error
        formatter?.(encoder(obj, defaults.encoder, charset, "value", format))
      ];
    }
    return [formatter?.(prefix) + "=" + formatter?.(String(obj))];
  }
  const values = [];
  if (typeof obj === "undefined") {
    return values;
  }
  let obj_keys;
  if (generateArrayPrefix === "comma" && isArray(obj)) {
    if (encodeValuesOnly && encoder) {
      obj = maybe_map(obj, encoder);
    }
    obj_keys = [{ value: obj.length > 0 ? obj.join(",") || null : void 0 }];
  } else if (isArray(filter)) {
    obj_keys = filter;
  } else {
    const keys = Object.keys(obj);
    obj_keys = sort ? keys.sort(sort) : keys;
  }
  const encoded_prefix = encodeDotInKeys ? String(prefix).replace(/\./g, "%2E") : String(prefix);
  const adjusted_prefix = commaRoundTrip && isArray(obj) && obj.length === 1 ? encoded_prefix + "[]" : encoded_prefix;
  if (allowEmptyArrays && isArray(obj) && obj.length === 0) {
    return adjusted_prefix + "[]";
  }
  for (let j = 0; j < obj_keys.length; ++j) {
    const key = obj_keys[j];
    const value = (
      // @ts-ignore
      typeof key === "object" && typeof key.value !== "undefined" ? key.value : obj[key]
    );
    if (skipNulls && value === null) {
      continue;
    }
    const encoded_key = allowDots && encodeDotInKeys ? key.replace(/\./g, "%2E") : key;
    const key_prefix = isArray(obj) ? typeof generateArrayPrefix === "function" ? generateArrayPrefix(adjusted_prefix, encoded_key) : adjusted_prefix : adjusted_prefix + (allowDots ? "." + encoded_key : "[" + encoded_key + "]");
    sideChannel.set(object, step);
    const valueSideChannel = /* @__PURE__ */ new WeakMap();
    valueSideChannel.set(sentinel, sideChannel);
    push_to_array(values, inner_stringify(
      value,
      key_prefix,
      generateArrayPrefix,
      commaRoundTrip,
      allowEmptyArrays,
      strictNullHandling,
      skipNulls,
      encodeDotInKeys,
      // @ts-ignore
      generateArrayPrefix === "comma" && encodeValuesOnly && isArray(obj) ? null : encoder,
      filter,
      sort,
      allowDots,
      serializeDate,
      format,
      formatter,
      encodeValuesOnly,
      charset,
      valueSideChannel
    ));
  }
  return values;
}
function normalize_stringify_options(opts = defaults) {
  if (typeof opts.allowEmptyArrays !== "undefined" && typeof opts.allowEmptyArrays !== "boolean") {
    throw new TypeError("`allowEmptyArrays` option can only be `true` or `false`, when provided");
  }
  if (typeof opts.encodeDotInKeys !== "undefined" && typeof opts.encodeDotInKeys !== "boolean") {
    throw new TypeError("`encodeDotInKeys` option can only be `true` or `false`, when provided");
  }
  if (opts.encoder !== null && typeof opts.encoder !== "undefined" && typeof opts.encoder !== "function") {
    throw new TypeError("Encoder has to be a function.");
  }
  const charset = opts.charset || defaults.charset;
  if (typeof opts.charset !== "undefined" && opts.charset !== "utf-8" && opts.charset !== "iso-8859-1") {
    throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
  }
  let format = default_format;
  if (typeof opts.format !== "undefined") {
    if (!has(formatters, opts.format)) {
      throw new TypeError("Unknown format option provided.");
    }
    format = opts.format;
  }
  const formatter = formatters[format];
  let filter = defaults.filter;
  if (typeof opts.filter === "function" || isArray(opts.filter)) {
    filter = opts.filter;
  }
  let arrayFormat;
  if (opts.arrayFormat && opts.arrayFormat in array_prefix_generators) {
    arrayFormat = opts.arrayFormat;
  } else if ("indices" in opts) {
    arrayFormat = opts.indices ? "indices" : "repeat";
  } else {
    arrayFormat = defaults.arrayFormat;
  }
  if ("commaRoundTrip" in opts && typeof opts.commaRoundTrip !== "boolean") {
    throw new TypeError("`commaRoundTrip` must be a boolean, or absent");
  }
  const allowDots = typeof opts.allowDots === "undefined" ? !!opts.encodeDotInKeys === true ? true : defaults.allowDots : !!opts.allowDots;
  return {
    addQueryPrefix: typeof opts.addQueryPrefix === "boolean" ? opts.addQueryPrefix : defaults.addQueryPrefix,
    // @ts-ignore
    allowDots,
    allowEmptyArrays: typeof opts.allowEmptyArrays === "boolean" ? !!opts.allowEmptyArrays : defaults.allowEmptyArrays,
    arrayFormat,
    charset,
    charsetSentinel: typeof opts.charsetSentinel === "boolean" ? opts.charsetSentinel : defaults.charsetSentinel,
    commaRoundTrip: !!opts.commaRoundTrip,
    delimiter: typeof opts.delimiter === "undefined" ? defaults.delimiter : opts.delimiter,
    encode: typeof opts.encode === "boolean" ? opts.encode : defaults.encode,
    encodeDotInKeys: typeof opts.encodeDotInKeys === "boolean" ? opts.encodeDotInKeys : defaults.encodeDotInKeys,
    encoder: typeof opts.encoder === "function" ? opts.encoder : defaults.encoder,
    encodeValuesOnly: typeof opts.encodeValuesOnly === "boolean" ? opts.encodeValuesOnly : defaults.encodeValuesOnly,
    filter,
    format,
    formatter,
    serializeDate: typeof opts.serializeDate === "function" ? opts.serializeDate : defaults.serializeDate,
    skipNulls: typeof opts.skipNulls === "boolean" ? opts.skipNulls : defaults.skipNulls,
    // @ts-ignore
    sort: typeof opts.sort === "function" ? opts.sort : null,
    strictNullHandling: typeof opts.strictNullHandling === "boolean" ? opts.strictNullHandling : defaults.strictNullHandling
  };
}
function stringify(object, opts = {}) {
  let obj = object;
  const options = normalize_stringify_options(opts);
  let obj_keys;
  let filter;
  if (typeof options.filter === "function") {
    filter = options.filter;
    obj = filter("", obj);
  } else if (isArray(options.filter)) {
    filter = options.filter;
    obj_keys = filter;
  }
  const keys = [];
  if (typeof obj !== "object" || obj === null) {
    return "";
  }
  const generateArrayPrefix = array_prefix_generators[options.arrayFormat];
  const commaRoundTrip = generateArrayPrefix === "comma" && options.commaRoundTrip;
  if (!obj_keys) {
    obj_keys = Object.keys(obj);
  }
  if (options.sort) {
    obj_keys.sort(options.sort);
  }
  const sideChannel = /* @__PURE__ */ new WeakMap();
  for (let i = 0; i < obj_keys.length; ++i) {
    const key = obj_keys[i];
    if (options.skipNulls && obj[key] === null) {
      continue;
    }
    push_to_array(keys, inner_stringify(
      obj[key],
      key,
      // @ts-expect-error
      generateArrayPrefix,
      commaRoundTrip,
      options.allowEmptyArrays,
      options.strictNullHandling,
      options.skipNulls,
      options.encodeDotInKeys,
      options.encode ? options.encoder : null,
      options.filter,
      options.sort,
      options.allowDots,
      options.serializeDate,
      options.format,
      options.formatter,
      options.encodeValuesOnly,
      options.charset,
      sideChannel
    ));
  }
  const joined = keys.join(options.delimiter);
  let prefix = options.addQueryPrefix === true ? "?" : "";
  if (options.charsetSentinel) {
    if (options.charset === "iso-8859-1") {
      prefix += "utf8=%26%2310003%3B&";
    } else {
      prefix += "utf8=%E2%9C%93&";
    }
  }
  return joined.length > 0 ? prefix + joined : "";
}

// node_modules/@anthropic-ai/sdk/internal/utils/query.mjs
function stringifyQuery(query) {
  return stringify(query, { arrayFormat: "brackets" });
}

// node_modules/@anthropic-ai/sdk/client.mjs
init_error();

// node_modules/@anthropic-ai/sdk/lib/credentials/types.mjs
init_error();
var GRANT_TYPE_JWT_BEARER = "urn:ietf:params:oauth:grant-type:jwt-bearer";
var GRANT_TYPE_REFRESH_TOKEN = "refresh_token";
var TOKEN_ENDPOINT = "/v1/oauth/token";
var OAUTH_API_BETA_HEADER = "oauth-2025-04-20";
var FEDERATION_BETA_HEADER = "oidc-federation-2026-04-01";
var ADVISORY_REFRESH_THRESHOLD_IN_SECONDS = 120;
var MANDATORY_REFRESH_THRESHOLD_IN_SECONDS = 30;
var ADVISORY_REFRESH_BACKOFF_IN_SECONDS = 5;
var MAX_TOKEN_RESPONSE_BYTES = 1 << 20;
function requireSecureTokenEndpoint(baseURL) {
  if (!baseURL)
    return;
  let u;
  try {
    u = new URL(baseURL);
  } catch (err) {
    throw new WorkloadIdentityError(`Invalid token endpoint base URL "${baseURL}": ${err}`);
  }
  if (u.protocol === "https:")
    return;
  const host = u.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (u.protocol === "http:" && (host === "localhost" || host === "127.0.0.1" || host === "::1")) {
    return;
  }
  throw new WorkloadIdentityError(`Refusing to send credential over non-https token endpoint "${baseURL}"`);
}
async function parseTokenResponse(resp, requestId) {
  const text = await readLimitedText(resp);
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new WorkloadIdentityError(`Token endpoint returned non-JSON response (status ${resp.status})`, resp.status, redactSensitive(text), requestId);
  }
  if (!data.access_token) {
    throw new WorkloadIdentityError(`Token endpoint response missing access_token: ${JSON.stringify(redactSensitive(data))}`, resp.status, redactSensitive(data), requestId);
  }
  if (data.token_type && data.token_type.toLowerCase() !== "bearer") {
    throw new WorkloadIdentityError(`Token endpoint response: unsupported token_type "${data.token_type}" (want Bearer)`, resp.status, redactSensitive(data), requestId);
  }
  return data;
}
var MAX_ERROR_BODY_CHARS = 2e3;
var SAFE_ERROR_KEYS = /* @__PURE__ */ new Set(["error", "error_description", "error_uri"]);
function redactSensitive(body) {
  if (body == null)
    return body;
  if (typeof body === "string") {
    let parsed;
    try {
      parsed = JSON.parse(body);
    } catch {
      if (body.length <= MAX_ERROR_BODY_CHARS)
        return body;
      return body.slice(0, MAX_ERROR_BODY_CHARS) + `... <${body.length - MAX_ERROR_BODY_CHARS} more chars>`;
    }
    return JSON.stringify(redactSensitive(parsed));
  }
  if (typeof body === "object" && !Array.isArray(body)) {
    const out = {};
    for (const [k, v] of Object.entries(body)) {
      if (SAFE_ERROR_KEYS.has(k))
        out[k] = v;
    }
    return out;
  }
  return null;
}
async function checkCredentialsFileSafety(path3, onWarn = (m) => console.warn(`anthropic-sdk: ${m}`)) {
  if (typeof process === "undefined" || process.platform === "win32")
    return;
  const { fs: fs2 } = await Promise.resolve().then(() => (init_node_browser(), node_browser_exports));
  let resolved = path3;
  let st;
  try {
    resolved = await fs2.promises.realpath(path3);
    st = await fs2.promises.stat(resolved);
  } catch {
    return;
  }
  const mode = st.mode & 511;
  if (mode & 18) {
    throw new WorkloadIdentityError(`Credentials file at ${resolved} is group/world-writable (mode 0o${mode.toString(8)}); this allows other local users to plant tokens. Run \`chmod 600 ${resolved}\`.`);
  }
  if (mode & 36) {
    throw new WorkloadIdentityError(`Credentials file at ${resolved} is group/world-readable (mode 0o${mode.toString(8)}); run \`chmod 600 ${resolved}\` before retrying.`);
  }
  if (typeof process.getuid === "function" && st.uid !== process.getuid()) {
    onWarn(`credentials file at ${resolved} is owned by uid ${st.uid} (current process uid ${process.getuid()}); verify this is intentional.`);
  }
}
async function writeCredentialsFileAtomic(targetPath, data) {
  const { fs: fs2, path: path3 } = await Promise.resolve().then(() => (init_node_browser(), node_browser_exports));
  const dir = path3.dirname(targetPath);
  await fs2.promises.mkdir(dir, { recursive: true, mode: 448 });
  const tmpPath = `${targetPath}.${process.pid}.${Math.random().toString(36).slice(2)}.tmp`;
  try {
    const fh = await fs2.promises.open(tmpPath, "w", 384);
    try {
      await fh.writeFile(JSON.stringify(data, null, 2));
      await fh.sync();
    } finally {
      await fh.close();
    }
    await fs2.promises.rename(tmpPath, targetPath);
  } catch (err) {
    await fs2.promises.unlink(tmpPath).catch(() => {
    });
    throw err;
  }
  try {
    const dirFh = await fs2.promises.open(dir, "r");
    try {
      await dirFh.sync();
    } finally {
      await dirFh.close();
    }
  } catch {
  }
}
async function readLimitedText(resp) {
  if (!resp.body) {
    return "";
  }
  const reader = resp.body.getReader();
  const chunks = [];
  let received = 0;
  for (; ; ) {
    const { done, value } = await reader.read();
    if (done)
      break;
    if (received + value.length > MAX_TOKEN_RESPONSE_BYTES) {
      const remaining = MAX_TOKEN_RESPONSE_BYTES - received;
      if (remaining > 0)
        chunks.push(value.subarray(0, remaining));
      await reader.cancel();
      break;
    }
    chunks.push(value);
    received += value.length;
  }
  let merged;
  if (chunks.length === 1) {
    merged = chunks[0];
  } else {
    merged = new Uint8Array(chunks.reduce((n, c) => n + c.length, 0));
    let offset = 0;
    for (const c of chunks) {
      merged.set(c, offset);
      offset += c.length;
    }
  }
  return new TextDecoder("utf-8").decode(merged);
}
var WorkloadIdentityError = class extends AnthropicError {
  constructor(message, statusCode = null, body = null, requestId = null) {
    super(message);
    this.statusCode = statusCode;
    this.body = body;
    this.requestId = requestId;
  }
};

// node_modules/@anthropic-ai/sdk/internal/utils/time.mjs
function nowAsSeconds() {
  return Math.floor(Date.now() / 1e3);
}

// node_modules/@anthropic-ai/sdk/lib/credentials/token-cache.mjs
var TokenCache = class {
  constructor(provider, onAdvisoryRefreshError) {
    this.cached = null;
    this.pendingRefresh = null;
    this.nextForce = false;
    this.lastAdvisoryError = 0;
    this.provider = provider;
    this.onAdvisoryRefreshError = onAdvisoryRefreshError;
  }
  async getToken() {
    const force = this.nextForce;
    this.nextForce = false;
    const cached = this.cached;
    if (force || cached == null) {
      const token2 = await this.refresh(force);
      return token2.token;
    }
    if (cached.expiresAt == null) {
      return cached.token;
    }
    const remaining = cached.expiresAt - nowAsSeconds();
    if (remaining > ADVISORY_REFRESH_THRESHOLD_IN_SECONDS) {
      return cached.token;
    }
    if (remaining > MANDATORY_REFRESH_THRESHOLD_IN_SECONDS) {
      this.backgroundRefresh();
      return cached.token;
    }
    const token = await this.refresh();
    return token.token;
  }
  /**
   * Clears the cached token and marks the next {@link getToken} as a forced
   * refresh, so the underlying provider bypasses any on-disk freshness check.
   * Called after a 401 — the server has just told us the token is bad even
   * if its `expires_at` still looks fresh.
   */
  invalidate() {
    this.cached = null;
    this.nextForce = true;
  }
  /**
   * Mandatory refresh. Joins any in-flight refresh unless forced — a forced
   * refresh must not coalesce into a non-forced one that may re-serve the
   * same stale disk token.
   */
  refresh(force = false) {
    if (this.pendingRefresh && !force) {
      return this.pendingRefresh;
    }
    return this.doRefresh(force);
  }
  /**
   * Advisory background refresh. Shares the same in-flight promise as
   * mandatory refreshes for deduplication, but swallows errors so the
   * stale cached token keeps being served. Backs off for
   * {@link ADVISORY_REFRESH_BACKOFF_IN_SECONDS} after a failure so an
   * outage during the advisory window doesn't hammer the token endpoint.
   */
  backgroundRefresh() {
    if (this.pendingRefresh) {
      return;
    }
    if (nowAsSeconds() - this.lastAdvisoryError < ADVISORY_REFRESH_BACKOFF_IN_SECONDS) {
      return;
    }
    this.doRefresh().catch((err) => {
      this.lastAdvisoryError = nowAsSeconds();
      this.onAdvisoryRefreshError?.(err);
    });
  }
  /**
   * Core refresh. Sets {@link pendingRefresh} so concurrent callers
   * (both advisory and mandatory) coalesce into a single provider call.
   */
  doRefresh(force = false) {
    this.pendingRefresh = this.provider(force ? { forceRefresh: true } : void 0).then((token) => {
      this.cached = token;
      this.pendingRefresh = null;
      return token;
    }, (err) => {
      this.pendingRefresh = null;
      throw err;
    });
    return this.pendingRefresh;
  }
};

// node_modules/@anthropic-ai/sdk/internal/utils/env.mjs
var readEnv = (env) => {
  if (typeof globalThis.process !== "undefined") {
    return globalThis.process.env?.[env]?.trim() || void 0;
  }
  if (typeof globalThis.Deno !== "undefined") {
    return globalThis.Deno.env?.get?.(env)?.trim() || void 0;
  }
  return void 0;
};

// node_modules/@anthropic-ai/sdk/internal/utils/base64.mjs
init_error();

// node_modules/@anthropic-ai/sdk/internal/utils/bytes.mjs
function concatBytes(buffers) {
  let length = 0;
  for (const buffer of buffers) {
    length += buffer.length;
  }
  const output = new Uint8Array(length);
  let index = 0;
  for (const buffer of buffers) {
    output.set(buffer, index);
    index += buffer.length;
  }
  return output;
}
var encodeUTF8_;
function encodeUTF8(str) {
  let encoder;
  return (encodeUTF8_ ?? (encoder = new globalThis.TextEncoder(), encodeUTF8_ = encoder.encode.bind(encoder)))(str);
}
var decodeUTF8_;
function decodeUTF8(bytes) {
  let decoder;
  return (decodeUTF8_ ?? (decoder = new globalThis.TextDecoder(), decodeUTF8_ = decoder.decode.bind(decoder)))(bytes);
}

// node_modules/@anthropic-ai/sdk/internal/utils/base64.mjs
var fromBase64 = (str) => {
  if (typeof globalThis.Buffer !== "undefined") {
    const buf = globalThis.Buffer.from(str, "base64");
    return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
  }
  if (typeof atob !== "undefined") {
    const bstr = atob(str);
    const buf = new Uint8Array(bstr.length);
    for (let i = 0; i < bstr.length; i++) {
      buf[i] = bstr.charCodeAt(i);
    }
    return buf;
  }
  throw new AnthropicError("Cannot decode base64 string; Expected `Buffer` or `atob` to be defined");
};

// node_modules/@anthropic-ai/sdk/internal/utils/log.mjs
var defaultLogLevel = "warn";
var levelNumbers = {
  off: 0,
  error: 200,
  warn: 300,
  info: 400,
  debug: 500
};
var parseLogLevel = (maybeLevel, sourceName, logger) => {
  if (!maybeLevel) {
    return void 0;
  }
  if (hasOwn(levelNumbers, maybeLevel)) {
    return maybeLevel;
  }
  logger.warn(`${sourceName} was set to ${JSON.stringify(maybeLevel)}, expected one of ${JSON.stringify(Object.keys(levelNumbers))}`);
  return void 0;
};
function noop() {
}
function makeLogFn(fnLevel, logger, logLevel) {
  if (!logger || levelNumbers[fnLevel] > levelNumbers[logLevel]) {
    return noop;
  } else {
    return logger[fnLevel].bind(logger);
  }
}
var noopLogger = {
  error: noop,
  warn: noop,
  info: noop,
  debug: noop
};
var cachedLoggers = /* @__PURE__ */ new WeakMap();
function filterLogger(logger, logLevel) {
  const cachedLogger = cachedLoggers.get(logger);
  if (cachedLogger && cachedLogger[0] === logLevel) {
    return cachedLogger[1];
  }
  const levelLogger = {
    error: makeLogFn("error", logger, logLevel),
    warn: makeLogFn("warn", logger, logLevel),
    info: makeLogFn("info", logger, logLevel),
    debug: makeLogFn("debug", logger, logLevel)
  };
  cachedLoggers.set(logger, [logLevel, levelLogger]);
  return levelLogger;
}
function loggerFor(client) {
  const logger = client.logger;
  const logLevel = client.logLevel ?? "off";
  if (!logger) {
    return noopLogger;
  }
  return filterLogger(logger, logLevel);
}
var lastEnvLevel;
var cachedDefaultLogger;
function defaultLogger() {
  const envLevel = readEnv("ANTHROPIC_LOG");
  if (!cachedDefaultLogger || envLevel !== lastEnvLevel) {
    lastEnvLevel = envLevel;
    cachedDefaultLogger = filterLogger(console, parseLogLevel(envLevel, "process.env['ANTHROPIC_LOG']", filterLogger(console, defaultLogLevel)) ?? defaultLogLevel);
  }
  return cachedDefaultLogger;
}
function debugLogRequestDetails(logger, message, details) {
  if (logger.debug === noop) {
    return;
  }
  logger.debug(message, formatRequestDetails(details));
}
var formatRequestDetails = (details) => {
  if (details.options) {
    details.options = { ...details.options };
    delete details.options["headers"];
  }
  if (details.headers) {
    details.headers = Object.fromEntries((details.headers instanceof Headers ? [...details.headers] : Object.entries(details.headers)).map(([name, value]) => [
      name,
      name.toLowerCase() === "authorization" || name.toLowerCase() === "api-key" || name.toLowerCase() === "x-api-key" || name.toLowerCase() === "cookie" || name.toLowerCase() === "set-cookie" ? "***" : value
    ]));
  }
  if ("retryOfRequestLogID" in details) {
    if (details.retryOfRequestLogID) {
      details.retryOf = details.retryOfRequestLogID;
    }
    delete details.retryOfRequestLogID;
  }
  return details;
};

// node_modules/@anthropic-ai/sdk/internal/utils/uuid.mjs
var uuid4 = function() {
  const { crypto: crypto2 } = globalThis;
  if (crypto2?.randomUUID) {
    uuid4 = crypto2.randomUUID.bind(crypto2);
    return crypto2.randomUUID();
  }
  const u8 = new Uint8Array(1);
  const randomByte = crypto2 ? () => crypto2.getRandomValues(u8)[0] : () => Math.random() * 255 & 255;
  return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (c) => (+c ^ randomByte() & 15 >> +c / 4).toString(16));
};

// node_modules/@anthropic-ai/sdk/core/credentials.mjs
var CREDENTIALS_FILE_VERSION = "1.0";
var PROFILE_NAME_PATTERN = /^[A-Za-z0-9_.-]+$/;
function validateProfileName(name) {
  if (!name) {
    throw new Error("profile name is empty");
  }
  if (name === "." || name === "..") {
    throw new Error(`profile name "${name}" is not allowed`);
  }
  if (name.includes("/") || name.includes("\\")) {
    throw new Error(`profile name "${name}" must not contain path separators`);
  }
  if (!PROFILE_NAME_PATTERN.test(name)) {
    throw new Error(`profile name "${name}" contains disallowed characters (allowed: letters, digits, '_', '.', '-')`);
  }
}
var loadConfigWithSource = async (profile) => {
  var _a2, _b;
  const rootConfigPath = await getRootConfigPath();
  if (rootConfigPath === null) {
    return null;
  }
  const profileName = profile ?? await getActiveProfileName();
  if (profileName === null) {
    return null;
  }
  validateProfileName(profileName);
  const { fs: fs2, path: path3 } = await Promise.resolve().then(() => (init_node_browser(), node_browser_exports));
  const configPath = path3.join(rootConfigPath, "configs", `${profileName}.json`);
  let configRaw;
  try {
    configRaw = await fs2.promises.readFile(configPath, "utf-8");
  } catch (err) {
    if (err?.code !== "ENOENT") {
      throw new Error(`failed to read config file ${configPath}: ${err}`);
    }
    configRaw = null;
  }
  if (configRaw === null) {
    const organizationId = readEnv("ANTHROPIC_ORGANIZATION_ID");
    const identityTokenFile = readEnv("ANTHROPIC_IDENTITY_TOKEN_FILE");
    const federationRuleId = readEnv("ANTHROPIC_FEDERATION_RULE_ID");
    if (federationRuleId && organizationId) {
      return {
        fromFile: false,
        config: {
          organization_id: organizationId,
          // A defaulted-but-empty CI variable (`ANTHROPIC_WORKSPACE_ID=""`) is
          // treated as unset — readEnv coerces empty to undefined, and the body
          // builder's truthy check skips it — so `"workspace_id": ""` never goes
          // on the wire.
          workspace_id: readEnv("ANTHROPIC_WORKSPACE_ID"),
          base_url: readEnv("ANTHROPIC_BASE_URL"),
          authentication: {
            type: "oidc_federation",
            federation_rule_id: federationRuleId,
            service_account_id: readEnv("ANTHROPIC_SERVICE_ACCOUNT_ID"),
            identity_token: identityTokenFile ? { source: "file", path: identityTokenFile } : void 0,
            scope: readEnv("ANTHROPIC_SCOPE")
          }
        }
      };
    }
    return null;
  }
  let config;
  try {
    config = JSON.parse(configRaw);
  } catch (err) {
    throw new Error(`failed to parse config file ${configPath}: ${err}`);
  }
  if (!config.authentication) {
    throw new Error(`config file ${configPath} is missing "authentication"`);
  }
  const authType = config.authentication.type;
  if (authType !== "oidc_federation" && authType !== "user_oauth") {
    throw new Error(`authentication.type "${authType}" is not a known authentication type`);
  }
  config.organization_id ?? (config.organization_id = readEnv("ANTHROPIC_ORGANIZATION_ID"));
  config.workspace_id ?? (config.workspace_id = readEnv("ANTHROPIC_WORKSPACE_ID"));
  config.base_url ?? (config.base_url = readEnv("ANTHROPIC_BASE_URL"));
  (_a2 = config.authentication).scope ?? (_a2.scope = readEnv("ANTHROPIC_SCOPE"));
  if (config.authentication.type === "oidc_federation") {
    if (!config.authentication.identity_token) {
      const identityTokenFile = readEnv("ANTHROPIC_IDENTITY_TOKEN_FILE");
      if (identityTokenFile) {
        config.authentication.identity_token = {
          source: "file",
          path: identityTokenFile
        };
      }
    }
    if (!config.authentication.federation_rule_id) {
      config.authentication.federation_rule_id = readEnv("ANTHROPIC_FEDERATION_RULE_ID") ?? "";
    }
    (_b = config.authentication).service_account_id ?? (_b.service_account_id = readEnv("ANTHROPIC_SERVICE_ACCOUNT_ID"));
  }
  return { config, fromFile: true };
};
var getCredentialsPath = async (config, profile) => {
  if (config?.authentication.credentials_path) {
    return config.authentication.credentials_path;
  }
  const rootConfigPath = await getRootConfigPath();
  if (!rootConfigPath) {
    return null;
  }
  const profileName = profile ?? await getActiveProfileName();
  if (!profileName) {
    return null;
  }
  validateProfileName(profileName);
  const { path: path3 } = await Promise.resolve().then(() => (init_node_browser(), node_browser_exports));
  return path3.join(rootConfigPath, "credentials", `${profileName}.json`);
};
var getRootConfigPath = async () => {
  if (!supportsLocalConfigFiles()) {
    return null;
  }
  const { path: path3 } = await Promise.resolve().then(() => (init_node_browser(), node_browser_exports));
  const configDir = readEnv("ANTHROPIC_CONFIG_DIR");
  if (configDir) {
    return configDir;
  }
  const os2 = getPlatformHeaders()["X-Stainless-OS"];
  if (os2 === "Windows") {
    const appData = readEnv("APPDATA");
    if (appData) {
      return path3.join(appData, "Anthropic");
    }
    const userProfile = readEnv("USERPROFILE");
    if (userProfile) {
      return path3.join(userProfile, "AppData", "Roaming", "Anthropic");
    }
    return null;
  }
  const xdgConfigHome = readEnv("XDG_CONFIG_HOME");
  if (xdgConfigHome) {
    return path3.join(xdgConfigHome, "anthropic");
  }
  const home = readEnv("HOME");
  if (home) {
    return path3.join(home, ".config", "anthropic");
  }
  return null;
};
var supportsLocalConfigFiles = () => {
  const runtime = getPlatformHeaders()["X-Stainless-Runtime"];
  return runtime === "node" || runtime === "deno";
};
var getActiveProfileName = async () => {
  const rootConfigPath = await getRootConfigPath();
  if (!rootConfigPath) {
    return null;
  }
  const profileName = readEnv("ANTHROPIC_PROFILE");
  if (profileName) {
    return profileName;
  }
  const { fs: fs2, path: path3 } = await Promise.resolve().then(() => (init_node_browser(), node_browser_exports));
  const filePath = path3.join(rootConfigPath, "active_config");
  try {
    return (await fs2.promises.readFile(filePath, "utf-8")).trim() || "default";
  } catch (err) {
    if (err?.code !== "ENOENT") {
      throw new Error(`failed to read ${filePath}: ${err}`);
    }
    return "default";
  }
};

// node_modules/@anthropic-ai/sdk/lib/credentials/identity-token.mjs
init_error();
function identityTokenFromFile(path3) {
  if (!path3) {
    throw new AnthropicError("Identity token file path is empty");
  }
  return async () => {
    const { fs: fs2 } = await Promise.resolve().then(() => (init_node_browser(), node_browser_exports));
    let content;
    try {
      content = await fs2.promises.readFile(path3, "utf-8");
    } catch (err) {
      throw new AnthropicError(`Failed to read identity token file at ${path3}: ${err}`);
    }
    const token = content.trim();
    if (!token) {
      throw new AnthropicError(`Identity token file at ${path3} is empty`);
    }
    return token;
  };
}
function identityTokenFromValue(token) {
  if (!token) {
    throw new AnthropicError("Identity token value is empty");
  }
  return () => token;
}

// node_modules/@anthropic-ai/sdk/lib/credentials/oidc-federation.mjs
function oidcFederationProvider(config) {
  return async () => {
    requireSecureTokenEndpoint(config.baseURL);
    const jwt = await config.identityTokenProvider();
    if (jwt.length > 16 * 1024) {
      throw new WorkloadIdentityError(`Identity token is ${Math.ceil(jwt.length / 1024)} KiB, exceeds the 16 KiB assertion limit`);
    }
    const body = {
      grant_type: GRANT_TYPE_JWT_BEARER,
      assertion: jwt,
      federation_rule_id: config.federationRuleId,
      organization_id: config.organizationId
    };
    if (config.serviceAccountId) {
      body["service_account_id"] = config.serviceAccountId;
    }
    if (config.workspaceId) {
      body["workspace_id"] = config.workspaceId;
    }
    const url = `${config.baseURL}${TOKEN_ENDPOINT}`;
    let resp;
    try {
      resp = await config.fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "anthropic-beta": `${OAUTH_API_BETA_HEADER},${FEDERATION_BETA_HEADER}`,
          "User-Agent": config.userAgent || `anthropic-sdk-typescript/${VERSION} oidcFederationProvider`
        },
        body: JSON.stringify(body)
      });
    } catch (err) {
      throw new WorkloadIdentityError(`Failed to reach token endpoint ${url}: ${err}`);
    }
    const requestId = resp.headers.get("Request-Id");
    if (!resp.ok) {
      const text = await resp.text().catch(() => "");
      const redacted = redactSensitive(text);
      let hint = "";
      if (resp.status === 401) {
        const hintMiddle = config.workspaceId ? "" : "If your federation rule is scoped to multiple workspaces, set the ANTHROPIC_WORKSPACE_ID environment variable, the 'workspace_id' config key, or the `workspaceId` option. ";
        hint = ` Ensure your federation rule matches your identity token. ${hintMiddle}View your authentication events in the Workload identity page of Claude Console for more details.`;
      }
      throw new WorkloadIdentityError(`Token exchange failed with status ${resp.status}${requestId ? ` (request-id ${requestId})` : ""}: ${redacted}${hint}`, resp.status, redacted, requestId);
    }
    const data = await parseTokenResponse(resp, requestId);
    const expiresIn = Number(data.expires_in);
    if (!Number.isFinite(expiresIn)) {
      throw new WorkloadIdentityError(`Token endpoint response missing required fields: ${JSON.stringify(redactSensitive(data))}`, resp.status, redactSensitive(data), requestId);
    }
    return {
      token: data.access_token,
      expiresAt: nowAsSeconds() + expiresIn
    };
  };
}

// node_modules/@anthropic-ai/sdk/lib/credentials/user-oauth.mjs
function userOAuthProvider(config) {
  return async (opts) => {
    const { fs: fs2 } = await Promise.resolve().then(() => (init_node_browser(), node_browser_exports));
    await checkCredentialsFileSafety(config.credentialsPath, config.onSafetyWarning);
    let raw;
    try {
      raw = await fs2.promises.readFile(config.credentialsPath, "utf-8");
    } catch (err) {
      throw new WorkloadIdentityError(`Credentials file not found at ${config.credentialsPath}: ${err}`);
    }
    let creds;
    try {
      creds = JSON.parse(raw);
    } catch (err) {
      throw new WorkloadIdentityError(`Credentials file at ${config.credentialsPath} is not valid JSON: ${err}`);
    }
    const accessToken = creds.access_token;
    if (!accessToken) {
      throw new WorkloadIdentityError(`Credentials file at ${config.credentialsPath} must include 'access_token'`);
    }
    const expiresAt = creds.expires_at;
    if (!opts?.forceRefresh && (expiresAt == null || nowAsSeconds() < expiresAt - MANDATORY_REFRESH_THRESHOLD_IN_SECONDS)) {
      return { token: accessToken, expiresAt: expiresAt ?? null };
    }
    const refreshToken = creds.refresh_token;
    if (!config.clientId || !refreshToken) {
      throw new WorkloadIdentityError(`Access token at ${config.credentialsPath} has expired and no refresh is available (client_id ${config.clientId ? "set" : "empty"}, refresh_token ${refreshToken ? "set" : "empty"})`);
    }
    requireSecureTokenEndpoint(config.baseURL);
    const body = {
      grant_type: GRANT_TYPE_REFRESH_TOKEN,
      refresh_token: refreshToken,
      client_id: config.clientId
    };
    const url = `${config.baseURL}${TOKEN_ENDPOINT}`;
    let resp;
    try {
      resp = await config.fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "anthropic-beta": OAUTH_API_BETA_HEADER,
          "User-Agent": config.userAgent || `anthropic-sdk-typescript/${VERSION} userOAuthProvider`
        },
        body: JSON.stringify(body)
      });
    } catch (err) {
      throw new WorkloadIdentityError(`User OAuth refresh failed to reach token endpoint: ${err}`);
    }
    const requestId = resp.headers.get("Request-Id");
    if (!resp.ok) {
      const text = await resp.text().catch(() => "");
      throw new WorkloadIdentityError(`User OAuth refresh failed (HTTP ${resp.status}): ${redactSensitive(text)}`, resp.status, redactSensitive(text), requestId);
    }
    const data = await parseTokenResponse(resp, requestId);
    const expiresIn = Number(data.expires_in);
    if (!Number.isFinite(expiresIn)) {
      throw new WorkloadIdentityError(`User OAuth refresh response missing or invalid expires_in: ${JSON.stringify(redactSensitive(data))}`, resp.status, redactSensitive(data), requestId);
    }
    const newExpiresAt = nowAsSeconds() + expiresIn;
    const newRefreshToken = data.refresh_token || refreshToken;
    await writeCredentialsFileAtomic(config.credentialsPath, {
      ...creds,
      version: CREDENTIALS_FILE_VERSION,
      type: "oauth_token",
      access_token: data.access_token,
      expires_at: newExpiresAt,
      refresh_token: newRefreshToken
    });
    return { token: data.access_token, expiresAt: newExpiresAt };
  };
}

// node_modules/@anthropic-ai/sdk/lib/credentials/credential-chain.mjs
function resolveCredentialsFromConfig(config, options) {
  const credentialsPath = config.authentication.credentials_path ?? null;
  const effectiveBaseURL = (config.base_url || options.baseURL).replace(/\/+$/, "");
  const provider = buildProvider(config, credentialsPath, effectiveBaseURL, options);
  const extraHeaders = {};
  if (config.workspace_id && config.authentication.type === "user_oauth") {
    extraHeaders["anthropic-workspace-id"] = config.workspace_id;
  }
  return { provider, extraHeaders, baseURL: config.base_url || void 0 };
}
async function defaultCredentials(options, profile) {
  const loaded = await loadConfigWithSource(profile);
  if (!loaded) {
    return null;
  }
  const { config, fromFile } = loaded;
  const withPath = config.authentication.credentials_path || !fromFile ? config : {
    ...config,
    authentication: {
      ...config.authentication,
      credentials_path: await getCredentialsPath(config, profile) ?? void 0
    }
  };
  return resolveCredentialsFromConfig(withPath, options);
}
function buildProvider(config, credentialsPath, baseURL, options) {
  switch (config.authentication.type) {
    case "oidc_federation": {
      const auth = config.authentication;
      const identityProvider = resolveIdentityTokenProvider(auth);
      if (!identityProvider) {
        throw new WorkloadIdentityError("oidc_federation config requires an identity token (set authentication.identity_token, ANTHROPIC_IDENTITY_TOKEN_FILE, or ANTHROPIC_IDENTITY_TOKEN)");
      }
      if (!auth.federation_rule_id) {
        throw new WorkloadIdentityError("oidc_federation config requires 'federation_rule_id'. Set it in authentication.federation_rule_id in your profile, or via ANTHROPIC_FEDERATION_RULE_ID (profile takes precedence).");
      }
      if (!config.organization_id) {
        throw new WorkloadIdentityError("oidc_federation config requires organization_id (set ANTHROPIC_ORGANIZATION_ID or config.organization_id)");
      }
      const exchange = oidcFederationProvider({
        identityTokenProvider: identityProvider,
        federationRuleId: auth.federation_rule_id,
        organizationId: config.organization_id,
        serviceAccountId: auth.service_account_id,
        workspaceId: config.workspace_id,
        baseURL,
        fetch: options.fetch,
        userAgent: options.userAgent
      });
      if (credentialsPath) {
        return cachedExchangeProvider(exchange, credentialsPath, options.onCacheWriteError, options.onSafetyWarning);
      }
      return exchange;
    }
    case "user_oauth": {
      if (!credentialsPath) {
        throw new WorkloadIdentityError("user_oauth config requires authentication.credentials_path (or load via a profile so it defaults to <config_dir>/credentials/<profile>.json)");
      }
      return userOAuthProvider({
        credentialsPath,
        clientId: config.authentication.client_id,
        baseURL,
        fetch: options.fetch,
        userAgent: options.userAgent,
        onSafetyWarning: options.onSafetyWarning
      });
    }
    default: {
      const t = config.authentication.type;
      throw new WorkloadIdentityError(`authentication.type "${t}" is not a known authentication type`);
    }
  }
}
function resolveIdentityTokenProvider(auth) {
  if (auth.identity_token) {
    const source = auth.identity_token.source;
    if (source !== "file") {
      throw new WorkloadIdentityError(`identity_token.source "${source}" is not supported by this SDK version (only "file")`);
    }
    if (!auth.identity_token.path) {
      throw new WorkloadIdentityError(`identity_token.source "file" requires a non-empty path`);
    }
    return identityTokenFromFile(auth.identity_token.path);
  }
  const tokenFile = readEnv("ANTHROPIC_IDENTITY_TOKEN_FILE");
  if (tokenFile) {
    return identityTokenFromFile(tokenFile);
  }
  const tokenValue = readEnv("ANTHROPIC_IDENTITY_TOKEN");
  if (tokenValue) {
    return identityTokenFromValue(tokenValue);
  }
  return null;
}
function cachedExchangeProvider(exchange, credentialsPath, onCacheWriteError, onSafetyWarning) {
  return async (opts) => {
    const { fs: fs2 } = await Promise.resolve().then(() => (init_node_browser(), node_browser_exports));
    await checkCredentialsFileSafety(credentialsPath, onSafetyWarning);
    let existing;
    try {
      const raw = await fs2.promises.readFile(credentialsPath, "utf-8");
      existing = JSON.parse(raw);
      const token = existing?.["access_token"];
      if (token && !opts?.forceRefresh) {
        const expiresAt = existing?.["expires_at"];
        if (expiresAt == null || nowAsSeconds() < expiresAt - MANDATORY_REFRESH_THRESHOLD_IN_SECONDS) {
          return { token, expiresAt: expiresAt ?? null };
        }
      }
    } catch (err) {
      const code = err?.code;
      if (code !== "ENOENT" && !(err instanceof SyntaxError)) {
        onCacheWriteError?.(err);
      }
    }
    const result = await exchange(opts);
    try {
      await writeCredentialsFileAtomic(credentialsPath, {
        ...existing ?? {},
        version: CREDENTIALS_FILE_VERSION,
        type: "oauth_token",
        access_token: result.token,
        expires_at: result.expiresAt
      });
    } catch (err) {
      onCacheWriteError?.(err);
    }
    return result;
  };
}

// node_modules/@anthropic-ai/sdk/core/middleware.mjs
init_errors();

// node_modules/@anthropic-ai/sdk/core/streaming.mjs
init_error();

// node_modules/@anthropic-ai/sdk/internal/decoders/line.mjs
var _LineDecoder_buffer;
var _LineDecoder_carriageReturnIndex;
var LineDecoder = /* @__PURE__ */ (() => {
  class LineDecoder2 {
    constructor() {
      _LineDecoder_buffer.set(this, void 0);
      _LineDecoder_carriageReturnIndex.set(this, void 0);
      __classPrivateFieldSet(this, _LineDecoder_buffer, new Uint8Array(), "f");
      __classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
    }
    decode(chunk) {
      if (chunk == null) {
        return [];
      }
      const binaryChunk = chunk instanceof ArrayBuffer ? new Uint8Array(chunk) : typeof chunk === "string" ? encodeUTF8(chunk) : chunk;
      __classPrivateFieldSet(this, _LineDecoder_buffer, concatBytes([__classPrivateFieldGet(this, _LineDecoder_buffer, "f"), binaryChunk]), "f");
      const lines = [];
      let patternIndex;
      while ((patternIndex = findNewlineIndex(__classPrivateFieldGet(this, _LineDecoder_buffer, "f"), __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f"))) != null) {
        if (patternIndex.carriage && __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") == null) {
          __classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, patternIndex.index, "f");
          continue;
        }
        if (__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") != null && (patternIndex.index !== __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") + 1 || patternIndex.carriage)) {
          lines.push(decodeUTF8(__classPrivateFieldGet(this, _LineDecoder_buffer, "f").subarray(0, __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") - 1)));
          __classPrivateFieldSet(this, _LineDecoder_buffer, __classPrivateFieldGet(this, _LineDecoder_buffer, "f").subarray(__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f")), "f");
          __classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
          continue;
        }
        const endIndex = __classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") !== null ? patternIndex.preceding - 1 : patternIndex.preceding;
        const line = decodeUTF8(__classPrivateFieldGet(this, _LineDecoder_buffer, "f").subarray(0, endIndex));
        lines.push(line);
        __classPrivateFieldSet(this, _LineDecoder_buffer, __classPrivateFieldGet(this, _LineDecoder_buffer, "f").subarray(patternIndex.index), "f");
        __classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
      }
      return lines;
    }
    flush() {
      if (!__classPrivateFieldGet(this, _LineDecoder_buffer, "f").length) {
        return [];
      }
      return this.decode("\n");
    }
  }
  _LineDecoder_buffer = /* @__PURE__ */ new WeakMap(), _LineDecoder_carriageReturnIndex = /* @__PURE__ */ new WeakMap();
  LineDecoder2.NEWLINE_CHARS = /* @__PURE__ */ new Set(["\n", "\r"]);
  LineDecoder2.NEWLINE_REGEXP = /\r\n|[\n\r]/g;
  return LineDecoder2;
})();
function findNewlineIndex(buffer, startIndex) {
  const newline = 10;
  const carriage = 13;
  for (let i = startIndex ?? 0; i < buffer.length; i++) {
    if (buffer[i] === newline) {
      return { preceding: i, index: i + 1, carriage: false };
    }
    if (buffer[i] === carriage) {
      return { preceding: i, index: i + 1, carriage: true };
    }
  }
  return null;
}

// node_modules/@anthropic-ai/sdk/core/streaming.mjs
init_errors();
init_error();
var _Stream_client;
var Stream = /* @__PURE__ */ (() => {
  class Stream2 {
    constructor(iterator, controller, client) {
      this.iterator = iterator;
      _Stream_client.set(this, void 0);
      this.controller = controller;
      __classPrivateFieldSet(this, _Stream_client, client, "f");
    }
    /**
     * Iterate the raw Server-Sent Events from `response` — `{event, data, raw}`
     * objects, before any JSON parsing or event-name filtering.
     *
     * This reads `response.body` directly (not a clone), so the response is
     * consumed. Use this in middleware that fully replaces the stream body; for
     * read-only observation of parsed events, use `ctx.parse()` instead.
     */
    static rawEvents(response, controller = new AbortController()) {
      return _iterSSEMessages(response, controller);
    }
    static fromSSEResponse(response, controller, client) {
      let consumed = false;
      const logger = client ? loggerFor(client) : console;
      async function* iterator() {
        if (consumed) {
          throw new AnthropicError("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
        }
        consumed = true;
        let done = false;
        try {
          for await (const sse of _iterSSEMessages(response, controller)) {
            if (sse.event === "completion") {
              try {
                yield JSON.parse(sse.data);
              } catch (e) {
                logger.error(`Could not parse message into JSON:`, sse.data);
                logger.error(`From chunk:`, sse.raw);
                throw e;
              }
            }
            if (sse.event === "message_start" || sse.event === "message_delta" || sse.event === "message_stop" || sse.event === "content_block_start" || sse.event === "content_block_delta" || sse.event === "content_block_stop" || sse.event === "message" || sse.event === "user.message" || sse.event === "user.interrupt" || sse.event === "user.tool_confirmation" || sse.event === "user.custom_tool_result" || sse.event === "user.tool_result" || sse.event === "agent.message" || sse.event === "agent.thinking" || sse.event === "agent.tool_use" || sse.event === "agent.tool_result" || sse.event === "agent.mcp_tool_use" || sse.event === "agent.mcp_tool_result" || sse.event === "agent.custom_tool_use" || sse.event === "agent.thread_context_compacted" || sse.event === "session.status_running" || sse.event === "session.status_idle" || sse.event === "session.status_rescheduled" || sse.event === "session.status_terminated" || sse.event === "session.error" || sse.event === "session.deleted" || sse.event === "session.updated" || sse.event === "span.model_request_start" || sse.event === "span.model_request_end" || sse.event === "span.outcome_evaluation_start" || sse.event === "span.outcome_evaluation_ongoing" || sse.event === "span.outcome_evaluation_end" || sse.event === "user.define_outcome" || sse.event === "agent.thread_message_received" || sse.event === "agent.thread_message_sent" || sse.event === "agent.session_thread_message_received" || sse.event === "agent.session_thread_message_sent" || sse.event === "session.thread_created" || sse.event === "session.thread_status_created" || sse.event === "session.thread_status_running" || sse.event === "session.thread_status_idle" || sse.event === "session.thread_status_rescheduled" || sse.event === "session.thread_status_terminated" || sse.event === "event_start" || sse.event === "event_delta" || sse.event === "system.message" || sse.event === "workflow_run.created" || sse.event === "workflow_run.status_running" || sse.event === "workflow_run.status_idle" || sse.event === "workflow_run.status_ended" || sse.event === "workflow_run.error" || sse.event === "workflow_run.phase_started" || sse.event === "workflow_run.phase_ended") {
              try {
                yield JSON.parse(sse.data);
              } catch (e) {
                logger.error(`Could not parse message into JSON:`, sse.data);
                logger.error(`From chunk:`, sse.raw);
                throw e;
              }
            }
            if (sse.event === "ping") {
              continue;
            }
            if (sse.event === "error") {
              const body = safeJSON(sse.data) ?? sse.data;
              const type = body?.error?.type;
              throw new APIError(void 0, body, void 0, response.headers, type);
            }
          }
          done = true;
        } catch (e) {
          if (isAbortError(e))
            return;
          throw e;
        } finally {
          if (!done)
            controller.abort();
          releaseRequestSignal(controller);
        }
      }
      return new Stream2(iterator, controller, client);
    }
    /**
     * Generates a Stream from a newline-separated ReadableStream
     * where each item is a JSON value.
     */
    static fromReadableStream(readableStream, controller, client) {
      let consumed = false;
      async function* iterLines() {
        const lineDecoder = new LineDecoder();
        const iter = ReadableStreamToAsyncIterable(readableStream);
        for await (const chunk of iter) {
          for (const line of lineDecoder.decode(chunk)) {
            yield line;
          }
        }
        for (const line of lineDecoder.flush()) {
          yield line;
        }
      }
      async function* iterator() {
        if (consumed) {
          throw new AnthropicError("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
        }
        consumed = true;
        let done = false;
        try {
          for await (const line of iterLines()) {
            if (done)
              continue;
            if (line)
              yield JSON.parse(line);
          }
          done = true;
        } catch (e) {
          if (isAbortError(e))
            return;
          throw e;
        } finally {
          if (!done)
            controller.abort();
          releaseRequestSignal(controller);
        }
      }
      return new Stream2(iterator, controller, client);
    }
    [(_Stream_client = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
      return this.iterator();
    }
    /**
     * Splits the stream into two streams which can be
     * independently read from at different speeds.
     */
    tee() {
      const left = [];
      const right = [];
      const iterator = this.iterator();
      const teeIterator = (queue) => {
        return {
          next: () => {
            if (queue.length === 0) {
              const result = iterator.next();
              left.push(result);
              right.push(result);
            }
            return queue.shift();
          }
        };
      };
      return [
        new Stream2(() => teeIterator(left), this.controller, __classPrivateFieldGet(this, _Stream_client, "f")),
        new Stream2(() => teeIterator(right), this.controller, __classPrivateFieldGet(this, _Stream_client, "f"))
      ];
    }
    /**
     * Converts this stream to a newline-separated ReadableStream of
     * JSON stringified values in the stream
     * which can be turned back into a Stream with `Stream.fromReadableStream()`.
     */
    toReadableStream() {
      const self = this;
      let iter;
      return makeReadableStream({
        async start() {
          iter = self[Symbol.asyncIterator]();
        },
        async pull(ctrl) {
          try {
            const { value, done } = await iter.next();
            if (done)
              return ctrl.close();
            const bytes = encodeUTF8(JSON.stringify(value) + "\n");
            ctrl.enqueue(bytes);
          } catch (err) {
            ctrl.error(err);
          }
        },
        async cancel() {
          await iter.return?.();
        }
      });
    }
  }
  return Stream2;
})();
async function* _iterSSEMessages(response, controller) {
  if (!response.body) {
    controller.abort();
    if (typeof globalThis.navigator !== "undefined" && globalThis.navigator.product === "ReactNative") {
      throw new AnthropicError(`The default react-native fetch implementation does not support streaming. Please use expo/fetch: https://docs.expo.dev/versions/latest/sdk/expo/#expofetch-api`);
    }
    throw new AnthropicError(`Attempted to iterate over a response with no body`);
  }
  const sseDecoder = new SSEDecoder();
  const lineDecoder = new LineDecoder();
  const iter = ReadableStreamToAsyncIterable(response.body);
  for await (const chunk of iter) {
    for (const line of lineDecoder.decode(chunk)) {
      const sse = sseDecoder.decode(line);
      if (sse)
        yield sse;
    }
  }
  for (const line of lineDecoder.flush()) {
    const sse = sseDecoder.decode(line);
    if (sse)
      yield sse;
  }
}
var SSEDecoder = class {
  constructor() {
    this.event = null;
    this.data = [];
    this.chunks = [];
  }
  decode(line) {
    if (line.endsWith("\r")) {
      line = line.substring(0, line.length - 1);
    }
    if (!line) {
      if (!this.event && !this.data.length)
        return null;
      const sse = {
        event: this.event,
        data: this.data.join("\n"),
        raw: this.chunks
      };
      this.event = null;
      this.data = [];
      this.chunks = [];
      return sse;
    }
    this.chunks.push(line);
    if (line.startsWith(":")) {
      return null;
    }
    let [fieldname, _, value] = partition(line, ":");
    if (value.startsWith(" ")) {
      value = value.substring(1);
    }
    if (fieldname === "event") {
      this.event = value;
    } else if (fieldname === "data") {
      this.data.push(value);
    }
    return null;
  }
};
function partition(str, delimiter) {
  const index = str.indexOf(delimiter);
  if (index !== -1) {
    return [str.substring(0, index), delimiter, str.substring(index + delimiter.length)];
  }
  return [str, "", ""];
}

// node_modules/@anthropic-ai/sdk/internal/parse.mjs
async function defaultParseResponse(client, props) {
  const { response, requestLogID, retryOfRequestLogID, startTime } = props;
  const body = await (async () => {
    if (props.options.stream) {
      loggerFor(client).debug("response", response.status, response.url, response.headers, response.body);
      return Stream.fromSSEResponse(response, props.controller, client);
    }
    if (response.status === 204) {
      return null;
    }
    if (props.options.__binaryResponse) {
      return response;
    }
    const contentType = response.headers.get("content-type");
    const mediaType = contentType?.split(";")[0]?.trim();
    const isJSON = mediaType?.includes("application/json") || mediaType?.endsWith("+json");
    if (isJSON) {
      const contentLength = response.headers.get("content-length");
      if (contentLength === "0") {
        return void 0;
      }
      const json2 = await response.json();
      return addResponseIDs(json2, response);
    }
    const text = await response.text();
    return text;
  })().finally(() => {
    if (!props.options.stream && !props.options.__binaryResponse) {
      releaseRequestSignal(props.controller);
    }
  });
  debugLogRequestDetails(loggerFor(client), `[${requestLogID}] response parsed`, {
    retryOfRequestLogID,
    url: response.url,
    status: response.status,
    body,
    durationMs: Date.now() - startTime
  });
  return body;
}
function addResponseIDs(value, response) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return value;
  }
  return Object.defineProperties(value, {
    _request_id: { value: response.headers.get("request-id"), enumerable: false },
    _workspace_id: { value: response.headers.get("anthropic-workspace-id"), enumerable: false }
  });
}

// node_modules/@anthropic-ai/sdk/core/middleware.mjs
init_error();
var fetchOriginErrors = /* @__PURE__ */ new WeakSet();
function isFetchOriginError(err) {
  return typeof err === "object" && err !== null && fetchOriginErrors.has(err);
}
function isRetryableError(err) {
  const seen = /* @__PURE__ */ new Set();
  while (typeof err === "object" && err !== null && !seen.has(err)) {
    seen.add(err);
    if (isFetchOriginError(err) || isAbortError(err) || err instanceof APIConnectionError || err instanceof RetryableError) {
      return true;
    }
    err = err.cause;
  }
  return false;
}
function wrapFetchWithMiddleware(fetchFn, middleware, options, client) {
  return async (url, init = {}) => {
    if (middleware.length === 0) {
      return fetchFn.call(void 0, url, init);
    }
    const headers = init.headers instanceof Headers ? init.headers : new Headers(init.headers);
    const response = await applyMiddleware(fetchFn, middleware, options, client)({
      ...init,
      headers,
      url: typeof url === "string" ? url : url instanceof URL ? url.href : url.url
    });
    if (response.bodyUsed || response.body?.locked) {
      throw new AnthropicError("middleware consumed the response body; use response.clone() to inspect it, or return new Response(body, response) to consume and replace it");
    }
    return response;
  };
}
function createMiddlewareContext(options, client) {
  const cache = /* @__PURE__ */ new WeakMap();
  return {
    options,
    // Resolved per chain, so changes to the client's `logLevel`/`logger`
    // apply to subsequent requests.
    logger: client ? loggerFor(client) : defaultLogger(),
    parse(response) {
      if (options?.stream && response.ok) {
        return parseMiddlewareResponse(response, options, client);
      }
      let parsed = cache.get(response);
      if (!parsed) {
        parsed = parseMiddlewareResponse(response, options, client);
        cache.set(response, parsed);
      }
      return parsed;
    }
  };
}
async function parseMiddlewareResponse(response, options, client) {
  if (response.bodyUsed || response.body?.locked) {
    throw new AnthropicError("cannot ctx.parse() a response whose body was already consumed; call ctx.parse() instead of reading the body, or read via response.clone()");
  }
  if (options?.stream && response.ok) {
    return Stream.fromSSEResponse(response.clone(), new AbortController(), client);
  }
  if (response.status === 204) {
    return null;
  }
  if (options?.__binaryResponse) {
    return response;
  }
  const contentType = response.headers.get("content-type");
  const mediaType = contentType?.split(";")[0]?.trim();
  const isJSON = mediaType?.includes("application/json") || mediaType?.endsWith("+json");
  if (isJSON) {
    if (response.headers.get("content-length") === "0") {
      return void 0;
    }
    return addResponseIDs(await response.clone().json(), response);
  }
  return await response.clone().text();
}
function applyMiddleware(fetchFn, middleware, options, client) {
  let next = async ({ url, ...init }) => {
    try {
      return await fetchFn.call(void 0, url, init);
    } catch (err) {
      const error = castToError(err);
      fetchOriginErrors.add(error);
      throw error;
    }
  };
  const ctx = createMiddlewareContext(options, client);
  for (let i = middleware.length - 1; i >= 0; i--) {
    const mw = middleware[i];
    const nextInner = next;
    next = async (request) => mw(request, nextInner, ctx);
  }
  return next;
}

// node_modules/@anthropic-ai/sdk/core/pagination.mjs
init_error();

// node_modules/@anthropic-ai/sdk/core/api-promise.mjs
var _APIPromise_client;
var APIPromise = /* @__PURE__ */ (() => {
  class APIPromise2 extends Promise {
    constructor(client, responsePromise, parseResponse = defaultParseResponse) {
      super((resolve) => {
        resolve(null);
      });
      this.responsePromise = responsePromise;
      this.parseResponse = parseResponse;
      _APIPromise_client.set(this, void 0);
      __classPrivateFieldSet(this, _APIPromise_client, client, "f");
    }
    _thenUnwrap(transform) {
      return new APIPromise2(__classPrivateFieldGet(this, _APIPromise_client, "f"), this.responsePromise, async (client, props) => addResponseIDs(transform(await this.parseResponse(client, props), props), props.response));
    }
    /**
     * Gets the raw `Response` instance instead of parsing the response
     * data.
     *
     * If you want to parse the response body but still get the `Response`
     * instance, you can use {@link withResponse()}.
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` or add `"lib": ["DOM"]`
     * to your `tsconfig.json`.
     */
    asResponse() {
      return this.responsePromise.then((p) => p.response);
    }
    /**
     * Gets the parsed response data, the raw `Response` instance and the ID of the request,
     * returned via the `request-id` header which is useful for debugging requests and resporting
     * issues to Anthropic.
     *
     * If you just want to get the raw `Response` instance without parsing it,
     * you can use {@link asResponse()}.
     *
     * 👋 Getting the wrong TypeScript type for `Response`?
     * Try setting `"moduleResolution": "NodeNext"` or add `"lib": ["DOM"]`
     * to your `tsconfig.json`.
     */
    async withResponse() {
      const [data, response] = await Promise.all([this.parse(), this.asResponse()]);
      return {
        data,
        response,
        request_id: response.headers.get("request-id"),
        workspace_id: response.headers.get("anthropic-workspace-id")
      };
    }
    parse() {
      if (!this.parsedPromise) {
        this.parsedPromise = this.responsePromise.then((data) => this.parseResponse(__classPrivateFieldGet(this, _APIPromise_client, "f"), data));
      }
      return this.parsedPromise;
    }
    then(onfulfilled, onrejected) {
      return this.parse().then(onfulfilled, onrejected);
    }
    catch(onrejected) {
      return this.parse().catch(onrejected);
    }
    finally(onfinally) {
      return this.parse().finally(onfinally);
    }
  }
  _APIPromise_client = /* @__PURE__ */ new WeakMap();
  return APIPromise2;
})();

// node_modules/@anthropic-ai/sdk/core/pagination.mjs
var _AbstractPage_client;
var AbstractPage = /* @__PURE__ */ (() => {
  class AbstractPage2 {
    constructor(client, response, body, options) {
      _AbstractPage_client.set(this, void 0);
      __classPrivateFieldSet(this, _AbstractPage_client, client, "f");
      this.options = options;
      this.response = response;
      this.body = body;
    }
    hasNextPage() {
      const items = this.getPaginatedItems();
      if (!items.length)
        return false;
      return this.nextPageRequestOptions() != null;
    }
    async getNextPage() {
      const nextOptions = this.nextPageRequestOptions();
      if (!nextOptions) {
        throw new AnthropicError("No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.");
      }
      return await __classPrivateFieldGet(this, _AbstractPage_client, "f").requestAPIList(this.constructor, nextOptions);
    }
    async *iterPages() {
      let page = this;
      yield page;
      while (page.hasNextPage()) {
        page = await page.getNextPage();
        yield page;
      }
    }
    async *[(_AbstractPage_client = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
      for await (const page of this.iterPages()) {
        for (const item of page.getPaginatedItems()) {
          yield item;
        }
      }
    }
  }
  return AbstractPage2;
})();
var PagePromise = /* @__PURE__ */ (() => {
  class PagePromise2 extends APIPromise {
    constructor(client, request, Page2) {
      super(client, request, async (client2, props) => new Page2(client2, props.response, await defaultParseResponse(client2, props), props.options));
    }
    /**
     * Allow auto-paginating iteration on an unawaited list call, eg:
     *
     *    for await (const item of client.items.list()) {
     *      console.log(item)
     *    }
     */
    async *[Symbol.asyncIterator]() {
      const page = await this;
      for await (const item of page) {
        yield item;
      }
    }
  }
  return PagePromise2;
})();
var Page = class extends AbstractPage {
  constructor(client, response, body, options) {
    super(client, response, body, options);
    this.data = body.data || [];
    this.has_more = body.has_more || false;
    this.first_id = body.first_id || null;
    this.last_id = body.last_id || null;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    if (this.has_more === false) {
      return false;
    }
    return super.hasNextPage();
  }
  nextPageRequestOptions() {
    if (this.options.query?.["before_id"]) {
      const first_id = this.first_id;
      if (!first_id) {
        return null;
      }
      return {
        ...this.options,
        query: {
          ...maybeObj(this.options.query),
          before_id: first_id
        }
      };
    }
    const cursor = this.last_id;
    if (!cursor) {
      return null;
    }
    return {
      ...this.options,
      query: {
        ...maybeObj(this.options.query),
        after_id: cursor
      }
    };
  }
};
var PageCursor = class extends AbstractPage {
  constructor(client, response, body, options) {
    super(client, response, body, options);
    this.data = body.data || [];
    this.next_page = body.next_page || null;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    return this.nextPageRequestOptions() != null;
  }
  nextPageRequestOptions() {
    const cursor = this.next_page;
    if (!cursor) {
      return null;
    }
    return {
      ...this.options,
      query: {
        ...maybeObj(this.options.query),
        page: cursor
      }
    };
  }
};
var BidirectionalPageCursor = class extends AbstractPage {
  constructor(client, response, body, options) {
    super(client, response, body, options);
    this.data = body.data || [];
    this.next_page = body.next_page || null;
    this.prev_page = body.prev_page || null;
  }
  getPaginatedItems() {
    return this.data ?? [];
  }
  hasNextPage() {
    return this.nextPageRequestOptions() != null;
  }
  nextPageRequestOptions() {
    const cursor = this.next_page;
    if (!cursor) {
      return null;
    }
    return {
      ...this.options,
      query: {
        ...maybeObj(this.options.query),
        page: cursor
      }
    };
  }
};

// node_modules/@anthropic-ai/sdk/internal/uploads.mjs
var checkFileSupport = () => {
  if (typeof File === "undefined") {
    const { process: process2 } = globalThis;
    const isOldNode = typeof process2?.versions?.node === "string" && parseInt(process2.versions.node.split(".")) < 20;
    throw new Error("`File` is not defined as a global, which is required for file uploads." + (isOldNode ? " Update to Node 20 LTS or newer, or set `globalThis.File` to `import('node:buffer').File`." : ""));
  }
};
function makeFile(fileBits, fileName, options) {
  checkFileSupport();
  return new File(fileBits, fileName ?? "", options);
}
function getName(value, stripPath) {
  const val = typeof value === "object" && value !== null && ("name" in value && value.name && String(value.name) || "url" in value && value.url && String(value.url) || "filename" in value && value.filename && String(value.filename) || "path" in value && value.path && String(value.path)) || "";
  return stripPath ? val.split(/[\\/]/).pop() || void 0 : val;
}
var isAsyncIterable = (value) => value != null && typeof value === "object" && typeof value[Symbol.asyncIterator] === "function";
var multipartFormRequestOptions = async (opts, fetch2, stripFilenames = true) => {
  return { ...opts, body: await createForm(opts.body, fetch2, stripFilenames) };
};
var supportsFormDataMap = /* @__PURE__ */ new WeakMap();
function supportsFormData(fetchObject) {
  const fetch2 = typeof fetchObject === "function" ? fetchObject : fetchObject.fetch;
  const cached = supportsFormDataMap.get(fetch2);
  if (cached)
    return cached;
  const promise = (async () => {
    try {
      const FetchResponse = "Response" in fetch2 ? fetch2.Response : (await fetch2("data:,")).constructor;
      const data = new FormData();
      if (data.toString() === await new FetchResponse(data).text()) {
        return false;
      }
      return true;
    } catch {
      return true;
    }
  })();
  supportsFormDataMap.set(fetch2, promise);
  return promise;
}
var createForm = async (body, fetch2, stripFilenames = true) => {
  if (!await supportsFormData(fetch2)) {
    throw new TypeError("The provided fetch function does not support file uploads with the current global FormData class.");
  }
  const form = new FormData();
  await Promise.all(Object.entries(body || {}).map(([key, value]) => addFormValue(form, key, value, stripFilenames)));
  return form;
};
var addFormValue = async (form, key, value, stripFilenames) => {
  if (value === void 0)
    return;
  if (value == null) {
    throw new TypeError(`Received null for "${key}"; to pass null in FormData, you must use the string 'null'`);
  }
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    form.append(key, String(value));
  } else if (value instanceof Response) {
    let options = {};
    const contentType = value.headers.get("Content-Type");
    if (contentType) {
      options = { type: contentType };
    }
    form.append(key, makeFile([await value.blob()], getName(value, stripFilenames), options));
  } else if (isAsyncIterable(value)) {
    form.append(key, makeFile([await new Response(ReadableStreamFrom(value)).blob()], getName(value, stripFilenames)));
  } else if (value instanceof Blob) {
    const isFile = typeof File !== "undefined" && value instanceof File;
    const name = isFile ? value.name : getName(value, stripFilenames);
    form.append(key, makeFile([value], name, { type: value.type }));
  } else if (Array.isArray(value)) {
    await Promise.all(value.map((entry) => addFormValue(form, key + "[]", entry, stripFilenames)));
  } else if (typeof value.then === "function") {
    throw new TypeError(`Received a Promise for "${key}"; await it first, e.g. \`await toFile(...)\``);
  } else if (value instanceof ArrayBuffer || ArrayBuffer.isView(value)) {
    throw new TypeError(`Received ${value.constructor.name} for "${key}"; to upload raw bytes, wrap them with \`await toFile(bytes, 'filename')\``);
  } else if (typeof value === "object") {
    await Promise.all(Object.entries(value).map(([name, prop]) => addFormValue(form, `${key}[${name}]`, prop, stripFilenames)));
  } else {
    throw new TypeError(`Invalid value given to form, expected a string, number, boolean, object, Array, File or Blob but got ${value} instead`);
  }
};

// node_modules/@anthropic-ai/sdk/internal/to-file.mjs
var isBlobLike = (value) => value != null && typeof value === "object" && typeof value.size === "number" && typeof value.type === "string" && typeof value.text === "function" && typeof value.slice === "function" && typeof value.arrayBuffer === "function";
var isFileLike = (value) => value != null && typeof value === "object" && typeof value.name === "string" && typeof value.lastModified === "number" && isBlobLike(value);
var isResponseLike = (value) => value != null && typeof value === "object" && typeof value.url === "string" && typeof value.blob === "function";
async function toFile(value, name, options) {
  checkFileSupport();
  value = await value;
  name || (name = value instanceof File ? value.name : getName(value, true));
  if (isFileLike(value)) {
    if (value instanceof File && name == null && options == null) {
      return value;
    }
    return makeFile([await value.arrayBuffer()], name ?? value.name, {
      type: value.type,
      lastModified: value.lastModified,
      ...options
    });
  }
  if (isResponseLike(value)) {
    const blob = await value.blob();
    name || (name = new URL(value.url).pathname.split(/[\\/]/).pop());
    return makeFile(await getBytes(blob), name, options);
  }
  const parts = await getBytes(value);
  if (!options?.type) {
    const type = parts.find((part) => typeof part === "object" && "type" in part && part.type);
    if (typeof type === "string") {
      options = { ...options, type };
    }
  }
  return makeFile(parts, name, options);
}
async function getBytes(value) {
  let parts = [];
  if (typeof value === "string" || ArrayBuffer.isView(value) || // includes Uint8Array, Buffer, etc.
  value instanceof ArrayBuffer) {
    parts.push(value);
  } else if (isBlobLike(value)) {
    parts.push(value instanceof Blob ? value : await value.arrayBuffer());
  } else if (isAsyncIterable(value)) {
    for await (const chunk of value) {
      parts.push(...await getBytes(chunk));
    }
  } else {
    const constructor = value?.constructor?.name;
    throw new Error(`Unexpected data type: ${typeof value}${constructor ? `; constructor: ${constructor}` : ""}${propsForError(value)}`);
  }
  return parts;
}
function propsForError(value) {
  if (typeof value !== "object" || value === null)
    return "";
  const props = Object.getOwnPropertyNames(value);
  return `; props: [${props.map((p) => `"${p}"`).join(", ")}]`;
}

// node_modules/@anthropic-ai/sdk/core/resource.mjs
var APIResource = class {
  constructor(client) {
    this._client = client;
  }
};

// node_modules/@anthropic-ai/sdk/internal/headers.mjs
var brand_privateNullableHeaders = /* @__PURE__ */ Symbol.for("brand.privateNullableHeaders");
function* iterateHeaders(headers) {
  if (!headers)
    return;
  if (brand_privateNullableHeaders in headers) {
    const { values, nulls } = headers;
    yield* values.entries();
    for (const name of nulls) {
      yield [name, null];
    }
    return;
  }
  let shouldClear = false;
  let iter;
  if (headers instanceof Headers) {
    iter = headers.entries();
  } else if (isReadonlyArray(headers)) {
    iter = headers;
  } else {
    shouldClear = true;
    iter = Object.entries(headers ?? {});
  }
  for (let row of iter) {
    const name = row[0];
    if (typeof name !== "string")
      throw new TypeError("expected header name to be a string");
    const values = isReadonlyArray(row[1]) ? row[1] : [row[1]];
    let didClear = false;
    for (const value of values) {
      if (value === void 0)
        continue;
      if (shouldClear && !didClear) {
        didClear = true;
        yield [name, clearSentinel];
      }
      yield [name, value];
    }
  }
}
var clearSentinel = /* @__PURE__ */ Symbol("clear");
var APPEND_HEADERS = /* @__PURE__ */ new Set(["x-stainless-helper"]);
var appendHeaderValue = (existing, addition) => {
  const tokens = existing ? existing.split(",").map((t) => t.trim()).filter(Boolean) : [];
  for (const tok of addition.split(",").map((t) => t.trim())) {
    if (tok && !tokens.includes(tok))
      tokens.push(tok);
  }
  return tokens.join(", ");
};
var buildHeaders = (newHeaders) => {
  const targetHeaders = new Headers();
  const nullHeaders = /* @__PURE__ */ new Set();
  for (const headers of newHeaders) {
    const seenHeaders = /* @__PURE__ */ new Set();
    for (const [name, value] of iterateHeaders(headers)) {
      const lowerName = name.toLowerCase();
      if (APPEND_HEADERS.has(lowerName)) {
        if (value === clearSentinel)
          continue;
        if (value === null) {
          targetHeaders.delete(name);
          nullHeaders.add(lowerName);
        } else {
          targetHeaders.set(name, appendHeaderValue(targetHeaders.get(name), value));
          nullHeaders.delete(lowerName);
        }
        continue;
      }
      if (value === clearSentinel || !seenHeaders.has(lowerName)) {
        targetHeaders.delete(name);
        seenHeaders.add(lowerName);
        if (value === clearSentinel)
          continue;
      }
      if (value === null) {
        targetHeaders.delete(name);
        nullHeaders.add(lowerName);
      } else {
        targetHeaders.append(name, value);
        nullHeaders.delete(lowerName);
      }
    }
  }
  return { [brand_privateNullableHeaders]: true, values: targetHeaders, nulls: nullHeaders };
};

// node_modules/@anthropic-ai/sdk/internal/stainless-helper-header.mjs
var STAINLESS_HELPER_HEADER = "x-stainless-helper";
var STAINLESS_HELPER_METHOD_HEADER = "x-stainless-helper-method";
function helperHeader(value) {
  return { [STAINLESS_HELPER_HEADER]: value };
}
var SDK_HELPER_SYMBOL = /* @__PURE__ */ Symbol("anthropic.sdk.stainlessHelper");
function wasCreatedByStainlessHelper(value) {
  return typeof value === "object" && value !== null && SDK_HELPER_SYMBOL in value;
}
function collectStainlessHelpers(tools, messages) {
  const helpers = /* @__PURE__ */ new Set();
  if (tools) {
    for (const tool of tools) {
      if (wasCreatedByStainlessHelper(tool)) {
        helpers.add(tool[SDK_HELPER_SYMBOL]);
      }
    }
  }
  if (messages) {
    for (const message of messages) {
      if (wasCreatedByStainlessHelper(message)) {
        helpers.add(message[SDK_HELPER_SYMBOL]);
      }
      const content = message.content;
      if (Array.isArray(content)) {
        for (const block of content) {
          if (wasCreatedByStainlessHelper(block)) {
            helpers.add(block[SDK_HELPER_SYMBOL]);
          }
          const definition = block?.tool?.definition;
          if (wasCreatedByStainlessHelper(definition)) {
            helpers.add(definition[SDK_HELPER_SYMBOL]);
          }
        }
      }
    }
  }
  return Array.from(helpers);
}
function stainlessHelperHeader(tools, messages) {
  const helpers = collectStainlessHelpers(tools, messages);
  if (helpers.length === 0)
    return {};
  return { [STAINLESS_HELPER_HEADER]: helpers.join(", ") };
}
function stainlessHelperHeaderFromFile(file) {
  if (wasCreatedByStainlessHelper(file)) {
    return { [STAINLESS_HELPER_HEADER]: file[SDK_HELPER_SYMBOL] };
  }
  return {};
}

// node_modules/@anthropic-ai/sdk/lib/MessageStream.mjs
init_errors();

// node_modules/@anthropic-ai/sdk/lib/parser.mjs
init_error();
function getOutputFormat(params) {
  return params?.output_config?.format;
}
function maybeParseMessage(message, params, opts) {
  const outputFormat = getOutputFormat(params);
  if (!params || !("parse" in (outputFormat ?? {}))) {
    return {
      ...message,
      content: message.content.map((block) => {
        if (block.type === "text") {
          const parsedBlock = Object.defineProperty({ ...block }, "parsed_output", {
            value: null,
            enumerable: false
          });
          return parsedBlock;
        }
        return block;
      }),
      parsed_output: null
    };
  }
  return parseMessage(message, params, opts);
}
function parseMessage(message, params, opts) {
  let firstParsedOutput = null;
  const content = message.content.map((block) => {
    if (block.type === "text") {
      const parsedOutput = parseOutputFormat(params, block.text);
      if (firstParsedOutput === null) {
        firstParsedOutput = parsedOutput;
      }
      const parsedBlock = Object.defineProperty({ ...block }, "parsed_output", {
        value: parsedOutput,
        enumerable: false
      });
      return parsedBlock;
    }
    return block;
  });
  return {
    ...message,
    content,
    parsed_output: firstParsedOutput
  };
}
function parseOutputFormat(params, content) {
  const outputFormat = getOutputFormat(params);
  if (outputFormat?.type !== "json_schema") {
    return null;
  }
  try {
    if ("parse" in outputFormat) {
      return outputFormat.parse(content);
    }
    return JSON.parse(content);
  } catch (error) {
    throw new AnthropicError(`Failed to parse structured output: ${error}`);
  }
}

// node_modules/@anthropic-ai/sdk/_vendor/partial-json-parser/parser.mjs
var tokenize = (input) => {
  let current = 0;
  let tokens = [];
  while (current < input.length) {
    let char = input[current];
    if (char === "\\") {
      current++;
      continue;
    }
    if (char === "{") {
      tokens.push({
        type: "brace",
        value: "{"
      });
      current++;
      continue;
    }
    if (char === "}") {
      tokens.push({
        type: "brace",
        value: "}"
      });
      current++;
      continue;
    }
    if (char === "[") {
      tokens.push({
        type: "paren",
        value: "["
      });
      current++;
      continue;
    }
    if (char === "]") {
      tokens.push({
        type: "paren",
        value: "]"
      });
      current++;
      continue;
    }
    if (char === ":") {
      tokens.push({
        type: "separator",
        value: ":"
      });
      current++;
      continue;
    }
    if (char === ",") {
      tokens.push({
        type: "delimiter",
        value: ","
      });
      current++;
      continue;
    }
    if (char === '"') {
      const start = current + 1;
      let end = start;
      let danglingQuote = false;
      while (true) {
        end = input.indexOf('"', end);
        if (end === -1) {
          danglingQuote = true;
          break;
        }
        let backslashes = 0;
        let i = end - 1;
        while (i >= start && input[i] === "\\") {
          backslashes++;
          i--;
        }
        if (backslashes % 2 === 0)
          break;
        end++;
      }
      if (danglingQuote) {
        current = input.length;
      } else {
        tokens.push({
          type: "string",
          value: input.slice(start, end)
        });
        current = end + 1;
      }
      continue;
    }
    let WHITESPACE = /\s/;
    if (char && WHITESPACE.test(char)) {
      current++;
      continue;
    }
    let NUMBERS = /[0-9]/;
    if (char && NUMBERS.test(char) || char === "-" || char === ".") {
      let value = "";
      if (char === "-") {
        value += char;
        char = input[++current];
      }
      while (char && (NUMBERS.test(char) || char === "." || // exponent marker, e.g. `1e10` or `1.5E-9`
      char === "e" || char === "E" || // exponent sign, only valid immediately after the exponent marker
      (char === "-" || char === "+") && (value[value.length - 1] === "e" || value[value.length - 1] === "E"))) {
        value += char;
        char = input[++current];
      }
      tokens.push({
        type: "number",
        value,
        unterminated: current === input.length
      });
      continue;
    }
    let LETTERS = /[a-z]/i;
    if (char && LETTERS.test(char)) {
      let value = "";
      while (char && LETTERS.test(char)) {
        if (current === input.length) {
          break;
        }
        value += char;
        char = input[++current];
      }
      if (value == "true" || value == "false" || value === "null") {
        tokens.push({
          type: "name",
          value
        });
      } else {
        current++;
        continue;
      }
      continue;
    }
    current++;
  }
  return tokens;
};
var strip = (tokens) => {
  let open = [];
  for (const token of tokens) {
    if (token.type === "brace" || token.type === "paren") {
      if (token.value === "{" || token.value === "[") {
        open.push(token.value);
      } else {
        open.pop();
      }
    }
  }
  let innermostOpenBracket = open[open.length - 1];
  let length = tokens.length;
  let JSON_NUMBER = /^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][-+]?[0-9]+)?$/;
  while (length > 0) {
    let lastToken = tokens[length - 1];
    switch (lastToken.type) {
      case "separator":
        length--;
        continue;
      case "number":
        if (lastToken.unterminated || !JSON_NUMBER.test(lastToken.value)) {
          length--;
          continue;
        }
        break;
      case "string":
        let tokenBeforeTheLastToken = tokens[length - 2];
        if (innermostOpenBracket === "{" && (tokenBeforeTheLastToken?.type === "delimiter" || tokenBeforeTheLastToken?.type === "brace" && tokenBeforeTheLastToken.value === "{")) {
          length--;
          continue;
        }
        break;
      case "delimiter":
        length--;
        break;
    }
    break;
  }
  return tokens.slice(0, length);
};
var unstrip = (tokens) => {
  let tail = [];
  tokens.map((token) => {
    if (token.type === "brace") {
      if (token.value === "{") {
        tail.push("}");
      } else {
        tail.splice(tail.lastIndexOf("}"), 1);
      }
    }
    if (token.type === "paren") {
      if (token.value === "[") {
        tail.push("]");
      } else {
        tail.splice(tail.lastIndexOf("]"), 1);
      }
    }
  });
  if (tail.length > 0) {
    tail.reverse().map((item) => {
      if (item === "}") {
        tokens.push({
          type: "brace",
          value: "}"
        });
      } else if (item === "]") {
        tokens.push({
          type: "paren",
          value: "]"
        });
      }
    });
  }
  return tokens;
};
var generate = (tokens) => {
  let output = "";
  tokens.map((token) => {
    switch (token.type) {
      case "string":
        output += '"' + token.value + '"';
        break;
      default:
        output += token.value;
        break;
    }
  });
  return output;
};
var partialParse = (input) => JSON.parse(generate(unstrip(strip(tokenize(input)))));

// node_modules/@anthropic-ai/sdk/internal/message-stream-utils.mjs
var JSON_BUF_PROPERTY = "__json_buf";
function withLazyInput(prev, jsonBuf) {
  const next = {};
  for (const key of Object.keys(prev)) {
    if (key !== "input")
      next[key] = prev[key];
  }
  Object.defineProperty(next, JSON_BUF_PROPERTY, { value: jsonBuf, enumerable: false, writable: true });
  let input;
  let parsed = false;
  Object.defineProperty(next, "input", {
    enumerable: true,
    configurable: true,
    get() {
      if (!parsed) {
        input = jsonBuf ? partialParse(jsonBuf) : {};
        parsed = true;
      }
      return input;
    }
  });
  return next;
}

// node_modules/@anthropic-ai/sdk/lib/MessageStream.mjs
var _MessageStream_instances;
var _MessageStream_currentMessageSnapshot;
var _MessageStream_params;
var _MessageStream_connectedPromise;
var _MessageStream_resolveConnectedPromise;
var _MessageStream_rejectConnectedPromise;
var _MessageStream_endPromise;
var _MessageStream_resolveEndPromise;
var _MessageStream_rejectEndPromise;
var _MessageStream_listeners;
var _MessageStream_ended;
var _MessageStream_errored;
var _MessageStream_aborted;
var _MessageStream_catchingPromiseCreated;
var _MessageStream_response;
var _MessageStream_request_id;
var _MessageStream_workspace_id;
var _MessageStream_logger;
var _MessageStream_getFinalMessage;
var _MessageStream_getFinalText;
var _MessageStream_handleError;
var _MessageStream_beginRequest;
var _MessageStream_addStreamEvent;
var _MessageStream_endRequest;
var _MessageStream_accumulateMessage;
function tracksToolInput(content) {
  return content.type === "tool_use" || content.type === "server_tool_use";
}
var MessageStream = /* @__PURE__ */ (() => {
  class MessageStream2 {
    constructor(params, opts) {
      _MessageStream_instances.add(this);
      this.messages = [];
      this.receivedMessages = [];
      _MessageStream_currentMessageSnapshot.set(this, void 0);
      _MessageStream_params.set(this, null);
      this.controller = new AbortController();
      _MessageStream_connectedPromise.set(this, void 0);
      _MessageStream_resolveConnectedPromise.set(this, () => {
      });
      _MessageStream_rejectConnectedPromise.set(this, () => {
      });
      _MessageStream_endPromise.set(this, void 0);
      _MessageStream_resolveEndPromise.set(this, () => {
      });
      _MessageStream_rejectEndPromise.set(this, () => {
      });
      _MessageStream_listeners.set(this, {});
      _MessageStream_ended.set(this, false);
      _MessageStream_errored.set(this, false);
      _MessageStream_aborted.set(this, false);
      _MessageStream_catchingPromiseCreated.set(this, false);
      _MessageStream_response.set(this, void 0);
      _MessageStream_request_id.set(this, void 0);
      _MessageStream_workspace_id.set(this, void 0);
      _MessageStream_logger.set(this, void 0);
      _MessageStream_handleError.set(this, (error) => {
        __classPrivateFieldSet(this, _MessageStream_errored, true, "f");
        if (isAbortError(error)) {
          error = new APIUserAbortError();
        }
        if (error instanceof APIUserAbortError) {
          __classPrivateFieldSet(this, _MessageStream_aborted, true, "f");
          return this._emit("abort", error);
        }
        if (error instanceof AnthropicError) {
          return this._emit("error", error);
        }
        if (error instanceof Error) {
          const anthropicError = new AnthropicError(error.message);
          anthropicError.cause = error;
          return this._emit("error", anthropicError);
        }
        return this._emit("error", new AnthropicError(String(error)));
      });
      __classPrivateFieldSet(this, _MessageStream_connectedPromise, new Promise((resolve, reject) => {
        __classPrivateFieldSet(this, _MessageStream_resolveConnectedPromise, resolve, "f");
        __classPrivateFieldSet(this, _MessageStream_rejectConnectedPromise, reject, "f");
      }), "f");
      __classPrivateFieldSet(this, _MessageStream_endPromise, new Promise((resolve, reject) => {
        __classPrivateFieldSet(this, _MessageStream_resolveEndPromise, resolve, "f");
        __classPrivateFieldSet(this, _MessageStream_rejectEndPromise, reject, "f");
      }), "f");
      __classPrivateFieldGet(this, _MessageStream_connectedPromise, "f").catch(() => {
      });
      __classPrivateFieldGet(this, _MessageStream_endPromise, "f").catch(() => {
      });
      __classPrivateFieldSet(this, _MessageStream_params, params, "f");
      __classPrivateFieldSet(this, _MessageStream_logger, opts?.logger ?? console, "f");
    }
    get response() {
      return __classPrivateFieldGet(this, _MessageStream_response, "f");
    }
    get request_id() {
      return __classPrivateFieldGet(this, _MessageStream_request_id, "f");
    }
    get workspace_id() {
      return __classPrivateFieldGet(this, _MessageStream_workspace_id, "f");
    }
    /**
     * Returns the `MessageStream` data, the raw `Response` instance and the ID of the request,
     * returned vie the `request-id` header which is useful for debugging requests and resporting
     * issues to Anthropic.
     *
     * This is the same as the `APIPromise.withResponse()` method.
     *
     * This method will raise an error if you created the stream using `MessageStream.fromReadableStream`
     * as no `Response` is available.
     */
    async withResponse() {
      __classPrivateFieldSet(this, _MessageStream_catchingPromiseCreated, true, "f");
      const response = await __classPrivateFieldGet(this, _MessageStream_connectedPromise, "f");
      if (!response) {
        throw new Error("Could not resolve a `Response` object");
      }
      return {
        data: this,
        response,
        request_id: response.headers.get("request-id"),
        workspace_id: response.headers.get("anthropic-workspace-id")
      };
    }
    /**
     * Intended for use on the frontend, consuming a stream produced with
     * `.toReadableStream()` on the backend.
     *
     * Note that messages sent to the model do not appear in `.on('message')`
     * in this context.
     */
    static fromReadableStream(stream2) {
      const runner = new MessageStream2(null);
      runner._run(() => runner._fromReadableStream(stream2));
      return runner;
    }
    static createMessage(messages, params, options, { logger } = {}) {
      const runner = new MessageStream2(params, { logger });
      for (const message of params.messages) {
        runner._addMessageParam(message);
      }
      __classPrivateFieldSet(runner, _MessageStream_params, { ...params, stream: true }, "f");
      runner._run(() => runner._createMessage(messages, { ...params, stream: true }, { ...options, headers: { ...options?.headers, [STAINLESS_HELPER_METHOD_HEADER]: "stream" } }));
      return runner;
    }
    _run(executor) {
      executor().then(() => {
        this._emitFinal();
        this._emit("end");
      }, __classPrivateFieldGet(this, _MessageStream_handleError, "f"));
    }
    _addMessageParam(message) {
      this.messages.push(message);
    }
    _addMessage(message, emit = true) {
      this.receivedMessages.push(message);
      if (emit) {
        this._emit("message", message);
      }
    }
    async _createMessage(messages, params, options) {
      const signal = options?.signal;
      let abortHandler;
      if (signal) {
        if (signal.aborted)
          this.controller.abort();
        abortHandler = this.controller.abort.bind(this.controller);
        signal.addEventListener("abort", abortHandler);
      }
      try {
        __classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_beginRequest).call(this);
        const { response, data: stream2 } = await messages.create({ ...params, stream: true }, { ...options, signal: this.controller.signal }).withResponse();
        this._connected(response);
        for await (const event of stream2) {
          __classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_addStreamEvent).call(this, event);
        }
        if (stream2.controller.signal?.aborted) {
          throw new APIUserAbortError();
        }
        __classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_endRequest).call(this);
      } finally {
        if (signal && abortHandler) {
          signal.removeEventListener("abort", abortHandler);
        }
      }
    }
    _connected(response) {
      if (this.ended)
        return;
      __classPrivateFieldSet(this, _MessageStream_response, response, "f");
      __classPrivateFieldSet(this, _MessageStream_request_id, response?.headers.get("request-id"), "f");
      __classPrivateFieldSet(this, _MessageStream_workspace_id, response?.headers.get("anthropic-workspace-id"), "f");
      __classPrivateFieldGet(this, _MessageStream_resolveConnectedPromise, "f").call(this, response);
      this._emit("connect");
    }
    get ended() {
      return __classPrivateFieldGet(this, _MessageStream_ended, "f");
    }
    get errored() {
      return __classPrivateFieldGet(this, _MessageStream_errored, "f");
    }
    get aborted() {
      return __classPrivateFieldGet(this, _MessageStream_aborted, "f");
    }
    abort() {
      this.controller.abort();
    }
    /**
     * Adds the listener function to the end of the listeners array for the event.
     * No checks are made to see if the listener has already been added. Multiple calls passing
     * the same combination of event and listener will result in the listener being added, and
     * called, multiple times.
     * @returns this MessageStream, so that calls can be chained
     */
    on(event, listener) {
      const listeners = __classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] || (__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] = []);
      listeners.push({ listener });
      return this;
    }
    /**
     * Removes the specified listener from the listener array for the event.
     * off() will remove, at most, one instance of a listener from the listener array. If any single
     * listener has been added multiple times to the listener array for the specified event, then
     * off() must be called multiple times to remove each instance.
     * @returns this MessageStream, so that calls can be chained
     */
    off(event, listener) {
      const listeners = __classPrivateFieldGet(this, _MessageStream_listeners, "f")[event];
      if (!listeners)
        return this;
      const index = listeners.findIndex((l) => l.listener === listener);
      if (index >= 0)
        listeners.splice(index, 1);
      return this;
    }
    /**
     * Adds a one-time listener function for the event. The next time the event is triggered,
     * this listener is removed and then invoked.
     * @returns this MessageStream, so that calls can be chained
     */
    once(event, listener) {
      const listeners = __classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] || (__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] = []);
      listeners.push({ listener, once: true });
      return this;
    }
    /**
     * This is similar to `.once()`, but returns a Promise that resolves the next time
     * the event is triggered, instead of calling a listener callback.
     * @returns a Promise that resolves the next time given event is triggered,
     * or rejects if an error is emitted.  (If you request the 'error' event,
     * returns a promise that resolves with the error).
     *
     * Example:
     *
     *   const message = await stream.emitted('message') // rejects if the stream errors
     */
    emitted(event) {
      return new Promise((resolve, reject) => {
        __classPrivateFieldSet(this, _MessageStream_catchingPromiseCreated, true, "f");
        if (event !== "error")
          this.once("error", reject);
        this.once(event, resolve);
      });
    }
    async done() {
      __classPrivateFieldSet(this, _MessageStream_catchingPromiseCreated, true, "f");
      await __classPrivateFieldGet(this, _MessageStream_endPromise, "f");
    }
    get currentMessage() {
      return __classPrivateFieldGet(this, _MessageStream_currentMessageSnapshot, "f");
    }
    /**
     * @returns a promise that resolves with the the final assistant Message response,
     * or rejects if an error occurred or the stream ended prematurely without producing a Message.
     * If structured outputs were used, this will be a ParsedMessage with a `parsed_output` field.
     */
    async finalMessage() {
      await this.done();
      return __classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_getFinalMessage).call(this);
    }
    /**
     * @returns a promise that resolves with the the final assistant Message's text response, concatenated
     * together if there are more than one text blocks.
     * Rejects if an error occurred or the stream ended prematurely without producing a Message.
     */
    async finalText() {
      await this.done();
      return __classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_getFinalText).call(this);
    }
    _emit(event, ...args) {
      if (__classPrivateFieldGet(this, _MessageStream_ended, "f"))
        return;
      if (event === "end") {
        __classPrivateFieldSet(this, _MessageStream_ended, true, "f");
        __classPrivateFieldGet(this, _MessageStream_resolveEndPromise, "f").call(this);
      }
      const listeners = __classPrivateFieldGet(this, _MessageStream_listeners, "f")[event];
      if (listeners) {
        __classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] = listeners.filter((l) => !l.once);
        listeners.forEach(({ listener }) => listener(...args));
      }
      if (event === "abort") {
        const error = args[0];
        if (!__classPrivateFieldGet(this, _MessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
          Promise.reject(error);
        }
        __classPrivateFieldGet(this, _MessageStream_rejectConnectedPromise, "f").call(this, error);
        __classPrivateFieldGet(this, _MessageStream_rejectEndPromise, "f").call(this, error);
        this._emit("end");
        return;
      }
      if (event === "error") {
        const error = args[0];
        if (!__classPrivateFieldGet(this, _MessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
          Promise.reject(error);
        }
        __classPrivateFieldGet(this, _MessageStream_rejectConnectedPromise, "f").call(this, error);
        __classPrivateFieldGet(this, _MessageStream_rejectEndPromise, "f").call(this, error);
        this._emit("end");
      }
    }
    _emitFinal() {
      const finalMessage = this.receivedMessages.at(-1);
      if (finalMessage) {
        this._emit("finalMessage", __classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_getFinalMessage).call(this));
      }
    }
    async _fromReadableStream(readableStream, options) {
      const signal = options?.signal;
      let abortHandler;
      if (signal) {
        if (signal.aborted)
          this.controller.abort();
        abortHandler = this.controller.abort.bind(this.controller);
        signal.addEventListener("abort", abortHandler);
      }
      try {
        __classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_beginRequest).call(this);
        this._connected(null);
        const stream2 = Stream.fromReadableStream(readableStream, this.controller);
        for await (const event of stream2) {
          __classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_addStreamEvent).call(this, event);
        }
        if (stream2.controller.signal?.aborted) {
          throw new APIUserAbortError();
        }
        __classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_endRequest).call(this);
      } finally {
        if (signal && abortHandler) {
          signal.removeEventListener("abort", abortHandler);
        }
      }
    }
    [(_MessageStream_currentMessageSnapshot = /* @__PURE__ */ new WeakMap(), _MessageStream_params = /* @__PURE__ */ new WeakMap(), _MessageStream_connectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_resolveConnectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_rejectConnectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_endPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_resolveEndPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_rejectEndPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_listeners = /* @__PURE__ */ new WeakMap(), _MessageStream_ended = /* @__PURE__ */ new WeakMap(), _MessageStream_errored = /* @__PURE__ */ new WeakMap(), _MessageStream_aborted = /* @__PURE__ */ new WeakMap(), _MessageStream_catchingPromiseCreated = /* @__PURE__ */ new WeakMap(), _MessageStream_response = /* @__PURE__ */ new WeakMap(), _MessageStream_request_id = /* @__PURE__ */ new WeakMap(), _MessageStream_workspace_id = /* @__PURE__ */ new WeakMap(), _MessageStream_logger = /* @__PURE__ */ new WeakMap(), _MessageStream_handleError = /* @__PURE__ */ new WeakMap(), _MessageStream_instances = /* @__PURE__ */ new WeakSet(), _MessageStream_getFinalMessage = function _MessageStream_getFinalMessage2() {
      if (this.receivedMessages.length === 0) {
        throw new AnthropicError("stream ended without producing a Message with role=assistant");
      }
      return this.receivedMessages.at(-1);
    }, _MessageStream_getFinalText = function _MessageStream_getFinalText2() {
      if (this.receivedMessages.length === 0) {
        throw new AnthropicError("stream ended without producing a Message with role=assistant");
      }
      const textBlocks = this.receivedMessages.at(-1).content.filter((block) => block.type === "text").map((block) => block.text);
      if (textBlocks.length === 0) {
        throw new AnthropicError("stream ended without producing a content block with type=text");
      }
      return textBlocks.join(" ");
    }, _MessageStream_beginRequest = function _MessageStream_beginRequest2() {
      if (this.ended)
        return;
      __classPrivateFieldSet(this, _MessageStream_currentMessageSnapshot, void 0, "f");
    }, _MessageStream_addStreamEvent = function _MessageStream_addStreamEvent2(event) {
      if (this.ended)
        return;
      const messageSnapshot = __classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_accumulateMessage).call(this, event);
      this._emit("streamEvent", event, messageSnapshot);
      switch (event.type) {
        case "content_block_delta": {
          const content = messageSnapshot.content.at(-1);
          switch (event.delta.type) {
            case "text_delta": {
              if (content.type === "text") {
                this._emit("text", event.delta.text, content.text || "");
              }
              break;
            }
            case "citations_delta": {
              if (content.type === "text") {
                this._emit("citation", event.delta.citation, content.citations ?? []);
              }
              break;
            }
            case "input_json_delta": {
              if (tracksToolInput(content) && __classPrivateFieldGet(this, _MessageStream_listeners, "f").inputJson?.length) {
                this._emit("inputJson", event.delta.partial_json, content.input);
              }
              break;
            }
            case "thinking_delta": {
              if (content.type === "thinking") {
                this._emit("thinking", event.delta.thinking, content.thinking);
              }
              break;
            }
            case "signature_delta": {
              if (content.type === "thinking") {
                this._emit("signature", content.signature);
              }
              break;
            }
            default:
              checkNever(event.delta);
          }
          break;
        }
        case "message_stop": {
          this._addMessageParam(messageSnapshot);
          this._addMessage(maybeParseMessage(messageSnapshot, __classPrivateFieldGet(this, _MessageStream_params, "f"), { logger: __classPrivateFieldGet(this, _MessageStream_logger, "f") }), true);
          break;
        }
        case "content_block_stop": {
          this._emit("contentBlock", messageSnapshot.content.at(-1));
          break;
        }
        case "message_start": {
          __classPrivateFieldSet(this, _MessageStream_currentMessageSnapshot, messageSnapshot, "f");
          break;
        }
        case "content_block_start":
        case "message_delta":
          break;
      }
    }, _MessageStream_endRequest = function _MessageStream_endRequest2() {
      if (this.ended) {
        throw new AnthropicError(`stream has ended, this shouldn't happen`);
      }
      const snapshot = __classPrivateFieldGet(this, _MessageStream_currentMessageSnapshot, "f");
      if (!snapshot) {
        throw new AnthropicError(`request ended without sending any chunks`);
      }
      __classPrivateFieldSet(this, _MessageStream_currentMessageSnapshot, void 0, "f");
      return maybeParseMessage(snapshot, __classPrivateFieldGet(this, _MessageStream_params, "f"), { logger: __classPrivateFieldGet(this, _MessageStream_logger, "f") });
    }, _MessageStream_accumulateMessage = function _MessageStream_accumulateMessage2(event) {
      let snapshot = __classPrivateFieldGet(this, _MessageStream_currentMessageSnapshot, "f");
      if (event.type === "message_start") {
        if (snapshot) {
          throw new AnthropicError(`Unexpected event order, got ${event.type} before receiving "message_stop"`);
        }
        return event.message;
      }
      if (!snapshot) {
        throw new AnthropicError(`Unexpected event order, got ${event.type} before "message_start"`);
      }
      switch (event.type) {
        case "message_stop":
          return snapshot;
        case "message_delta":
          snapshot.stop_reason = event.delta.stop_reason;
          snapshot.stop_sequence = event.delta.stop_sequence;
          snapshot.stop_details = event.delta.stop_details;
          snapshot.usage.output_tokens = event.usage.output_tokens;
          if (event.delta.container != null) {
            snapshot.container = event.delta.container;
          }
          if (event.usage.input_tokens != null) {
            snapshot.usage.input_tokens = event.usage.input_tokens;
          }
          if (event.usage.cache_creation_input_tokens != null) {
            snapshot.usage.cache_creation_input_tokens = event.usage.cache_creation_input_tokens;
          }
          if (event.usage.cache_read_input_tokens != null) {
            snapshot.usage.cache_read_input_tokens = event.usage.cache_read_input_tokens;
          }
          if (event.usage.server_tool_use != null) {
            snapshot.usage.server_tool_use = event.usage.server_tool_use;
          }
          if (event.usage.output_tokens_details != null) {
            snapshot.usage.output_tokens_details = event.usage.output_tokens_details;
          }
          return snapshot;
        case "content_block_start":
          snapshot.content.push({ ...event.content_block });
          return snapshot;
        case "content_block_delta": {
          const snapshotContent = snapshot.content.at(event.index);
          switch (event.delta.type) {
            case "text_delta": {
              if (snapshotContent?.type === "text") {
                snapshot.content[event.index] = {
                  ...snapshotContent,
                  text: (snapshotContent.text || "") + event.delta.text
                };
              }
              break;
            }
            case "citations_delta": {
              if (snapshotContent?.type === "text") {
                snapshot.content[event.index] = {
                  ...snapshotContent,
                  citations: [...snapshotContent.citations ?? [], event.delta.citation]
                };
              }
              break;
            }
            case "input_json_delta": {
              if (snapshotContent && tracksToolInput(snapshotContent)) {
                const jsonBuf = (snapshotContent[JSON_BUF_PROPERTY] || "") + event.delta.partial_json;
                snapshot.content[event.index] = withLazyInput(snapshotContent, jsonBuf);
              }
              break;
            }
            case "thinking_delta": {
              if (snapshotContent?.type === "thinking") {
                snapshot.content[event.index] = {
                  ...snapshotContent,
                  thinking: snapshotContent.thinking + event.delta.thinking
                };
              }
              break;
            }
            case "signature_delta": {
              if (snapshotContent?.type === "thinking") {
                snapshot.content[event.index] = {
                  ...snapshotContent,
                  signature: event.delta.signature
                };
              }
              break;
            }
            default:
              checkNever(event.delta);
          }
          return snapshot;
        }
        case "content_block_stop": {
          const snapshotContent = snapshot.content.at(event.index);
          if (snapshotContent && tracksToolInput(snapshotContent) && JSON_BUF_PROPERTY in snapshotContent) {
            Object.defineProperty(snapshotContent, "input", {
              value: snapshotContent.input,
              enumerable: true,
              configurable: true,
              writable: true
            });
          }
          return snapshot;
        }
      }
    }, Symbol.asyncIterator)]() {
      const pushQueue = [];
      const readQueue = [];
      let done = false;
      this.on("streamEvent", (event) => {
        const reader = readQueue.shift();
        if (reader) {
          reader.resolve(event);
        } else {
          pushQueue.push(event);
        }
      });
      this.on("end", () => {
        done = true;
        for (const reader of readQueue) {
          reader.resolve(void 0);
        }
        readQueue.length = 0;
      });
      this.on("abort", (err) => {
        done = true;
        for (const reader of readQueue) {
          reader.reject(err);
        }
        readQueue.length = 0;
      });
      this.on("error", (err) => {
        done = true;
        for (const reader of readQueue) {
          reader.reject(err);
        }
        readQueue.length = 0;
      });
      return {
        next: async () => {
          if (!pushQueue.length) {
            if (done) {
              return { value: void 0, done: true };
            }
            return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk2) => chunk2 ? { value: chunk2, done: false } : { value: void 0, done: true });
          }
          const chunk = pushQueue.shift();
          return { value: chunk, done: false };
        },
        return: async () => {
          this.abort();
          return { value: void 0, done: true };
        }
      };
    }
    toReadableStream() {
      const stream2 = new Stream(this[Symbol.asyncIterator].bind(this), this.controller);
      return stream2.toReadableStream();
    }
  }
  return MessageStream2;
})();

// node_modules/@anthropic-ai/sdk/internal/decoders/jsonl.mjs
init_error();
var _JSONLDecoder_consumed;
var JSONLDecoder = /* @__PURE__ */ (() => {
  class JSONLDecoder2 {
    constructor(iterator, controller) {
      this.iterator = iterator;
      _JSONLDecoder_consumed.set(this, false);
      this.controller = controller;
    }
    async *decoder() {
      if (__classPrivateFieldGet(this, _JSONLDecoder_consumed, "f")) {
        throw new AnthropicError("Cannot iterate over a consumed stream.");
      }
      __classPrivateFieldSet(this, _JSONLDecoder_consumed, true, "f");
      const lineDecoder = new LineDecoder();
      for await (const chunk of this.iterator) {
        for (const line of lineDecoder.decode(chunk)) {
          yield JSON.parse(line);
        }
      }
      for (const line of lineDecoder.flush()) {
        yield JSON.parse(line);
      }
    }
    [(_JSONLDecoder_consumed = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
      return this.decoder();
    }
    static fromResponse(response, controller) {
      if (!response.body) {
        controller.abort();
        if (typeof globalThis.navigator !== "undefined" && globalThis.navigator.product === "ReactNative") {
          throw new AnthropicError(`The default react-native fetch implementation does not support streaming. Please use expo/fetch: https://docs.expo.dev/versions/latest/sdk/expo/#expofetch-api`);
        }
        throw new AnthropicError(`Attempted to iterate over a response with no body`);
      }
      return new JSONLDecoder2(ReadableStreamToAsyncIterable(response.body), controller);
    }
  }
  return JSONLDecoder2;
})();

// node_modules/@anthropic-ai/sdk/internal/utils/path.mjs
init_error();
function encodeURIPath(str) {
  return str.replace(/[^A-Za-z0-9\-._~!$&'()*+,;=:@]+/g, encodeURIComponent);
}
var EMPTY = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.create(null));
var createPathTagFunction = (pathEncoder = encodeURIPath) => function path3(statics, ...params) {
  if (statics.length === 1)
    return statics[0];
  let postPath = false;
  const invalidSegments = [];
  const path4 = statics.reduce((previousValue, currentValue, index) => {
    if (/[?#]/.test(currentValue)) {
      postPath = true;
    }
    const value = params[index];
    let encoded = (postPath ? encodeURIComponent : pathEncoder)("" + value);
    if (index !== params.length && (value == null || typeof value === "object" && // handle values from other realms
    value.toString === Object.getPrototypeOf(Object.getPrototypeOf(value.hasOwnProperty ?? EMPTY) ?? EMPTY)?.toString)) {
      encoded = value + "";
      invalidSegments.push({
        start: previousValue.length + currentValue.length,
        length: encoded.length,
        error: `Value of type ${Object.prototype.toString.call(value).slice(8, -1)} is not a valid path parameter`
      });
    }
    if (!postPath && encoded === "") {
      invalidSegments.push({
        start: previousValue.length + currentValue.length,
        length: 0,
        error: `Value "" can't be safely passed as a path parameter`
      });
    }
    return previousValue + currentValue + (index === params.length ? "" : encoded);
  }, "");
  const pathOnly = path4.split(/[?#]/, 1)[0];
  const invalidSegmentPattern = /(?<=^|\/)(?:\.|%2e){1,2}(?=\/|$)/gi;
  let match;
  while ((match = invalidSegmentPattern.exec(pathOnly)) !== null) {
    invalidSegments.push({
      start: match.index,
      length: match[0].length,
      error: `Value "${match[0]}" can't be safely passed as a path parameter`
    });
  }
  invalidSegments.sort((a, b) => a.start - b.start);
  if (invalidSegments.length > 0) {
    const marks = [];
    for (const segment of invalidSegments) {
      for (let i = segment.start; i < segment.start + Math.max(1, segment.length); i++) {
        marks[i] = "^";
      }
    }
    const underline = Array.from(marks, (mark) => mark ?? " ").join("");
    throw new AnthropicError(`Path parameters result in path with invalid segments:
${invalidSegments.map((e) => e.error).join("\n")}
${path4}
${underline}`);
  }
  return path4;
};
var path2 = /* @__PURE__ */ createPathTagFunction(encodeURIPath);

// node_modules/@anthropic-ai/sdk/resources/messages/batches.mjs
var Batches = class extends APIResource {
  /**
   * Send a batch of Message creation requests.
   *
   * The Message Batches API can be used to process multiple Messages API requests at
   * once. Once a Message Batch is created, it begins processing immediately. Batches
   * can take up to 24 hours to complete.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const messageBatch = await client.messages.batches.create({
   *   requests: [
   *     {
   *       custom_id: 'my-custom-id-1',
   *       params: {
   *         max_tokens: 1024,
   *         messages: [
   *           { content: 'Hello, world', role: 'user' },
   *         ],
   *         model: 'claude-opus-5',
   *       },
   *     },
   *   ],
   * });
   * ```
   */
  create(params, options) {
    const { user_profile_id, workspace_id, ...body } = params;
    return this._client.post("/v1/messages/batches", {
      body,
      ...options,
      headers: buildHeaders([
        {
          ...user_profile_id != null ? { "anthropic-user-profile-id": user_profile_id } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * This endpoint is idempotent and can be used to poll for Message Batch
   * completion. To access the results of a Message Batch, make a request to the
   * `results_url` field in the response.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const messageBatch = await client.messages.batches.retrieve(
   *   'message_batch_id',
   * );
   * ```
   */
  retrieve(messageBatchID, params = {}, options) {
    const { workspace_id } = params ?? {};
    return this._client.get(path2`/v1/messages/batches/${messageBatchID}`, {
      ...options,
      headers: buildHeaders([
        { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * List all Message Batches within a Workspace. Most recently created batches are
   * returned first.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const messageBatch of client.messages.batches.list()) {
   *   // ...
   * }
   * ```
   */
  list(params = {}, options) {
    const { workspace_id, ...query } = params ?? {};
    return this._client.getAPIList("/v1/messages/batches", Page, {
      query,
      ...options,
      headers: buildHeaders([
        { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * Delete a Message Batch.
   *
   * Message Batches can only be deleted once they've finished processing. If you'd
   * like to delete an in-progress batch, you must first cancel it.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const deletedMessageBatch =
   *   await client.messages.batches.delete('message_batch_id');
   * ```
   */
  delete(messageBatchID, params = {}, options) {
    const { workspace_id } = params ?? {};
    return this._client.delete(path2`/v1/messages/batches/${messageBatchID}`, {
      ...options,
      headers: buildHeaders([
        { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * Batches may be canceled any time before processing ends. Once cancellation is
   * initiated, the batch enters a `canceling` state, at which time the system may
   * complete any in-progress, non-interruptible requests before finalizing
   * cancellation.
   *
   * The number of canceled requests is specified in `request_counts`. To determine
   * which requests were canceled, check the individual results within the batch.
   * Note that cancellation may not result in any canceled requests if they were
   * non-interruptible.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const messageBatch = await client.messages.batches.cancel(
   *   'message_batch_id',
   * );
   * ```
   */
  cancel(messageBatchID, params = {}, options) {
    const { workspace_id } = params ?? {};
    return this._client.post(path2`/v1/messages/batches/${messageBatchID}/cancel`, {
      ...options,
      headers: buildHeaders([
        { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * Streams the results of a Message Batch as a `.jsonl` file.
   *
   * Each line in the file is a JSON object containing the result of a single request
   * in the Message Batch. Results are not guaranteed to be in the same order as
   * requests. Use the `custom_id` field to match results to requests.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const messageBatchIndividualResponse =
   *   await client.messages.batches.results('message_batch_id');
   * ```
   */
  async results(messageBatchID, params = {}, options) {
    const batch = await this.retrieve(messageBatchID, params, options);
    if (!batch.results_url) {
      throw new AnthropicError(`No batch \`results_url\`; Has it finished processing? ${batch.processing_status} - ${batch.id}`);
    }
    const { workspace_id } = params ?? {};
    return this._client.get(batch.results_url, {
      ...options,
      headers: buildHeaders([
        {
          Accept: "application/binary",
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ]),
      stream: true,
      __binaryResponse: true
    })._thenUnwrap((_, props) => JSONLDecoder.fromResponse(props.response, props.controller));
  }
};

// node_modules/@anthropic-ai/sdk/internal/constants.mjs
var MODEL_NONSTREAMING_TOKENS = {
  "claude-opus-4@20250514": 8192,
  "anthropic.claude-opus-4-1-20250805-v1:0": 8192,
  "claude-opus-4-1@20250805": 8192
};

// node_modules/@anthropic-ai/sdk/resources/messages/messages.mjs
var Messages = /* @__PURE__ */ (() => {
  class Messages3 extends APIResource {
    constructor() {
      super(...arguments);
      this.batches = new Batches(this._client);
    }
    create(params, options) {
      const { user_profile_id, workspace_id, ...body } = params;
      if (body.model in DEPRECATED_MODELS) {
        console.warn(`The model '${body.model}' is deprecated and will reach end-of-life on ${DEPRECATED_MODELS[body.model]}
Please migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.`);
      }
      if (MODELS_TO_WARN_WITH_THINKING_ENABLED.includes(body.model) && body.thinking && body.thinking.type === "enabled") {
        console.warn(`Using Claude with ${body.model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking`);
      }
      let timeout = options?.timeout ?? this._client._options.timeout;
      if (!body.stream && timeout == null) {
        const maxNonstreamingTokens = MODEL_NONSTREAMING_TOKENS[body.model] ?? void 0;
        timeout = this._client.calculateNonstreamingTimeout(body.max_tokens, maxNonstreamingTokens);
      }
      const helperHeader2 = stainlessHelperHeader(body.tools, body.messages);
      return this._client.post("/v1/messages", {
        body,
        timeout: timeout ?? 6e5,
        ...options,
        headers: buildHeaders([
          {
            ...user_profile_id != null ? { "anthropic-user-profile-id": user_profile_id } : void 0,
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          helperHeader2,
          options?.headers
        ]),
        stream: params.stream ?? false
      });
    }
    /**
     * Send a structured list of input messages with text and/or image content, along with an expected `output_config.format` and
     * the response will be automatically parsed and available in the `parsed_output` property of the message.
     *
     * @example
     * ```ts
     * const message = await client.messages.parse({
     *   model: 'claude-sonnet-5-5',
     *   max_tokens: 1024,
     *   messages: [{ role: 'user', content: 'What is 2+2?' }],
     *   output_config: {
     *     format: zodOutputFormat(z.object({ answer: z.number() })),
     *   },
     * });
     *
     * console.log(message.parsed_output?.answer); // 4
     * ```
     */
    parse(params, options) {
      return this.create(params, options).then((message) => parseMessage(message, params, { logger: this._client.logger ?? console }));
    }
    /**
     * Create a Message stream.
     *
     * If `output_config.format` is provided with a parseable format (like `zodOutputFormat()`),
     * the final message will include a `parsed_output` property with the parsed content.
     *
     * @example
     * ```ts
     * const stream = client.messages.stream({
     *   model: 'claude-sonnet-5-5',
     *   max_tokens: 1024,
     *   messages: [{ role: 'user', content: 'What is 2+2?' }],
     *   output_config: {
     *     format: zodOutputFormat(z.object({ answer: z.number() })),
     *   },
     * });
     *
     * const message = await stream.finalMessage();
     * console.log(message.parsed_output?.answer); // 4
     * ```
     */
    stream(body, options) {
      return MessageStream.createMessage(this, body, options, { logger: this._client.logger ?? console });
    }
    /**
     * Count the number of tokens in a Message.
     *
     * The Token Count API can be used to count the number of tokens in a Message,
     * including tools, images, and documents, without creating it.
     *
     * Learn more about token counting in our
     * [user guide](https://platform.claude.com/docs/en/build-with-claude/token-counting)
     *
     * @example
     * ```ts
     * const messageTokensCount =
     *   await client.messages.countTokens({
     *     messages: [{ content: 'Hello, world', role: 'user' }],
     *     model: 'claude-opus-5',
     *   });
     * ```
     */
    countTokens(params, options) {
      const { user_profile_id, workspace_id, ...body } = params;
      return this._client.post("/v1/messages/count_tokens", {
        body,
        ...options,
        headers: buildHeaders([
          {
            ...user_profile_id != null ? { "anthropic-user-profile-id": user_profile_id } : void 0,
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
  }
  Messages3.Batches = Batches;
  return Messages3;
})();
var DEPRECATED_MODELS = {
  "claude-sonnet-4-5": "November 30th, 2026",
  "claude-sonnet-4-5-20250929": "November 30th, 2026"
};
var MODELS_TO_WARN_WITH_THINKING_ENABLED = ["claude-mythos-preview", "claude-opus-4-6"];

// node_modules/@anthropic-ai/sdk/resources/beta/deployment-runs.mjs
var DeploymentRuns = class extends APIResource {
  /**
   * Get Deployment Run
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeploymentRun =
   *   await client.beta.deploymentRuns.retrieve(
   *     'deployment_run_id',
   *   );
   * ```
   */
  retrieve(deploymentRunID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.get(path2`/v1/deployment_runs/${deploymentRunID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * List Deployment Runs
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsDeploymentRun of client.beta.deploymentRuns.list()) {
   *   // ...
   * }
   * ```
   */
  list(params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList("/v1/deployment_runs?beta=true", PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/deployments.mjs
var Deployments = class extends APIResource {
  /**
   * Create Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.create({
   *     agent: 'string',
   *     environment_id: 'x',
   *     initial_events: [
   *       {
   *         content: [
   *           {
   *             text: 'Where is my order #1234?',
   *             type: 'text',
   *           },
   *         ],
   *         type: 'user.message',
   *       },
   *     ],
   *     name: 'x',
   *   });
   * ```
   */
  create(params, options) {
    const { betas, workspace_id, ...body } = params;
    return this._client.post("/v1/deployments?beta=true", {
      body,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Get Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.retrieve(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  retrieve(deploymentID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.get(path2`/v1/deployments/${deploymentID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Update Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.update(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  update(deploymentID, params, options) {
    const { betas, workspace_id, ...body } = params;
    return this._client.post(path2`/v1/deployments/${deploymentID}?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * List Deployments
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsDeployment of client.beta.deployments.list()) {
   *   // ...
   * }
   * ```
   */
  list(params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList("/v1/deployments?beta=true", PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Archive Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.archive(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  archive(deploymentID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.post(path2`/v1/deployments/${deploymentID}/archive?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Pause Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.pause(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  pause(deploymentID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.post(path2`/v1/deployments/${deploymentID}/pause?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Run Deployment Now
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeploymentRun =
   *   await client.beta.deployments.run(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  run(deploymentID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.post(path2`/v1/deployments/${deploymentID}/run?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Unpause Deployment
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeployment =
   *   await client.beta.deployments.unpause(
   *     'depl_011CZkZcDH3vPqd7xnEfwTai',
   *   );
   * ```
   */
  unpause(deploymentID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.post(path2`/v1/deployments/${deploymentID}/unpause?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/dreams.mjs
var Dreams = class extends APIResource {
  /**
   * Start an asynchronous job that uses past sessions to produce a reorganized
   * version of a memory store and get back the dream to poll for the result.
   *
   * By default the dream writes its result to a new memory store and doesn't change
   * the input memory store. The response has `status` set to `pending` and an empty
   * `outputs` array. Poll the dream until `status` is `completed`, `failed`, or
   * `canceled`.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#create-a-dream)
   * to learn more about creating dreams.
   *
   * @example
   * ```ts
   * const betaDream = await client.beta.dreams.create({
   *   inputs: [{ memory_store_id: 'x', type: 'memory_store' }],
   *   model: 'string',
   * });
   * ```
   */
  create(params, options) {
    const { betas, workspace_id, ...body } = params;
    return this._client.post("/v1/dreams?beta=true", {
      body,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "dreaming-2026-04-21"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Get a dream by ID to check its status, output memory store, and token usage.
   *
   * Archived dreams are returned too.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#track-progress)
   * for how to poll a dream and what each status means.
   *
   * @example
   * ```ts
   * const betaDream = await client.beta.dreams.retrieve(
   *   'dream_id',
   * );
   * ```
   */
  retrieve(dreamID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.get(path2`/v1/dreams/${dreamID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "dreaming-2026-04-21"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * List the dreams in the workspace, newest first.
   *
   * Archived dreams are left out unless `include_archived` is `true`.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#list-dreams)
   * for how to page through dreams.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaDream of client.beta.dreams.list()) {
   *   // ...
   * }
   * ```
   */
  list(params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList("/v1/dreams?beta=true", PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "dreaming-2026-04-21"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Hide a `completed`, `failed`, or `canceled` dream from the default list of
   * dreams.
   *
   * Archiving a `pending` or `running` dream returns a 400 error, so cancel it
   * first. Archiving an archived dream returns it unchanged. An archived dream can
   * still be fetched by ID. Archiving can't be undone.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#archive-a-dream)
   * to learn more about archiving dreams.
   *
   * @example
   * ```ts
   * const betaDream = await client.beta.dreams.archive(
   *   'dream_id',
   * );
   * ```
   */
  archive(dreamID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.post(path2`/v1/dreams/${dreamID}/archive?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "dreaming-2026-04-21"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Stop a `pending` or `running` dream.
   *
   * The response shows `status` as `canceled`, unless the dream reached `completed`
   * or `failed` first. `usage` can keep changing after the response. Canceling a
   * `canceled` dream returns it unchanged. Canceling a `completed` or `failed` dream
   * returns a 400 error.
   *
   * See the
   * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#cancel-a-dream)
   * to learn more about canceling dreams.
   *
   * @example
   * ```ts
   * const betaDream = await client.beta.dreams.cancel(
   *   'dream_id',
   * );
   * ```
   */
  cancel(dreamID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.post(path2`/v1/dreams/${dreamID}/cancel?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "dreaming-2026-04-21"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/files.mjs
var Files = class extends APIResource {
  /**
   * List Files
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaFileMetadata of client.beta.files.list()) {
   *   // ...
   * }
   * ```
   */
  list(params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList("/v1/files?beta=true", PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        {
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Delete File
   *
   * @example
   * ```ts
   * const betaDeletedFile = await client.beta.files.delete(
   *   'file_id',
   * );
   * ```
   */
  delete(fileID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.delete(path2`/v1/files/${fileID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Download File
   *
   * @example
   * ```ts
   * const response = await client.beta.files.download(
   *   'file_id',
   * );
   *
   * const content = await response.blob();
   * console.log(content);
   * ```
   */
  download(fileID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.get(path2`/v1/files/${fileID}/content?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          Accept: "application/binary",
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ]),
      __binaryResponse: true
    });
  }
  /**
   * Get File Metadata
   *
   * @example
   * ```ts
   * const betaFileMetadata =
   *   await client.beta.files.retrieveMetadata('file_id');
   * ```
   */
  retrieveMetadata(fileID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.get(path2`/v1/files/${fileID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Upload File
   *
   * @example
   * ```ts
   * const betaFileMetadata = await client.beta.files.upload({
   *   file: fs.createReadStream('path/to/file'),
   * });
   * ```
   */
  upload(params, options) {
    const { betas, workspace_id, ...body } = params;
    return this._client.post("/v1/files?beta=true", multipartFormRequestOptions({
      body,
      ...options,
      headers: buildHeaders([
        {
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        stainlessHelperHeaderFromFile(body.file),
        options?.headers
      ])
    }, this._client));
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/models.mjs
var Models = class extends APIResource {
  /**
   * Get a specific model.
   *
   * The Models API response can be used to determine information about a specific
   * model or resolve a model alias to a model ID.
   *
   * @example
   * ```ts
   * const betaModelInfo = await client.beta.models.retrieve(
   *   'model_id',
   * );
   * ```
   */
  retrieve(modelID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.get(path2`/v1/models/${modelID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * List available models.
   *
   * The Models API response can be used to determine which models are available for
   * use in the API. More recently released models are listed first.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaModelInfo of client.beta.models.list()) {
   *   // ...
   * }
   * ```
   */
  list(params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList("/v1/models?beta=true", Page, {
      query,
      ...options,
      headers: buildHeaders([
        {
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/user-profiles.mjs
var UserProfiles = class extends APIResource {
  /**
   * Create User Profile
   *
   * @example
   * ```ts
   * const betaUserProfile =
   *   await client.beta.userProfiles.create();
   * ```
   */
  create(params, options) {
    const { betas, workspace_id, ...body } = params;
    return this._client.post("/v1/user_profiles?beta=true", {
      body,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "user-profiles-2026-08-18"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Get User Profile
   *
   * @example
   * ```ts
   * const betaUserProfile =
   *   await client.beta.userProfiles.retrieve(
   *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
   *   );
   * ```
   */
  retrieve(userProfileID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.get(path2`/v1/user_profiles/${userProfileID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "user-profiles-2026-08-18"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Update User Profile
   *
   * @example
   * ```ts
   * const betaUserProfile =
   *   await client.beta.userProfiles.update(
   *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
   *   );
   * ```
   */
  update(userProfileID, params, options) {
    const { betas, workspace_id, ...body } = params;
    return this._client.post(path2`/v1/user_profiles/${userProfileID}?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "user-profiles-2026-08-18"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * List User Profiles
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaUserProfile of client.beta.userProfiles.list()) {
   *   // ...
   * }
   * ```
   */
  list(params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList("/v1/user_profiles?beta=true", PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "user-profiles-2026-08-18"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Create Enrollment URL
   *
   * @example
   * ```ts
   * const betaUserProfileEnrollmentURL =
   *   await client.beta.userProfiles.createEnrollmentURL(
   *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
   *   );
   * ```
   */
  createEnrollmentURL(userProfileID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.post(path2`/v1/user_profiles/${userProfileID}/enrollment_url?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "user-profiles-2026-08-18"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/webhooks.mjs
var import_standardwebhooks = __toESM(require_dist(), 1);
var Webhooks = class extends APIResource {
  /**
   * Parses a webhook payload into an event without verifying its signature. Prefer
   * `unwrap()` unless you have already verified the signature yourself.
   */
  parseUnverified(body) {
    return JSON.parse(body);
  }
  /**
   * Verifies the webhook signature from the `webhook-id`, `webhook-timestamp` and
   * `webhook-signature` headers using your webhook signing key, then parses the
   * payload into an event. Fails if the signature is missing or invalid.
   */
  unwrap(body, options) {
    const headers = options?.headers;
    if (headers == null)
      throw new Error("Webhook headers are required in order to verify the signature");
    const keyStr = options.key === void 0 ? this._client.webhookKey : options.key;
    if (!keyStr)
      throw new Error("Webhook key must not be null or empty in order to unwrap");
    const wh = new import_standardwebhooks.Webhook(keyStr);
    wh.verify(body, headers);
    return JSON.parse(body);
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/agents/versions.mjs
var Versions = class extends APIResource {
  /**
   * List Agent Versions
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsAgent of client.beta.agents.versions.list(
   *   'agent_011CZkYpogX7uDKUyvBTophP',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(agentID, params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/agents/${agentID}/versions?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/agents/agents.mjs
var Agents = /* @__PURE__ */ (() => {
  class Agents2 extends APIResource {
    constructor() {
      super(...arguments);
      this.versions = new Versions(this._client);
    }
    /**
     * Create Agent
     *
     * @example
     * ```ts
     * const betaManagedAgentsAgent =
     *   await client.beta.agents.create({
     *     model: 'claude-opus-5',
     *     name: 'My First Agent',
     *   });
     * ```
     */
    create(params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post("/v1/agents?beta=true", {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Get Agent
     *
     * @example
     * ```ts
     * const betaManagedAgentsAgent =
     *   await client.beta.agents.retrieve(
     *     'agent_011CZkYpogX7uDKUyvBTophP',
     *   );
     * ```
     */
    retrieve(agentID, params = {}, options) {
      const { betas, workspace_id, ...query } = params ?? {};
      return this._client.get(path2`/v1/agents/${agentID}?beta=true`, {
        query,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Update Agent
     *
     * @example
     * ```ts
     * const betaManagedAgentsAgent =
     *   await client.beta.agents.update(
     *     'agent_011CZkYpogX7uDKUyvBTophP',
     *     { description: 'updated' },
     *   );
     * ```
     */
    update(agentID, params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post(path2`/v1/agents/${agentID}?beta=true`, {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * List Agents
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsAgent of client.beta.agents.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
      const { betas, workspace_id, ...query } = params ?? {};
      return this._client.getAPIList("/v1/agents?beta=true", PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Archive Agent
     *
     * @example
     * ```ts
     * const betaManagedAgentsAgent =
     *   await client.beta.agents.archive(
     *     'agent_011CZkYpogX7uDKUyvBTophP',
     *   );
     * ```
     */
    archive(agentID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.post(path2`/v1/agents/${agentID}/archive?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
  }
  Agents2.Versions = Versions;
  return Agents2;
})();

// node_modules/@anthropic-ai/sdk/lib/environments/poller.mjs
init_error();

// node_modules/@anthropic-ai/sdk/internal/utils/abort.mjs
function linkAbort(external, controller) {
  if (!external)
    return () => {
    };
  if (external.aborted) {
    controller.abort();
    return () => {
    };
  }
  const onAbort = () => controller.abort();
  external.addEventListener("abort", onAbort);
  return () => external.removeEventListener("abort", onAbort);
}

// node_modules/@anthropic-ai/sdk/internal/utils/backoff.mjs
init_error();
function isStatus(e, code) {
  return e instanceof APIError && e.status === code;
}
function is4xx(e) {
  return e instanceof APIError && typeof e.status === "number" && e.status >= 400 && e.status < 500;
}
function isFatal4xx(e) {
  return is4xx(e) && !isStatus(e, 408) && !isStatus(e, 409) && !isStatus(e, 429);
}
function backoff(attempt, baseMs, capMs) {
  return Math.min(baseMs * 2 ** attempt, capMs);
}
function jitter(lowMs, highMs) {
  return lowMs + Math.random() * (highMs - lowMs);
}
function applyJitter(ms) {
  return ms * (1 - Math.random() * 0.25);
}

// node_modules/@anthropic-ai/sdk/lib/helper-client.mjs
init_error();
function copyClientForHelper(client, { authToken, helper }) {
  if (!authToken) {
    throw new AnthropicError(`copyClientForHelper: expected a non-empty authToken but received ${JSON.stringify(authToken)}`);
  }
  const internal = client;
  const parentDefaults = internal._options.defaultHeaders;
  const parentAuthExtraHeaders = internal._authState?.extraHeaders;
  const inheritedAuthExtraHeaders = parentAuthExtraHeaders ? Object.fromEntries(Object.entries(parentAuthExtraHeaders).filter(([name]) => {
    const lower = name.toLowerCase();
    return lower !== "authorization" && lower !== "x-api-key";
  })) : void 0;
  const defaultHeaders = buildHeaders([
    inheritedAuthExtraHeaders,
    parentDefaults,
    { [STAINLESS_HELPER_HEADER]: helper }
  ]);
  return client.withOptions({
    apiKey: null,
    authToken,
    baseURL: client.baseURL,
    credentials: void 0,
    defaultHeaders
  });
}

// node_modules/@anthropic-ai/sdk/lib/environments/poller.mjs
var _WorkPoller_runnerClient;
var _WorkPoller_consumed;
var _WorkPoller_controller;
var _WorkPoller_detachExternal;
var _WorkPoller_autoStop;
var _WorkPoller_drain;
var _WorkPoller_blockMs;
var _WorkPoller_reclaimOlderThanMs;
var _WorkPoller_requestOpts;
var _IdleLog_log;
var _IdleLog_environmentId;
var _IdleLog_idleSince;
var _IdleLog_lastReport;
var POLL_BLOCK_MS = 999;
var POLL_BACKOFF_BASE_MS = 1e3;
var POLL_BACKOFF_CAP_MS = 6e4;
var IDLE_REPORT_INTERVAL_MS = 3e5;
var WorkPoller = /* @__PURE__ */ (() => {
  class WorkPoller2 {
    constructor(opts) {
      _WorkPoller_runnerClient.set(this, void 0);
      _WorkPoller_consumed.set(this, false);
      _WorkPoller_controller.set(this, void 0);
      _WorkPoller_detachExternal.set(this, void 0);
      _WorkPoller_autoStop.set(this, void 0);
      _WorkPoller_drain.set(this, void 0);
      _WorkPoller_blockMs.set(this, void 0);
      _WorkPoller_reclaimOlderThanMs.set(this, void 0);
      _WorkPoller_requestOpts.set(this, void 0);
      this.client = opts.client;
      this.environmentId = opts.environmentId;
      this.environmentKey = opts.environmentKey;
      this.workerId = opts.workerId ?? defaultWorkerId();
      __classPrivateFieldSet(this, _WorkPoller_runnerClient, copyClientForHelper(opts.client, {
        authToken: opts.environmentKey,
        helper: "environments-work-poller"
      }), "f");
      __classPrivateFieldSet(this, _WorkPoller_autoStop, opts.autoStop ?? true, "f");
      __classPrivateFieldSet(this, _WorkPoller_drain, opts.drain ?? false, "f");
      __classPrivateFieldSet(this, _WorkPoller_blockMs, opts.blockMs === void 0 ? POLL_BLOCK_MS : opts.blockMs, "f");
      __classPrivateFieldSet(this, _WorkPoller_reclaimOlderThanMs, opts.reclaimOlderThanMs ?? null, "f");
      __classPrivateFieldSet(this, _WorkPoller_requestOpts, opts.requestOptions, "f");
      __classPrivateFieldSet(this, _WorkPoller_controller, new AbortController(), "f");
      __classPrivateFieldSet(this, _WorkPoller_detachExternal, linkAbort(opts.signal, __classPrivateFieldGet(this, _WorkPoller_controller, "f")), "f");
    }
    /** Read-only view of this iterator's abort signal. */
    get signal() {
      return __classPrivateFieldGet(this, _WorkPoller_controller, "f").signal;
    }
    /** Abort the iterator. The current `for await` will exit cleanly. */
    abort() {
      __classPrivateFieldGet(this, _WorkPoller_controller, "f").abort();
    }
    async *[(_WorkPoller_runnerClient = /* @__PURE__ */ new WeakMap(), _WorkPoller_consumed = /* @__PURE__ */ new WeakMap(), _WorkPoller_controller = /* @__PURE__ */ new WeakMap(), _WorkPoller_detachExternal = /* @__PURE__ */ new WeakMap(), _WorkPoller_autoStop = /* @__PURE__ */ new WeakMap(), _WorkPoller_drain = /* @__PURE__ */ new WeakMap(), _WorkPoller_blockMs = /* @__PURE__ */ new WeakMap(), _WorkPoller_reclaimOlderThanMs = /* @__PURE__ */ new WeakMap(), _WorkPoller_requestOpts = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
      if (__classPrivateFieldGet(this, _WorkPoller_consumed, "f")) {
        throw new AnthropicError("Cannot iterate over a consumed WorkPoller");
      }
      __classPrivateFieldSet(this, _WorkPoller_consumed, true, "f");
      const log = loggerFor(this.client);
      log.info("poller starting", {
        component: "work-poller",
        environment_id: this.environmentId
      });
      const idle = new IdleLog(log, this.environmentId);
      try {
        let attempt = 0;
        while (!__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal.aborted) {
          let work;
          try {
            work = await __classPrivateFieldGet(this, _WorkPoller_runnerClient, "f").beta.environments.work.poll(this.environmentId, {
              "Anthropic-Worker-ID": this.workerId,
              ...__classPrivateFieldGet(this, _WorkPoller_blockMs, "f") !== null ? { block_ms: __classPrivateFieldGet(this, _WorkPoller_blockMs, "f") } : {},
              ...__classPrivateFieldGet(this, _WorkPoller_reclaimOlderThanMs, "f") !== null ? { reclaim_older_than_ms: __classPrivateFieldGet(this, _WorkPoller_reclaimOlderThanMs, "f") } : {}
            }, { headers: buildHeaders([__classPrivateFieldGet(this, _WorkPoller_requestOpts, "f")?.headers]), signal: __classPrivateFieldGet(this, _WorkPoller_controller, "f").signal });
          } catch (e) {
            if (__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal.aborted)
              return;
            if (isFatal4xx(e)) {
              log.error("poll failed permanently, stopping poller", { error: String(e) });
              throw e;
            }
            const wait = applyJitter(backoff2(attempt));
            log.warn("poll failed, backing off", { error: String(e), backoff_ms: wait });
            attempt++;
            await sleep(wait, __classPrivateFieldGet(this, _WorkPoller_controller, "f").signal);
            continue;
          }
          attempt = 0;
          if (work == null) {
            if (__classPrivateFieldGet(this, _WorkPoller_drain, "f"))
              return;
            idle.onEmptyPoll();
            await sleep(jitter(1e3, 3e3), __classPrivateFieldGet(this, _WorkPoller_controller, "f").signal);
            continue;
          }
          idle.onClaim();
          log.info("claimed work", {
            component: "work-poller",
            environment_id: this.environmentId,
            work_id: work.id,
            work_type: work.data.type
          });
          try {
            await __classPrivateFieldGet(this, _WorkPoller_runnerClient, "f").beta.environments.work.ack(work.id, { environment_id: work.environment_id }, { headers: buildHeaders([__classPrivateFieldGet(this, _WorkPoller_requestOpts, "f")?.headers]), signal: __classPrivateFieldGet(this, _WorkPoller_controller, "f").signal });
          } catch (e) {
            log.error("ack failed", { work_id: work.id, error: String(e) });
            continue;
          }
          try {
            yield work;
          } finally {
            if (__classPrivateFieldGet(this, _WorkPoller_autoStop, "f")) {
              try {
                await __classPrivateFieldGet(this, _WorkPoller_runnerClient, "f").beta.environments.work.stop(work.id, { environment_id: work.environment_id }, { headers: buildHeaders([__classPrivateFieldGet(this, _WorkPoller_requestOpts, "f")?.headers]) });
              } catch (e) {
                if (!isStatus(e, 409))
                  log.warn("stop failed", { work_id: work.id, error: String(e) });
              }
            }
          }
        }
      } finally {
        __classPrivateFieldGet(this, _WorkPoller_detachExternal, "f").call(this);
      }
    }
  }
  return WorkPoller2;
})();
function backoff2(attempt) {
  return backoff(attempt, POLL_BACKOFF_BASE_MS, POLL_BACKOFF_CAP_MS);
}
var IdleLog = /* @__PURE__ */ (() => {
  class IdleLog2 {
    constructor(log, environmentId) {
      _IdleLog_log.set(this, void 0);
      _IdleLog_environmentId.set(this, void 0);
      _IdleLog_idleSince.set(this, void 0);
      _IdleLog_lastReport.set(this, 0);
      __classPrivateFieldSet(this, _IdleLog_log, log, "f");
      __classPrivateFieldSet(this, _IdleLog_environmentId, environmentId, "f");
    }
    onEmptyPoll() {
      const now = Date.now();
      const fields = { component: "work-poller", environment_id: __classPrivateFieldGet(this, _IdleLog_environmentId, "f") };
      if (__classPrivateFieldGet(this, _IdleLog_idleSince, "f") === void 0) {
        __classPrivateFieldSet(this, _IdleLog_idleSince, __classPrivateFieldSet(this, _IdleLog_lastReport, now, "f"), "f");
        __classPrivateFieldGet(this, _IdleLog_log, "f").info("idle; polling for work", fields);
      } else if (now - __classPrivateFieldGet(this, _IdleLog_lastReport, "f") >= IDLE_REPORT_INTERVAL_MS) {
        __classPrivateFieldSet(this, _IdleLog_lastReport, now, "f");
        __classPrivateFieldGet(this, _IdleLog_log, "f").info(`still polling; idle for ${Math.round((now - __classPrivateFieldGet(this, _IdleLog_idleSince, "f")) / 1e3)}s`, fields);
      } else {
        __classPrivateFieldGet(this, _IdleLog_log, "f").debug("poll returned no work", fields);
      }
    }
    onClaim() {
      __classPrivateFieldSet(this, _IdleLog_idleSince, void 0, "f");
    }
  }
  _IdleLog_log = /* @__PURE__ */ new WeakMap(), _IdleLog_environmentId = /* @__PURE__ */ new WeakMap(), _IdleLog_idleSince = /* @__PURE__ */ new WeakMap(), _IdleLog_lastReport = /* @__PURE__ */ new WeakMap();
  return IdleLog2;
})();
function defaultWorkerId() {
  const env = globalThis.process?.env;
  const host = env?.["HOSTNAME"];
  return host ? `${host}-${uuid4()}` : uuid4();
}

// node_modules/@anthropic-ai/sdk/lib/environments/worker.mjs
init_error();

// node_modules/@anthropic-ai/sdk/lib/tools/SessionToolRunner.mjs
init_error();

// node_modules/@anthropic-ai/sdk/internal/utils/async-queue.mjs
var _AsyncQueue_items;
var _AsyncQueue_waiters;
var _AsyncQueue_closed;
var AsyncQueue = /* @__PURE__ */ (() => {
  class AsyncQueue2 {
    constructor() {
      _AsyncQueue_items.set(this, []);
      _AsyncQueue_waiters.set(this, []);
      _AsyncQueue_closed.set(this, false);
    }
    /** Enqueue an item, or hand it directly to a waiting reader. Returns `false` once closed. */
    push(item) {
      if (__classPrivateFieldGet(this, _AsyncQueue_closed, "f"))
        return false;
      const w = __classPrivateFieldGet(this, _AsyncQueue_waiters, "f").shift();
      if (w)
        w({ done: false, value: item });
      else
        __classPrivateFieldGet(this, _AsyncQueue_items, "f").push(item);
      return true;
    }
    /** Mark the queue done. Idempotent; wakes every pending reader with `done: true`. */
    close() {
      if (__classPrivateFieldGet(this, _AsyncQueue_closed, "f"))
        return;
      __classPrivateFieldSet(this, _AsyncQueue_closed, true, "f");
      while (__classPrivateFieldGet(this, _AsyncQueue_waiters, "f").length > 0) {
        const w = __classPrivateFieldGet(this, _AsyncQueue_waiters, "f").shift();
        w({ done: true, value: void 0 });
      }
    }
    /**
     * Resolve with the next item, or `done: true` once the queue is closed and
     * drained. When `signal` is supplied, aborting it resolves a pending read
     * with `done: true` (cancellation is pushed down here rather than handled by
     * an outer `Promise.race`).
     */
    next(signal) {
      if (__classPrivateFieldGet(this, _AsyncQueue_items, "f").length > 0) {
        return Promise.resolve({ done: false, value: __classPrivateFieldGet(this, _AsyncQueue_items, "f").shift() });
      }
      if (__classPrivateFieldGet(this, _AsyncQueue_closed, "f") || signal?.aborted) {
        return Promise.resolve({ done: true, value: void 0 });
      }
      return new Promise((resolve) => {
        const waiter = (r) => {
          signal?.removeEventListener("abort", onAbort);
          resolve(r);
        };
        const onAbort = () => {
          const idx = __classPrivateFieldGet(this, _AsyncQueue_waiters, "f").indexOf(waiter);
          if (idx >= 0)
            __classPrivateFieldGet(this, _AsyncQueue_waiters, "f").splice(idx, 1);
          resolve({ done: true, value: void 0 });
        };
        __classPrivateFieldGet(this, _AsyncQueue_waiters, "f").push(waiter);
        signal?.addEventListener("abort", onAbort, { once: true });
      });
    }
    /** Synchronously remove and return the next buffered item, or `undefined` if empty. */
    tryShift() {
      return __classPrivateFieldGet(this, _AsyncQueue_items, "f").shift();
    }
  }
  _AsyncQueue_items = /* @__PURE__ */ new WeakMap(), _AsyncQueue_waiters = /* @__PURE__ */ new WeakMap(), _AsyncQueue_closed = /* @__PURE__ */ new WeakMap();
  return AsyncQueue2;
})();

// node_modules/@anthropic-ai/sdk/lib/tools/ToolError.mjs
var ToolError = /* @__PURE__ */ (() => {
  class ToolError2 extends Error {
    constructor(content) {
      const message = typeof content === "string" ? content : content.map((block) => {
        if (block.type === "text")
          return block.text;
        return `[${block.type}]`;
      }).join(" ");
      super(message);
      this.name = "ToolError";
      this.content = content;
    }
  }
  return ToolError2;
})();

// node_modules/@anthropic-ai/sdk/lib/internal/toolsets/sanitize.mjs
var LINE_UNSAFE = "\\x00-\\x1f\\x7f-\\x9f\\u061c\\u200e\\u200f\\u2028\\u2029\\u202a-\\u202e\\u2066-\\u2069";
var CONTROL_RE = /* @__PURE__ */ (() => new RegExp(`[${LINE_UNSAFE}]+`, "g"))();
var LONE_SURROGATE_RE = /[\uD800-\uDFFF]/gu;
function wellFormed(text) {
  return text.replace(LONE_SURROGATE_RE, "\uFFFD");
}
var FIELD_MAX = 4096;
var LOG_MAX = 200;
function oneLine(text, limit2 = FIELD_MAX) {
  return cutPoints(wellFormed(text).replace(CONTROL_RE, " ").trim(), limit2);
}
function logSafe(name) {
  return oneLine(name, LOG_MAX);
}
function quotedName(name) {
  return logSafe(name).replace(/[' ]+/g, " ").trim();
}
function thrownErrorText(e) {
  return `Error: ${e instanceof Error ? e.message : String(e)}`;
}
function errorText(error) {
  return cutPoints(wellFormed(thrownErrorText(error)), FIELD_MAX);
}
function cutPoints(text, limit2) {
  if (text.length <= limit2)
    return text;
  let end = 0;
  let points = 0;
  for (const ch of text) {
    if (points === limit2)
      break;
    points += 1;
    end += ch.length;
  }
  return text.slice(0, end);
}
function errorTextContent(content) {
  if (typeof content === "string")
    return wellFormed(content);
  return content.filter((block) => block.type === "text" && block.text !== "").map((block) => ({ ...block, text: wellFormed(block.text) }));
}

// node_modules/@anthropic-ai/sdk/lib/tools/BetaRunnableTool.mjs
function toolName(tool) {
  return "name" in tool ? tool.name : "mcp_server_name" in tool ? tool.mcp_server_name : tool.type;
}
function toolErrorContent(e) {
  return e instanceof ToolError ? e.content : thrownErrorText(e);
}
async function runRunnableTool(tool, rawInput, context) {
  try {
    const input = tool.parse ? tool.parse(rawInput) : rawInput;
    const content = await tool.run(input, context);
    return { content, isError: false };
  } catch (e) {
    return { content: toolErrorContent(e), isError: true };
  }
}

// node_modules/@anthropic-ai/sdk/lib/tools/SessionToolRunner.mjs
var _IdleClock_maxIdleMs;
var _IdleClock_onExpire;
var _IdleClock_blockers;
var _IdleClock_armPending;
var _IdleClock_timer;
var _SessionToolRunner_instances;
var _SessionToolRunner_consumed;
var _SessionToolRunner_controller;
var _SessionToolRunner_detachExternal;
var _SessionToolRunner_requestOpts;
var _SessionToolRunner_toolByName;
var _SessionToolRunner_logger;
var _SessionToolRunner_seen;
var _SessionToolRunner_answered;
var _SessionToolRunner_confirmationVerdicts;
var _SessionToolRunner_awaitingConfirmation;
var _SessionToolRunner_results;
var _SessionToolRunner_inFlightCount;
var _SessionToolRunner_sendRetryWindowMs;
var _SessionToolRunner_onIdle;
var _SessionToolRunner_idleClock;
var _SessionToolRunner_requestOptions;
var _SessionToolRunner_streamLoop;
var _SessionToolRunner_reconcile;
var _SessionToolRunner_ingestHistory;
var _SessionToolRunner_handleStreamEvent;
var _SessionToolRunner_routeToolEvent;
var _SessionToolRunner_noteConfirmation;
var _SessionToolRunner_applyVerdict;
var _SessionToolRunner_surfaceCall;
var _SessionToolRunner_execute;
var _SessionToolRunner_sendResult;
var _SessionToolRunner_drain;
var STREAM_BACKOFF_START_MS = 500;
var STREAM_BACKOFF_CAP_MS = 1e4;
var TOOL_TIMEOUT_MS = 12e4;
var DRAIN_TIMEOUT_MS = 3e4;
var SEND_BACKOFF_START_MS = 1e3;
var SEND_BACKOFF_CAP_MS = 3e4;
var SEND_RETRY_WINDOW_MS = 5 * 6e4;
var DEFAULT_MAX_IDLE_MS = 6e4;
function endsTurn(ev) {
  if (ev.type !== "session.status_idle")
    return false;
  return ev.stop_reason?.type !== "requires_action";
}
var IdleClock = /* @__PURE__ */ (() => {
  class IdleClock2 {
    constructor(maxIdleMs, onExpire) {
      _IdleClock_maxIdleMs.set(this, void 0);
      _IdleClock_onExpire.set(this, void 0);
      _IdleClock_blockers.set(this, /* @__PURE__ */ new Set());
      _IdleClock_armPending.set(this, false);
      _IdleClock_timer.set(this, void 0);
      __classPrivateFieldSet(this, _IdleClock_maxIdleMs, maxIdleMs, "f");
      __classPrivateFieldSet(this, _IdleClock_onExpire, onExpire, "f");
    }
    /**
     * Arm on an idle that ends the turn; disarm otherwise. `user.tool_confirmation`
     * is neutral: it signals neither agent activity nor an idle, and its effect
     * on the clock flows through {@link block} / {@link unblock} instead —
     * disarming here would discard the pending arm the verdict is about to
     * settle.
     */
    noteEvent(ev) {
      if (ev.type === "user.tool_confirmation")
        return;
      if (endsTurn(ev))
        this.arm();
      else
        this.disarm();
    }
    /** Register gated work that must resolve before an idle countdown starts. */
    block(toolUseId) {
      __classPrivateFieldGet(this, _IdleClock_blockers, "f").add(toolUseId);
      if (__classPrivateFieldGet(this, _IdleClock_timer, "f") !== void 0) {
        __classPrivateFieldSet(this, _IdleClock_armPending, true, "f");
        clearTimeout(__classPrivateFieldGet(this, _IdleClock_timer, "f"));
        __classPrivateFieldSet(this, _IdleClock_timer, void 0, "f");
      }
    }
    /**
     * Retire gated work (a no-op for ids never blocked); applies a pending arm —
     * with a fresh full `maxIdleMs` window — once the last blocker retires.
     */
    unblock(toolUseId) {
      __classPrivateFieldGet(this, _IdleClock_blockers, "f").delete(toolUseId);
      if (__classPrivateFieldGet(this, _IdleClock_blockers, "f").size === 0 && __classPrivateFieldGet(this, _IdleClock_armPending, "f"))
        this.arm();
    }
    /**
     * (Re)start the idle countdown — or, while blockers are outstanding, hold
     * the arm pending instead. Stopping then would drop a held call when its
     * verdict later arrives, or cut the runner off before a released call's
     * result can drive the next turn.
     */
    arm() {
      if (__classPrivateFieldGet(this, _IdleClock_maxIdleMs, "f") <= 0)
        return;
      if (__classPrivateFieldGet(this, _IdleClock_blockers, "f").size > 0) {
        __classPrivateFieldSet(this, _IdleClock_armPending, true, "f");
        return;
      }
      __classPrivateFieldSet(this, _IdleClock_armPending, false, "f");
      if (__classPrivateFieldGet(this, _IdleClock_timer, "f") !== void 0)
        clearTimeout(__classPrivateFieldGet(this, _IdleClock_timer, "f"));
      __classPrivateFieldSet(this, _IdleClock_timer, setTimeout(__classPrivateFieldGet(this, _IdleClock_onExpire, "f"), __classPrivateFieldGet(this, _IdleClock_maxIdleMs, "f")), "f");
    }
    /**
     * Cancel the idle countdown and any pending arm. Blockers persist — they
     * track real outstanding work, retired only by {@link unblock}.
     */
    disarm() {
      __classPrivateFieldSet(this, _IdleClock_armPending, false, "f");
      if (__classPrivateFieldGet(this, _IdleClock_timer, "f") !== void 0) {
        clearTimeout(__classPrivateFieldGet(this, _IdleClock_timer, "f"));
        __classPrivateFieldSet(this, _IdleClock_timer, void 0, "f");
      }
    }
  }
  _IdleClock_maxIdleMs = /* @__PURE__ */ new WeakMap(), _IdleClock_onExpire = /* @__PURE__ */ new WeakMap(), _IdleClock_blockers = /* @__PURE__ */ new WeakMap(), _IdleClock_armPending = /* @__PURE__ */ new WeakMap(), _IdleClock_timer = /* @__PURE__ */ new WeakMap();
  return IdleClock2;
})();
var SessionToolRunner = /* @__PURE__ */ (() => {
  class SessionToolRunner2 {
    constructor(sessionId, opts) {
      _SessionToolRunner_instances.add(this);
      _SessionToolRunner_consumed.set(this, false);
      _SessionToolRunner_controller.set(this, void 0);
      _SessionToolRunner_detachExternal.set(this, void 0);
      _SessionToolRunner_requestOpts.set(this, void 0);
      _SessionToolRunner_toolByName.set(this, void 0);
      _SessionToolRunner_logger.set(this, void 0);
      _SessionToolRunner_seen.set(this, /* @__PURE__ */ new Set());
      _SessionToolRunner_answered.set(this, /* @__PURE__ */ new Set());
      _SessionToolRunner_confirmationVerdicts.set(this, /* @__PURE__ */ new Map());
      _SessionToolRunner_awaitingConfirmation.set(this, /* @__PURE__ */ new Map());
      _SessionToolRunner_results.set(this, new AsyncQueue());
      _SessionToolRunner_inFlightCount.set(this, 0);
      _SessionToolRunner_sendRetryWindowMs.set(this, SEND_RETRY_WINDOW_MS);
      _SessionToolRunner_onIdle.set(this, null);
      _SessionToolRunner_idleClock.set(this, void 0);
      this.client = opts.client;
      this.sessionId = sessionId;
      this.tools = opts.tools;
      this.maxIdleMs = opts.maxIdleMs ?? DEFAULT_MAX_IDLE_MS;
      __classPrivateFieldSet(this, _SessionToolRunner_logger, loggerFor(opts.client), "f");
      __classPrivateFieldSet(this, _SessionToolRunner_toolByName, new Map(opts.tools.map((t) => [toolName(t), t])), "f");
      __classPrivateFieldSet(this, _SessionToolRunner_controller, new AbortController(), "f");
      __classPrivateFieldSet(this, _SessionToolRunner_detachExternal, linkAbort(opts.signal, __classPrivateFieldGet(this, _SessionToolRunner_controller, "f")), "f");
      __classPrivateFieldSet(this, _SessionToolRunner_requestOpts, opts.requestOptions, "f");
      __classPrivateFieldSet(this, _SessionToolRunner_idleClock, new IdleClock(this.maxIdleMs, () => {
        __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("session idle after its turn ended; stopping", {
          component: "session-tool-runner",
          session_id: this.sessionId,
          max_idle_ms: this.maxIdleMs
        });
        __classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
      }), "f");
    }
    /** Read-only view of this runner's abort signal. */
    get signal() {
      return __classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal;
    }
    /** Abort the runner. Background tasks will wind down and `for await` will exit cleanly. */
    abort() {
      __classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
    }
    /**
     * @internal
     * `EnvironmentWorker` keeps this equal to the lease TTL each heartbeat
     * reports; applies to a send already retrying.
     */
    _setSendRetryWindow(ms) {
      __classPrivateFieldSet(this, _SessionToolRunner_sendRetryWindowMs, ms, "f");
    }
    async *[(_SessionToolRunner_consumed = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_controller = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_detachExternal = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_requestOpts = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_toolByName = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_logger = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_seen = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_answered = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_confirmationVerdicts = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_awaitingConfirmation = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_results = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_inFlightCount = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_sendRetryWindowMs = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_onIdle = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_idleClock = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_instances = /* @__PURE__ */ new WeakSet(), Symbol.asyncIterator)]() {
      if (__classPrivateFieldGet(this, _SessionToolRunner_consumed, "f")) {
        throw new AnthropicError("Cannot iterate over a consumed SessionToolRunner");
      }
      __classPrivateFieldSet(this, _SessionToolRunner_consumed, true, "f");
      __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("session tool runner starting", {
        component: "session-tool-runner",
        session_id: this.sessionId
      });
      const streamPromise = __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_streamLoop).call(this).catch((e) => {
        if (!__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal.aborted) {
          __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").error("stream loop failed", { error: String(e) });
        }
        __classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
      });
      try {
        while (true) {
          const next = await __classPrivateFieldGet(this, _SessionToolRunner_results, "f").next(__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal);
          if (next.done)
            break;
          yield next.value;
        }
        await streamPromise;
        let pending;
        while ((pending = __classPrivateFieldGet(this, _SessionToolRunner_results, "f").tryShift()) !== void 0) {
          yield pending;
        }
      } finally {
        __classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
        __classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").disarm();
        await streamPromise;
        try {
          await __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_drain).call(this);
        } catch (e) {
          __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("drain failed", { error: String(e) });
        }
        __classPrivateFieldGet(this, _SessionToolRunner_results, "f").close();
        for (const t of this.tools) {
          try {
            await t.close?.();
          } catch (e) {
            __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("tool.close failed", { tool: toolName(t), error: String(e) });
          }
        }
        __classPrivateFieldGet(this, _SessionToolRunner_detachExternal, "f").call(this);
      }
    }
  }
  _SessionToolRunner_requestOptions = function _SessionToolRunner_requestOptions2() {
    return {
      ...__classPrivateFieldGet(this, _SessionToolRunner_requestOpts, "f"),
      headers: buildHeaders([helperHeader("session-tool-runner"), __classPrivateFieldGet(this, _SessionToolRunner_requestOpts, "f")?.headers]),
      signal: __classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal
    };
  }, _SessionToolRunner_streamLoop = // ===== event stream =====
  async function _SessionToolRunner_streamLoop2() {
    const ctrl = __classPrivateFieldGet(this, _SessionToolRunner_controller, "f");
    let backoff3 = STREAM_BACKOFF_START_MS;
    while (!ctrl.signal.aborted) {
      try {
        const stream2 = await this.client.beta.sessions.events.stream(this.sessionId, {}, __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_requestOptions).call(this));
        await __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_reconcile).call(this);
        for await (const ev of stream2) {
          backoff3 = STREAM_BACKOFF_START_MS;
          if (await __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_handleStreamEvent).call(this, ev))
            return;
        }
      } catch (e) {
        ctrl.signal.throwIfAborted();
        if (isFatal4xx(e)) {
          __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").error("permanent stream failure, shutting down", { error: String(e) });
          ctrl.abort();
          throw e;
        }
        __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("stream disconnected, reconnecting", {
          error: String(e),
          backoff_ms: backoff3
        });
      }
      ctrl.signal.throwIfAborted();
      await sleep(backoff3, ctrl.signal);
      backoff3 = Math.min(backoff3 * 2, STREAM_BACKOFF_CAP_MS);
    }
  }, _SessionToolRunner_reconcile = /**
   * Read full history before dispatching so a `tool_use` whose result appears
   * later in the same history is not re-executed. Runs after the live stream is
   * already attached (see {@link SessionToolRunner.#streamLoop}).
   */
  async function _SessionToolRunner_reconcile2() {
    const ctrl = __classPrivateFieldGet(this, _SessionToolRunner_controller, "f");
    const pending = [];
    let lastEndedTurn = false;
    try {
      for await (const ev of this.client.beta.sessions.events.list(this.sessionId, { limit: 1e3 }, __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_requestOptions).call(this))) {
        __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_ingestHistory).call(this, ev, pending);
        if (ev.type !== "user.tool_confirmation")
          lastEndedTurn = endsTurn(ev);
      }
    } catch (e) {
      ctrl.signal.throwIfAborted();
      __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("reconcile list failed", { error: String(e) });
      for (const ev of pending)
        __classPrivateFieldGet(this, _SessionToolRunner_seen, "f").delete(ev.id);
      return;
    }
    const unanswered = pending.filter((ev) => !__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").has(ev.id));
    __classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").disarm();
    for (const ev of unanswered)
      await __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_routeToolEvent).call(this, ev);
    for (const held of [...__classPrivateFieldGet(this, _SessionToolRunner_awaitingConfirmation, "f").values()]) {
      const verdict = __classPrivateFieldGet(this, _SessionToolRunner_confirmationVerdicts, "f").get(held.id);
      if (verdict !== void 0)
        await __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_applyVerdict).call(this, held, verdict);
    }
    const outstanding = unanswered.filter((ev) => !__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").has(ev.id) && !__classPrivateFieldGet(this, _SessionToolRunner_awaitingConfirmation, "f").has(ev.id));
    if (lastEndedTurn && outstanding.length === 0)
      __classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").arm();
    else
      __classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").disarm();
  }, _SessionToolRunner_ingestHistory = function _SessionToolRunner_ingestHistory2(ev, pending) {
    if (ev.type === "agent.tool_use" || ev.type === "agent.custom_tool_use") {
      __classPrivateFieldGet(this, _SessionToolRunner_seen, "f").add(ev.id);
      if (!__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").has(ev.id))
        pending.push(ev);
    } else if (ev.type === "user.tool_result") {
      __classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.tool_use_id);
    } else if (ev.type === "user.custom_tool_result") {
      __classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.custom_tool_use_id);
    } else if (ev.type === "user.tool_confirmation") {
      if (!__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").has(ev.tool_use_id))
        __classPrivateFieldGet(this, _SessionToolRunner_confirmationVerdicts, "f").set(ev.tool_use_id, ev.result);
    }
  }, _SessionToolRunner_handleStreamEvent = /** Returns true when the runner should exit. */
  async function _SessionToolRunner_handleStreamEvent2(ev) {
    __classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").noteEvent(ev);
    switch (ev.type) {
      case "agent.tool_use":
      case "agent.custom_tool_use":
        if (!__classPrivateFieldGet(this, _SessionToolRunner_seen, "f").has(ev.id)) {
          __classPrivateFieldGet(this, _SessionToolRunner_seen, "f").add(ev.id);
          await __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_routeToolEvent).call(this, ev);
        }
        return false;
      case "user.tool_confirmation":
        await __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_noteConfirmation).call(this, ev);
        return false;
      case "user.tool_result":
        __classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.tool_use_id);
        return false;
      case "user.custom_tool_result":
        __classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.custom_tool_use_id);
        return false;
      case "session.status_terminated":
      case "session.deleted":
        __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("session terminated", {
          component: "session-tool-runner",
          session_id: this.sessionId
        });
        __classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
        return true;
      default:
        return false;
    }
  }, _SessionToolRunner_routeToolEvent = // ===== confirmation gating (always_ask tools) =====
  /**
   * Dispatch `ev`, honoring its evaluated permission. A call the server gated
   * (`evaluated_permission == "ask"`) is held until its `user.tool_confirmation`
   * arrives. Fails closed: only an explicit `allow` verdict releases a gated
   * call; a server-side `deny` overrides any recorded verdict; an unrecognized
   * permission is held like `ask` and an unrecognized verdict is denied.
   */
  async function _SessionToolRunner_routeToolEvent2(ev) {
    const permission = ev.evaluated_permission;
    const verdict = permission === "deny" ? "deny" : __classPrivateFieldGet(this, _SessionToolRunner_confirmationVerdicts, "f").get(ev.id);
    if (verdict === void 0) {
      if (permission === void 0 || permission === "allow") {
        await __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_execute).call(this, ev, void 0);
      } else if (!__classPrivateFieldGet(this, _SessionToolRunner_awaitingConfirmation, "f").has(ev.id)) {
        __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("tool call awaiting confirmation; holding", {
          component: "session-tool-runner",
          session_id: this.sessionId,
          tool: ev.name,
          tool_use_id: ev.id
        });
        __classPrivateFieldGet(this, _SessionToolRunner_awaitingConfirmation, "f").set(ev.id, ev);
        __classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").block(ev.id);
      }
      return;
    }
    await __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_applyVerdict).call(this, ev, verdict);
  }, _SessionToolRunner_noteConfirmation = /** Record an allow/deny verdict and release the held call it gates, if any. */
  async function _SessionToolRunner_noteConfirmation2(ev) {
    __classPrivateFieldGet(this, _SessionToolRunner_confirmationVerdicts, "f").set(ev.tool_use_id, ev.result);
    const held = __classPrivateFieldGet(this, _SessionToolRunner_awaitingConfirmation, "f").get(ev.tool_use_id);
    if (held === void 0)
      return;
    await __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_applyVerdict).call(this, held, ev.result);
  }, _SessionToolRunner_applyVerdict = /**
   * Dispatch or resolve a gated call according to its verdict.
   *
   * The idle-clock blocker accounting lives here: a denial retires the held
   * call's blocker, while an allow keeps one on the call — taking it now if the
   * verdict was already known when the call was routed, so it was never held —
   * until `#execute` has finished with it. The countdown must not run over
   * gated work that is still in flight.
   */
  async function _SessionToolRunner_applyVerdict2(ev, verdict) {
    const wasHeld = __classPrivateFieldGet(this, _SessionToolRunner_awaitingConfirmation, "f").delete(ev.id);
    if (verdict === "allow") {
      __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("tool call confirmed", {
        component: "session-tool-runner",
        session_id: this.sessionId,
        tool: ev.name,
        tool_use_id: ev.id
      });
      if (!wasHeld)
        __classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").block(ev.id);
      try {
        await __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_execute).call(this, ev, "allow");
      } finally {
        __classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").unblock(ev.id);
      }
      return;
    }
    if (wasHeld)
      __classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").unblock(ev.id);
    __classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.id);
    __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("tool call denied; not executing", {
      component: "session-tool-runner",
      session_id: this.sessionId,
      tool: ev.name,
      tool_use_id: ev.id
    });
    __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_surfaceCall).call(this, {
      event: ev,
      toolUseId: ev.id,
      name: ev.name,
      isError: false,
      posted: false,
      confirmation: "deny"
    });
  }, _SessionToolRunner_surfaceCall = function _SessionToolRunner_surfaceCall2(call) {
    __classPrivateFieldGet(this, _SessionToolRunner_results, "f").push(call);
  }, _SessionToolRunner_execute = // ===== tool execution =====
  async function _SessionToolRunner_execute2(ev, confirmation) {
    var _a2, _b;
    if (__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").has(ev.id))
      return;
    __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("executing tool", {
      component: "session-tool-runner",
      session_id: this.sessionId,
      tool: ev.name,
      tool_use_id: ev.id
    });
    __classPrivateFieldSet(this, _SessionToolRunner_inFlightCount, (_a2 = __classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f"), _a2++, _a2), "f");
    try {
      const tool = __classPrivateFieldGet(this, _SessionToolRunner_toolByName, "f").get(ev.name);
      if (!tool) {
        __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("tool not owned by this runner; leaving the tool_use_id pending for its owner", {
          component: "session-tool-runner",
          session_id: this.sessionId,
          tool: ev.name,
          tool_use_id: ev.id
        });
        if (confirmation === "allow")
          __classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").disarm();
        __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_surfaceCall).call(this, {
          event: ev,
          toolUseId: ev.id,
          name: ev.name,
          isError: false,
          posted: false,
          confirmation
        });
        return;
      }
      let content;
      let isError;
      const toolCtrl = new AbortController();
      const detachTool = linkAbort(__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal, toolCtrl);
      const timer = setTimeout(() => toolCtrl.abort(), TOOL_TIMEOUT_MS);
      try {
        const outcome = await runRunnableTool(tool, ev.input, {
          toolUse: ev,
          toolUseBlock: ev,
          signal: toolCtrl.signal
        });
        content = outcome.content;
        isError = outcome.isError;
      } finally {
        clearTimeout(timer);
        detachTool();
      }
      const result = buildResultEvent(ev, isError, toSessionContent(content));
      const posted = await __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_sendResult).call(this, result, ev.id);
      __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_surfaceCall).call(this, {
        event: ev,
        result,
        toolUseId: ev.id,
        name: ev.name,
        isError,
        posted,
        confirmation
      });
    } finally {
      __classPrivateFieldSet(this, _SessionToolRunner_inFlightCount, (_b = __classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f"), _b--, _b), "f");
      if (__classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f") === 0)
        __classPrivateFieldGet(this, _SessionToolRunner_onIdle, "f")?.call(this);
    }
  }, _SessionToolRunner_sendResult = async function _SessionToolRunner_sendResult2(result, toolUseId) {
    const ctrl = __classPrivateFieldGet(this, _SessionToolRunner_controller, "f");
    const start = Date.now();
    let lastErr;
    let attempt = 0;
    while (true) {
      attempt++;
      ctrl.signal.throwIfAborted();
      try {
        await this.client.beta.sessions.events.send(this.sessionId, { events: [result] }, __classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_requestOptions).call(this));
        __classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(toolUseId);
        return true;
      } catch (e) {
        lastErr = e;
        if (isFatal4xx(e))
          break;
        const remainingMs = __classPrivateFieldGet(this, _SessionToolRunner_sendRetryWindowMs, "f") - (Date.now() - start);
        if (remainingMs <= 0)
          break;
        const waitMs = Math.min(applyJitter(backoff(attempt - 1, SEND_BACKOFF_START_MS, SEND_BACKOFF_CAP_MS)), remainingMs);
        __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("tool result send failed; retrying", {
          tool_use_id: toolUseId,
          attempt,
          backoff_ms: waitMs,
          error: String(e)
        });
        await sleep(waitMs, ctrl.signal);
      }
    }
    __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").error("failed to send tool result", {
      tool_use_id: toolUseId,
      attempts: attempt,
      error: String(lastErr)
    });
    return false;
  }, _SessionToolRunner_drain = /** Wait (bounded) for in-flight tool executions to finish during teardown. */
  async function _SessionToolRunner_drain2() {
    if (__classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f") === 0)
      return;
    await Promise.race([new Promise((r) => __classPrivateFieldSet(this, _SessionToolRunner_onIdle, r, "f")), sleep(DRAIN_TIMEOUT_MS)]);
    __classPrivateFieldSet(this, _SessionToolRunner_onIdle, null, "f");
    if (__classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f") > 0) {
      __classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("drain timeout exceeded");
    }
  };
  return SessionToolRunner2;
})();
function buildResultEvent(ev, isError, content) {
  if (ev.type === "agent.custom_tool_use") {
    return { type: "user.custom_tool_result", custom_tool_use_id: ev.id, is_error: isError, content };
  }
  return { type: "user.tool_result", tool_use_id: ev.id, is_error: isError, content };
}
function toSessionContent(content) {
  if (typeof content === "string")
    return [{ type: "text", text: content || "(no output)" }];
  const out = content.map((b) => {
    if (b.type === "text")
      return { type: "text", text: b.text || "(no output)" };
    if (b.type === "image" || b.type === "document")
      return b;
    if (b.type === "search_result") {
      return {
        type: "search_result",
        source: b.source,
        title: b.title,
        content: b.content.map((c) => ({ type: "text", text: c.text })),
        citations: { enabled: b.citations?.enabled ?? false }
      };
    }
    return { type: "text", text: JSON.stringify(b) };
  });
  return out.length > 0 ? out : [{ type: "text", text: "(no output)" }];
}

// node_modules/@anthropic-ai/sdk/lib/environments/worker.mjs
init_sync_interval();
var _EnvironmentWorker_instances;
var _EnvironmentWorker_signal;
var _EnvironmentWorker_handleItem;
var _Lease_ctrl;
var _Lease_endReason;
var HEARTBEAT_DEFAULT_MS = 3e4;
var HEARTBEAT_TTL_DEFAULT_MS = 9e4;
var NO_HEARTBEAT_SENTINEL = "NO_HEARTBEAT";
function hasMemoryStore(session) {
  return session.resources.some((r) => r.type === "memory_store");
}
function sessionsTokenFromSecret(secret) {
  if (!secret)
    return null;
  let parsed;
  try {
    const normalized = secret.replace(/-/g, "+").replace(/_/g, "/");
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
    parsed = JSON.parse(decodeUTF8(fromBase64(padded)));
  } catch {
    return null;
  }
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed))
    return null;
  const token = parsed.sessions_token;
  return typeof token === "string" && token !== "" ? token : null;
}
var EnvironmentWorker = /* @__PURE__ */ (() => {
  class EnvironmentWorker2 {
    constructor(opts) {
      _EnvironmentWorker_instances.add(this);
      _EnvironmentWorker_signal.set(this, void 0);
      if (opts.unrestrictedPaths !== void 0) {
        throw new AnthropicError("The `unrestrictedPaths` option you passed to EnvironmentWorker (or client.beta.environments.work.worker()) is no longer supported. The worker's file tools (read, write, edit, glob, grep) are now always confined to `workdir` plus the session's memory folders. Remove `unrestrictedPaths` from your options; to let the file tools reach any other directory, add it to `AgentToolContext.allowedRoots` from a `tools` factory.");
      }
      this.client = opts.client;
      this.environmentId = opts.environmentId;
      this.environmentKey = opts.environmentKey;
      this.tools = opts.tools;
      this.workdir = opts.workdir ?? process.cwd();
      this.maxFileBytes = opts.maxFileBytes;
      this.maxIdleMs = opts.maxIdleMs;
      if (opts.memorySyncIntervalMs != null) {
        checkMemorySyncInterval(opts.memorySyncIntervalMs, "memorySyncIntervalMs");
      }
      this.memorySyncIntervalMs = opts.memorySyncIntervalMs;
      this.memorySyncDeletions = opts.memorySyncDeletions ?? "enabled";
      this.workerId = opts.workerId;
      this.requestOptions = opts.requestOptions;
      __classPrivateFieldSet(this, _EnvironmentWorker_signal, opts.signal, "f");
    }
    /**
     * Poll the environment and service each claimed session until the supplied
     * signal (or the one passed to the constructor) aborts. Throws if
     * `environmentId` / `environmentKey` were not provided to the constructor.
     */
    async run(signal) {
      const { environmentId, environmentKey } = this;
      if (environmentId === void 0 || environmentKey === void 0) {
        throw new AnthropicError("EnvironmentWorker.run: environmentId and environmentKey are required to poll for work");
      }
      const externalSignal = signal ?? __classPrivateFieldGet(this, _EnvironmentWorker_signal, "f");
      const poller = new WorkPoller({
        client: this.client,
        environmentId,
        environmentKey,
        ...this.workerId !== void 0 ? { workerId: this.workerId } : {},
        ...externalSignal ? { signal: externalSignal } : {},
        ...this.requestOptions !== void 0 ? { requestOptions: this.requestOptions } : {},
        // The per-item handler stops or releases every work item on exit; let it
        // be the single owner of `work.stop` rather than double-posting from the
        // poller.
        autoStop: false
      });
      for await (const work of poller) {
        try {
          await __classPrivateFieldGet(this, _EnvironmentWorker_instances, "m", _EnvironmentWorker_handleItem).call(this, work, environmentKey, poller.signal);
        } catch (e) {
          if (poller.signal?.aborted)
            throw e;
          loggerFor(this.client).error("work item failed", { work_id: work.id, error: String(e) });
        }
      }
    }
    /**
     * Service a single, already-claimed work item without the poll loop: build the
     * per-session {@link AgentToolContext} (workdir from this worker's options),
     * download the session agent's skills (`setupSkills`), run a
     * {@link SessionToolRunner} for the session while heartbeating the work-item
     * lease, and force-stop the work item on exit (whether the runner finishes
     * normally, throws, or the control plane signals shutdown). The one
     * exception is a lost lease: the item then belongs to the queue or another
     * worker and is left alone.
     *
     * Use this when something else does the claiming — e.g. a `worker poll
     * --on-work` script that hands an already-claimed item to a fresh process. The
     * work id / environment id / session id each fall back to `ANTHROPIC_WORK_ID` /
     * `ANTHROPIC_ENVIRONMENT_ID` / `ANTHROPIC_SESSION_ID` (the env vars that
     * command sets) when not passed; the environment key resolves from this
     * option, then the worker's own `environmentKey`, then
     * `ANTHROPIC_ENVIRONMENT_KEY`, and is needed only when the work item's
     * `secret` yields no sessions token — a host that receives only the
     * per-item secret runs without ever holding the key. With no arguments
     * inside that command it just works. Throws a clear error naming the first
     * required value still missing after resolution, and — rather than ever
     * running unauthenticated — when neither a sessions token nor an
     * environment key resolved. Throws `SessionMemoryError` when the
     * session has memory stores attached but they cannot be mounted — the work
     * item carried no sessions token (unless `memorySyncIntervalMs` turned
     * memory off), or a store failed to download.
     *
     * `workSecret` is the work item's per-item `secret` payload from the poll
     * response, falling back to `ANTHROPIC_WORK_SECRET`; unlike the others it is
     * optional — when present, the sessions token extracted from it is preferred
     * as the Bearer credential for this item's heartbeat / force-stop / session
     * calls; when absent (or undecodable) those calls use the environment key.
     */
    async handleItem(opts) {
      const workId = opts?.workId ?? readEnv("ANTHROPIC_WORK_ID");
      const environmentId = opts?.environmentId ?? readEnv("ANTHROPIC_ENVIRONMENT_ID");
      const sessionId = opts?.sessionId ?? readEnv("ANTHROPIC_SESSION_ID");
      const environmentKey = (opts?.environmentKey ?? this.environmentKey ?? readEnv("ANTHROPIC_ENVIRONMENT_KEY")) || void 0;
      const workSecret = opts?.workSecret || readEnv("ANTHROPIC_WORK_SECRET") || null;
      if (!workId) {
        throw new AnthropicError("handleItem: workId is required \u2014 pass it or set ANTHROPIC_WORK_ID");
      }
      if (!environmentId) {
        throw new AnthropicError("handleItem: environmentId is required \u2014 pass it or set ANTHROPIC_ENVIRONMENT_ID");
      }
      if (!sessionId) {
        throw new AnthropicError("handleItem: sessionId is required \u2014 pass it or set ANTHROPIC_SESSION_ID");
      }
      if (!environmentKey && !workSecret) {
        throw new AnthropicError("handleItem: environmentKey is required when there is no work secret \u2014 pass it, construct the worker with it, or set ANTHROPIC_ENVIRONMENT_KEY");
      }
      const work = {
        id: workId,
        environment_id: environmentId,
        secret: workSecret,
        data: { type: "session", id: sessionId }
      };
      await __classPrivateFieldGet(this, _EnvironmentWorker_instances, "m", _EnvironmentWorker_handleItem).call(this, work, environmentKey, opts?.signal ?? __classPrivateFieldGet(this, _EnvironmentWorker_signal, "f"));
    }
  }
  _EnvironmentWorker_signal = /* @__PURE__ */ new WeakMap(), _EnvironmentWorker_instances = /* @__PURE__ */ new WeakSet(), _EnvironmentWorker_handleItem = /**
   * The per-item body shared by {@link EnvironmentWorker.run}'s poll loop and
   * {@link EnvironmentWorker.handleItem}: run a {@link SessionToolRunner} for the
   * work item's session while heartbeating its lease, force-stopping on exit
   * unless the lease was lost. Non-session work items are ignored.
   *
   * When the poll response carried a per-item `secret` (a short-lived payload
   * scoped to this work item), the sessions token extracted from it is
   * preferred over `environmentKey` as the Bearer credential for those
   * per-item calls; a missing/undecodable secret falls back to
   * `environmentKey` unchanged.
   */
  async function _EnvironmentWorker_handleItem2(work, environmentKey, externalSignal) {
    const log = loggerFor(this.client);
    const sessionsToken = sessionsTokenFromSecret(work.secret);
    const itemCredential = sessionsToken ?? environmentKey;
    if (itemCredential === void 0) {
      throw new AnthropicError("handleItem: the work item carried a secret payload but no sessions token could be extracted, and there is no environment key to fall back to; the poller must issue a secret whose payload carries `sessions_token`, or provide the environment key (pass it, construct the worker with it, or set ANTHROPIC_ENVIRONMENT_KEY)");
    }
    if (work.secret && sessionsToken === null) {
      log.warn("work item carried a secret payload but no sessions token could be extracted; falling back to the environment key", { work_id: work.id });
    }
    const sessionClient = copyClientForHelper(this.client, {
      authToken: itemCredential,
      helper: "environments-worker"
    });
    const sessionId = work.data.id;
    const ctrl = new AbortController();
    const detachExternal = linkAbort(externalSignal, ctrl);
    const lease = new Lease(ctrl);
    const agentToolset = await Promise.resolve().then(() => (init_node_browser2(), node_browser_exports2));
    let leaseTtlMs;
    let runner;
    const heartbeatPromise = heartbeatLoop(sessionClient, work, lease, log, this.requestOptions, (ttlMs) => {
      leaseTtlMs = ttlMs;
      runner?._setSendRetryWindow(ttlMs);
    }).catch((e) => {
      if (!ctrl.signal.aborted)
        log.error("heartbeat loop failed", { work_id: work.id, error: String(e) });
      ctrl.abort();
    });
    let cleanupSkills = async () => {
    };
    let stores;
    let cleanEnd = false;
    try {
      if (work.data.type !== "session") {
        log.debug("skipping non-session work item", { work_id: work.id, type: work.data.type });
        return;
      }
      const session = await sessionClient.beta.sessions.retrieve(sessionId);
      if (sessionsToken === null && this.memorySyncIntervalMs !== null && hasMemoryStore(session)) {
        throw new agentToolset.SessionMemoryError(`cannot mount the session's memories: the work item carried no sessions token (work_id=${work.id}, session_id=${sessionId}); the memory endpoints reject the environment key, so the poller must issue a per-item \`secret\` carrying \`sessions_token\`, or set \`memorySyncIntervalMs: null\` to run without memory`);
      }
      const ctx = {
        workdir: this.workdir,
        // The scoped sub-client, not the parent: the skill download
        // `setupSkills` performs for this session rides the same per-item
        // credential as every other per-item call.
        client: sessionClient,
        session,
        ...this.maxFileBytes !== void 0 ? { maxFileBytes: this.maxFileBytes } : {}
      };
      try {
        cleanupSkills = await agentToolset.setupSkills(ctx);
      } catch (e) {
        log.warn("skill setup failed", { session_id: sessionId, work_id: work.id, error: String(e) });
      }
      if (sessionsToken !== null && this.memorySyncIntervalMs !== null) {
        stores = new agentToolset.SessionMemoryStores(sessionClient, {
          workdir: this.workdir,
          ...this.memorySyncIntervalMs !== void 0 ? { syncIntervalMs: this.memorySyncIntervalMs } : {},
          syncDeletions: this.memorySyncDeletions
        });
        await stores.download(session);
        ctx.allowedRoots = stores.roots;
        ctx.readOnlyRoots = stores.readOnlyRoots;
      } else {
        log.debug("memory stores disabled for this item", { work_id: work.id });
      }
      const tools = typeof this.tools === "function" ? this.tools(ctx) : this.tools ?? agentToolset.betaAgentToolset20260401(ctx);
      runner = new SessionToolRunner(sessionId, {
        client: sessionClient,
        tools,
        ...this.maxIdleMs !== void 0 ? { maxIdleMs: this.maxIdleMs } : {},
        ...this.requestOptions !== void 0 ? { requestOptions: this.requestOptions } : {},
        signal: ctrl.signal
      });
      if (leaseTtlMs !== void 0)
        runner._setSendRetryWindow(leaseTtlMs);
      for await (const _ of runner) {
        if (stores)
          await stores.syncIfDue();
      }
      cleanEnd = !ctrl.signal.aborted;
    } finally {
      try {
        await cleanupSkills().catch((e) => {
          log.warn("skill cleanup failed", { session_id: sessionId, work_id: work.id, error: String(e) });
        });
      } finally {
        if (stores) {
          const boundMs = agentToolset.MEMORY_FLUSH_TIMEOUT_MS;
          if (cleanEnd) {
            const finishCutOff = await withTimeout(stores.finish(), boundMs);
            if (finishCutOff) {
              log.warn(`final memory sync cut off after ${boundMs}ms; the flush that follows still uploads changed files`, { session_id: sessionId, work_id: work.id });
            }
          }
          const flushBound = new AbortController();
          const flushCutOff = await withTimeout(stores.flushWrites(flushBound.signal), boundMs);
          if (flushCutOff) {
            flushBound.abort();
            log.warn(`memory flush cut off after ${boundMs}ms; changed files it had not uploaded yet are not saved`, { session_id: sessionId, work_id: work.id });
          }
          await stores.dispose().catch((e) => {
            log.warn("memory store cleanup failed", {
              session_id: sessionId,
              work_id: work.id,
              error: String(e)
            });
          });
        }
      }
      lease.finish("runner_done");
      detachExternal();
      await heartbeatPromise;
      if (lease.lost) {
        log.info("lease lost; released without stopping it", { session_id: sessionId, work_id: work.id });
      } else {
        await forceStop(sessionClient, work, log, this.requestOptions);
      }
    }
  };
  return EnvironmentWorker2;
})();
async function withTimeout(p, ms) {
  let timer;
  try {
    return await Promise.race([
      p.then(() => false, () => false),
      new Promise((resolve) => {
        timer = setTimeout(() => resolve(true), ms);
      })
    ]);
  } finally {
    if (timer !== void 0)
      clearTimeout(timer);
  }
}
async function forceStop(client, work, log, requestOptions) {
  try {
    await client.beta.environments.work.stop(
      work.id,
      { environment_id: work.environment_id, force: true },
      // Caller's headers pass through; the helper-tag header is on the scoped
      // sub-client's default_headers via copyClientForHelper, so no per-call
      // re-stamping needed.
      { ...requestOptions, headers: buildHeaders([requestOptions?.headers]) }
    );
  } catch (e) {
    if (!isStatus(e, 409)) {
      log.error("force-stop on exit failed", { work_id: work.id, error: String(e) });
    }
  }
}
var Lease = /* @__PURE__ */ (() => {
  class Lease2 {
    constructor(ctrl) {
      _Lease_ctrl.set(this, void 0);
      _Lease_endReason.set(this, void 0);
      __classPrivateFieldSet(this, _Lease_ctrl, ctrl, "f");
    }
    get signal() {
      return __classPrivateFieldGet(this, _Lease_ctrl, "f").signal;
    }
    finish(reason) {
      __classPrivateFieldSet(this, _Lease_endReason, __classPrivateFieldGet(this, _Lease_endReason, "f") ?? reason, "f");
      __classPrivateFieldGet(this, _Lease_ctrl, "f").abort();
    }
    /** True once the item belongs to the queue or another worker. */
    get lost() {
      return __classPrivateFieldGet(this, _Lease_endReason, "f") === "lease_lost" || __classPrivateFieldGet(this, _Lease_endReason, "f") === "assumed_lost";
    }
  }
  _Lease_ctrl = /* @__PURE__ */ new WeakMap(), _Lease_endReason = /* @__PURE__ */ new WeakMap();
  return Lease2;
})();
function serverLeaseState(e) {
  let node = e instanceof APIError ? e.error : void 0;
  for (const key of ["error", "details", "current_state"]) {
    if (!isObj(node))
      return {};
    node = node[key];
  }
  return isObj(node) ? node : {};
}
async function heartbeatLoop(client, work, lease, logger, requestOptions, onLeaseTtl) {
  let intervalMs = HEARTBEAT_DEFAULT_MS;
  let ttlMs = HEARTBEAT_TTL_DEFAULT_MS;
  let lastSuccessMs = Date.now();
  let last = NO_HEARTBEAT_SENTINEL;
  const beat = async () => {
    const beatCtrl = new AbortController();
    const detach = linkAbort(lease.signal, beatCtrl);
    const cutoff = setTimeout(() => beatCtrl.abort(), intervalMs);
    try {
      const resp = await client.beta.environments.work.heartbeat(work.id, { environment_id: work.environment_id, expected_last_heartbeat: last }, { ...requestOptions, headers: buildHeaders([requestOptions?.headers]), signal: beatCtrl.signal });
      lastSuccessMs = Date.now();
      last = resp.last_heartbeat;
      if (resp.ttl_seconds > 0) {
        ttlMs = resp.ttl_seconds * 1e3;
        intervalMs = Math.max(1e3, Math.min(ttlMs / 2, HEARTBEAT_DEFAULT_MS));
        onLeaseTtl?.(ttlMs);
      }
      if (resp.state === "stopping" || resp.state === "stopped") {
        logger.info("heartbeat signals shutdown", { work_id: work.id, state: resp.state });
        lease.finish("control_plane_stop");
      }
      if (!resp.lease_extended) {
        logger.warn("lease not extended, shutting down", { work_id: work.id });
        lease.finish("control_plane_stop");
      }
    } catch (e) {
      lease.signal.throwIfAborted();
      if (isStatus(e, 412)) {
        const server = serverLeaseState(e);
        logger.error("lease lost: heartbeat precondition failed", {
          work_id: work.id,
          server_state: server["state"],
          server_ttl_seconds: server["ttl_seconds"],
          server_last_heartbeat: server["last_heartbeat"]
        });
        lease.finish("lease_lost");
        return;
      }
      if (isFatal4xx(e)) {
        logger.error("permanent heartbeat failure", { work_id: work.id, error: String(e) });
        lease.finish("heartbeat_rejected");
        throw e;
      }
      if (Date.now() - lastSuccessMs > ttlMs) {
        logger.error("lease assumed lost: no successful heartbeat in ttl", {
          work_id: work.id,
          ttl_ms: ttlMs,
          error: String(e)
        });
        lease.finish("assumed_lost");
        return;
      }
      logger.warn("transient heartbeat failure", { work_id: work.id, error: String(e) });
    } finally {
      clearTimeout(cutoff);
      detach();
    }
  };
  await beat();
  while (!lease.signal.aborted) {
    await sleep(intervalMs, lease.signal);
    lease.signal.throwIfAborted();
    await beat();
  }
}

// node_modules/@anthropic-ai/sdk/resources/beta/environments/work.mjs
var Work = /* @__PURE__ */ (() => {
  class Work2 extends APIResource {
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Retrieve detailed information about a specific work item.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.retrieve('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   });
     * ```
     */
    retrieve(workID, params, options) {
      const { environment_id, betas, workspace_id } = params;
      return this._client.get(path2`/v1/environments/${environment_id}/work/${workID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Update work item metadata with merge semantics.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.update('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *     metadata: { foo: 'string' },
     *   });
     * ```
     */
    update(workID, params, options) {
      const { environment_id, betas, workspace_id, ...body } = params;
      return this._client.post(path2`/v1/environments/${environment_id}/work/${workID}?beta=true`, {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * List work items in an environment.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaSelfHostedWork of client.beta.environments.work.list(
     *   'env_011CZkZ9X2dpNyB7HsEFoRfW',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(environmentID, params = {}, options) {
      const { betas, ...query } = params ?? {};
      return this._client.getAPIList(path2`/v1/environments/${environmentID}/work?beta=true`, PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
          options?.headers
        ])
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Acknowledge receipt of a work item, transitioning it from 'queued' to 'starting'
     * and removing it from the queue.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.ack('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   });
     * ```
     */
    ack(workID, params, options) {
      const { environment_id, betas } = params;
      return this._client.post(path2`/v1/environments/${environment_id}/work/${workID}/ack?beta=true`, {
        ...options,
        headers: buildHeaders([
          { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
          options?.headers
        ])
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Record a heartbeat for a work item to maintain the lease.
     *
     * @example
     * ```ts
     * const betaSelfHostedWorkHeartbeatResponse =
     *   await client.beta.environments.work.heartbeat('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   });
     * ```
     */
    heartbeat(workID, params, options) {
      const { environment_id, desired_ttl_seconds, expected_last_heartbeat, betas } = params;
      return this._client.post(path2`/v1/environments/${environment_id}/work/${workID}/heartbeat?beta=true`, {
        query: { desired_ttl_seconds, expected_last_heartbeat },
        ...options,
        headers: buildHeaders([
          { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
          options?.headers
        ])
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Long poll for work items in the queue.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.poll(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    poll(environmentID, params = {}, options) {
      const { betas, "Anthropic-Worker-ID": anthropicWorkerID, ...query } = params ?? {};
      return this._client.get(path2`/v1/environments/${environmentID}/work/poll?beta=true`, {
        query,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...anthropicWorkerID != null ? { "Anthropic-Worker-ID": anthropicWorkerID } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Get statistics about the work queue for an environment.
     *
     * @example
     * ```ts
     * const betaSelfHostedWorkQueueStats =
     *   await client.beta.environments.work.stats(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    stats(environmentID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.get(path2`/v1/environments/${environmentID}/work/stats?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Note: these endpoints are called automatically by the pre-built environment
     * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
     * sandbox environments. They are included here as a reference; you do not need to
     * invoke them directly.
     *
     * Stop a work item, initiating graceful or forced shutdown.
     *
     * @example
     * ```ts
     * const betaSelfHostedWork =
     *   await client.beta.environments.work.stop('work_id', {
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   });
     * ```
     */
    stop(workID, params, options) {
      const { environment_id, betas, workspace_id, ...body } = params;
      return this._client.post(path2`/v1/environments/${environment_id}/work/${workID}/stop?beta=true`, {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Continuously claim work from a self-hosted environment, ack each item,
     * and yield it. Posts `stop` automatically when the consumer's loop body
     * returns or when iteration ends.
     *
     * @example
     * ```ts
     * for await (const work of client.beta.environments.work.poller({
     *   environmentId,
     *   environmentKey,
     * })) {
     *   if (work.data.type !== 'session') continue;
     *   // ...service the work...
     * }
     * ```
     */
    poller(opts) {
      return new WorkPoller({ ...opts, client: this._client });
    }
    worker(opts) {
      return new EnvironmentWorker({ ...opts, client: this._client });
    }
  }
  Work2.WorkPoller = WorkPoller;
  Work2.EnvironmentWorker = EnvironmentWorker;
  return Work2;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/environments/environments.mjs
var Environments = /* @__PURE__ */ (() => {
  class Environments2 extends APIResource {
    constructor() {
      super(...arguments);
      this.work = new Work(this._client);
    }
    /**
     * Create a new environment with the specified configuration.
     *
     * @example
     * ```ts
     * const betaEnvironment =
     *   await client.beta.environments.create({
     *     name: 'python-data-analysis',
     *   });
     * ```
     */
    create(params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post("/v1/environments?beta=true", {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Retrieve a specific environment by ID.
     *
     * @example
     * ```ts
     * const betaEnvironment =
     *   await client.beta.environments.retrieve(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    retrieve(environmentID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.get(path2`/v1/environments/${environmentID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Update an existing environment's configuration.
     *
     * @example
     * ```ts
     * const betaEnvironment =
     *   await client.beta.environments.update(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    update(environmentID, params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post(path2`/v1/environments/${environmentID}?beta=true`, {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * List environments with pagination support.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaEnvironment of client.beta.environments.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
      const { betas, workspace_id, ...query } = params ?? {};
      return this._client.getAPIList("/v1/environments?beta=true", PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Delete an environment by ID. Returns a confirmation of the deletion.
     *
     * @example
     * ```ts
     * const betaEnvironmentDeleteResponse =
     *   await client.beta.environments.delete(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    delete(environmentID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.delete(path2`/v1/environments/${environmentID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Archive an environment by ID. Archived environments cannot be used to create new
     * sessions.
     *
     * @example
     * ```ts
     * const betaEnvironment =
     *   await client.beta.environments.archive(
     *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *   );
     * ```
     */
    archive(environmentID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.post(path2`/v1/environments/${environmentID}/archive?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
  }
  Environments2.Work = Work;
  return Environments2;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memories.mjs
var Memories = class extends APIResource {
  /**
   * Create a memory
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemory =
   *   await client.beta.memoryStores.memories.create(
   *     'memory_store_id',
   *     { content: 'content', path: 'xx' },
   *   );
   * ```
   */
  create(memoryStoreID, params, options) {
    const { view, betas, workspace_id, ...body } = params;
    return this._client.post(path2`/v1/memory_stores/${memoryStoreID}/memories?beta=true`, {
      query: { view },
      body,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Retrieve a memory
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemory =
   *   await client.beta.memoryStores.memories.retrieve(
   *     'memory_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  retrieve(memoryID, params, options) {
    const { memory_store_id, betas, workspace_id, ...query } = params;
    return this._client.get(path2`/v1/memory_stores/${memory_store_id}/memories/${memoryID}?beta=true`, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Update a memory
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemory =
   *   await client.beta.memoryStores.memories.update(
   *     'memory_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  update(memoryID, params, options) {
    const { memory_store_id, view, betas, workspace_id, ...body } = params;
    return this._client.post(path2`/v1/memory_stores/${memory_store_id}/memories/${memoryID}?beta=true`, {
      query: { view },
      body,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * List memories
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsMemoryListItem of client.beta.memoryStores.memories.list(
   *   'memory_store_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(memoryStoreID, params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/memory_stores/${memoryStoreID}/memories?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Delete a memory
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeletedMemory =
   *   await client.beta.memoryStores.memories.delete(
   *     'memory_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  delete(memoryID, params, options) {
    const { memory_store_id, expected_content_sha256, betas, workspace_id } = params;
    return this._client.delete(path2`/v1/memory_stores/${memory_store_id}/memories/${memoryID}?beta=true`, {
      query: { expected_content_sha256 },
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memory-versions.mjs
var MemoryVersions = class extends APIResource {
  /**
   * Retrieve a memory version
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemoryVersion =
   *   await client.beta.memoryStores.memoryVersions.retrieve(
   *     'memory_version_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  retrieve(memoryVersionID, params, options) {
    const { memory_store_id, betas, workspace_id, ...query } = params;
    return this._client.get(path2`/v1/memory_stores/${memory_store_id}/memory_versions/${memoryVersionID}?beta=true`, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * List memory versions
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsMemoryVersion of client.beta.memoryStores.memoryVersions.list(
   *   'memory_store_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(memoryStoreID, params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/memory_stores/${memoryStoreID}/memory_versions?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Redact a memory version
   *
   * @example
   * ```ts
   * const betaManagedAgentsMemoryVersion =
   *   await client.beta.memoryStores.memoryVersions.redact(
   *     'memory_version_id',
   *     { memory_store_id: 'memory_store_id' },
   *   );
   * ```
   */
  redact(memoryVersionID, params, options) {
    const { memory_store_id, betas, workspace_id } = params;
    return this._client.post(path2`/v1/memory_stores/${memory_store_id}/memory_versions/${memoryVersionID}/redact?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memory-stores.mjs
var MemoryStores = /* @__PURE__ */ (() => {
  class MemoryStores2 extends APIResource {
    constructor() {
      super(...arguments);
      this.memories = new Memories(this._client);
      this.memoryVersions = new MemoryVersions(this._client);
    }
    /**
     * Create a memory store
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryStore =
     *   await client.beta.memoryStores.create({ name: 'x' });
     * ```
     */
    create(params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post("/v1/memory_stores?beta=true", {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Retrieve a memory store
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryStore =
     *   await client.beta.memoryStores.retrieve(
     *     'memory_store_id',
     *   );
     * ```
     */
    retrieve(memoryStoreID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.get(path2`/v1/memory_stores/${memoryStoreID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Update a memory store
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryStore =
     *   await client.beta.memoryStores.update('memory_store_id');
     * ```
     */
    update(memoryStoreID, params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post(path2`/v1/memory_stores/${memoryStoreID}?beta=true`, {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * List memory stores
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsMemoryStore of client.beta.memoryStores.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
      const { betas, workspace_id, ...query } = params ?? {};
      return this._client.getAPIList("/v1/memory_stores?beta=true", PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Delete a memory store
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeletedMemoryStore =
     *   await client.beta.memoryStores.delete('memory_store_id');
     * ```
     */
    delete(memoryStoreID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.delete(path2`/v1/memory_stores/${memoryStoreID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Archive a memory store
     *
     * @example
     * ```ts
     * const betaManagedAgentsMemoryStore =
     *   await client.beta.memoryStores.archive('memory_store_id');
     * ```
     */
    archive(memoryStoreID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.post(path2`/v1/memory_stores/${memoryStoreID}/archive?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
  }
  MemoryStores2.Memories = Memories;
  MemoryStores2.MemoryVersions = MemoryVersions;
  return MemoryStores2;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/messages/batches.mjs
var Batches2 = class extends APIResource {
  /**
   * Send a batch of Message creation requests.
   *
   * The Message Batches API can be used to process multiple Messages API requests at
   * once. Once a Message Batch is created, it begins processing immediately. Batches
   * can take up to 24 hours to complete.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const betaMessageBatch =
   *   await client.beta.messages.batches.create({
   *     requests: [
   *       {
   *         custom_id: 'my-custom-id-1',
   *         params: {
   *           max_tokens: 1024,
   *           messages: [
   *             { content: 'Hello, world', role: 'user' },
   *           ],
   *           model: 'claude-opus-5',
   *         },
   *       },
   *     ],
   *   });
   * ```
   */
  create(params, options) {
    const { betas, user_profile_id, workspace_id, ...body } = params;
    return this._client.post("/v1/messages/batches?beta=true", {
      body,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString(),
          ...user_profile_id != null ? { "anthropic-user-profile-id": user_profile_id } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * This endpoint is idempotent and can be used to poll for Message Batch
   * completion. To access the results of a Message Batch, make a request to the
   * `results_url` field in the response.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const betaMessageBatch =
   *   await client.beta.messages.batches.retrieve(
   *     'message_batch_id',
   *   );
   * ```
   */
  retrieve(messageBatchID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.get(path2`/v1/messages/batches/${messageBatchID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * List all Message Batches within a Workspace. Most recently created batches are
   * returned first.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaMessageBatch of client.beta.messages.batches.list()) {
   *   // ...
   * }
   * ```
   */
  list(params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList("/v1/messages/batches?beta=true", Page, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Delete a Message Batch.
   *
   * Message Batches can only be deleted once they've finished processing. If you'd
   * like to delete an in-progress batch, you must first cancel it.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const betaDeletedMessageBatch =
   *   await client.beta.messages.batches.delete(
   *     'message_batch_id',
   *   );
   * ```
   */
  delete(messageBatchID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.delete(path2`/v1/messages/batches/${messageBatchID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Batches may be canceled any time before processing ends. Once cancellation is
   * initiated, the batch enters a `canceling` state, at which time the system may
   * complete any in-progress, non-interruptible requests before finalizing
   * cancellation.
   *
   * The number of canceled requests is specified in `request_counts`. To determine
   * which requests were canceled, check the individual results within the batch.
   * Note that cancellation may not result in any canceled requests if they were
   * non-interruptible.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const betaMessageBatch =
   *   await client.beta.messages.batches.cancel(
   *     'message_batch_id',
   *   );
   * ```
   */
  cancel(messageBatchID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.post(path2`/v1/messages/batches/${messageBatchID}/cancel?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Streams the results of a Message Batch as a `.jsonl` file.
   *
   * Each line in the file is a JSON object containing the result of a single request
   * in the Message Batch. Results are not guaranteed to be in the same order as
   * requests. Use the `custom_id` field to match results to requests.
   *
   * Learn more about the Message Batches API in our
   * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
   *
   * @example
   * ```ts
   * const betaMessageBatchIndividualResponse =
   *   await client.beta.messages.batches.results(
   *     'message_batch_id',
   *   );
   * ```
   */
  async results(messageBatchID, params = {}, options) {
    const batch = await this.retrieve(messageBatchID, params, options);
    if (!batch.results_url) {
      throw new AnthropicError(`No batch \`results_url\`; Has it finished processing? ${batch.processing_status} - ${batch.id}`);
    }
    const { betas, workspace_id } = params ?? {};
    return this._client.get(batch.results_url, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString(),
          Accept: "application/binary",
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ]),
      stream: true,
      __binaryResponse: true
    })._thenUnwrap((_, props) => JSONLDecoder.fromResponse(props.response, props.controller));
  }
};

// node_modules/@anthropic-ai/sdk/lib/beta-parser.mjs
init_error();
function getOutputFormat2(params) {
  return params?.output_format ?? params?.output_config?.format;
}
function maybeParseBetaMessage(message, params, opts) {
  const outputFormat = getOutputFormat2(params);
  if (!params || !("parse" in (outputFormat ?? {}))) {
    return {
      ...message,
      content: message.content.map((block) => {
        if (block.type === "text") {
          const parsedBlock = Object.defineProperty({ ...block }, "parsed_output", {
            value: null,
            enumerable: false
          });
          return Object.defineProperty(parsedBlock, "parsed", {
            get() {
              opts.logger.warn("The `parsed` property on `text` blocks is deprecated, please use `parsed_output` instead.");
              return null;
            },
            enumerable: false
          });
        }
        return block;
      }),
      parsed_output: null
    };
  }
  return parseBetaMessage(message, params, opts);
}
function parseBetaMessage(message, params, opts) {
  let firstParsedOutput = null;
  const content = message.content.map((block) => {
    if (block.type === "text") {
      const parsedOutput = parseBetaOutputFormat(params, block.text);
      if (firstParsedOutput === null) {
        firstParsedOutput = parsedOutput;
      }
      const parsedBlock = Object.defineProperty({ ...block }, "parsed_output", {
        value: parsedOutput,
        enumerable: false
      });
      return Object.defineProperty(parsedBlock, "parsed", {
        get() {
          opts.logger.warn("The `parsed` property on `text` blocks is deprecated, please use `parsed_output` instead.");
          return parsedOutput;
        },
        enumerable: false
      });
    }
    return block;
  });
  return {
    ...message,
    content,
    parsed_output: firstParsedOutput
  };
}
function parseBetaOutputFormat(params, content) {
  const outputFormat = getOutputFormat2(params);
  if (outputFormat?.type !== "json_schema") {
    return null;
  }
  try {
    if ("parse" in outputFormat) {
      return outputFormat.parse(content);
    }
    return JSON.parse(content);
  } catch (error) {
    throw new AnthropicError(`Failed to parse structured output: ${error}`);
  }
}

// node_modules/@anthropic-ai/sdk/lib/BetaMessageStream.mjs
init_errors();
var _BetaMessageStream_instances;
var _BetaMessageStream_currentMessageSnapshot;
var _BetaMessageStream_params;
var _BetaMessageStream_connectedPromise;
var _BetaMessageStream_resolveConnectedPromise;
var _BetaMessageStream_rejectConnectedPromise;
var _BetaMessageStream_endPromise;
var _BetaMessageStream_resolveEndPromise;
var _BetaMessageStream_rejectEndPromise;
var _BetaMessageStream_listeners;
var _BetaMessageStream_ended;
var _BetaMessageStream_errored;
var _BetaMessageStream_aborted;
var _BetaMessageStream_catchingPromiseCreated;
var _BetaMessageStream_response;
var _BetaMessageStream_request_id;
var _BetaMessageStream_workspace_id;
var _BetaMessageStream_logger;
var _BetaMessageStream_getFinalMessage;
var _BetaMessageStream_getFinalText;
var _BetaMessageStream_handleError;
var _BetaMessageStream_beginRequest;
var _BetaMessageStream_addStreamEvent;
var _BetaMessageStream_endRequest;
var _BetaMessageStream_accumulateMessage;
var _BetaMessageStream_toolInputParseError;
function tracksToolInput2(content) {
  return content.type === "tool_use" || content.type === "server_tool_use" || content.type === "mcp_tool_use";
}
var BetaMessageStream = /* @__PURE__ */ (() => {
  class BetaMessageStream2 {
    constructor(params, opts) {
      _BetaMessageStream_instances.add(this);
      this.messages = [];
      this.receivedMessages = [];
      _BetaMessageStream_currentMessageSnapshot.set(this, void 0);
      _BetaMessageStream_params.set(this, null);
      this.controller = new AbortController();
      _BetaMessageStream_connectedPromise.set(this, void 0);
      _BetaMessageStream_resolveConnectedPromise.set(this, () => {
      });
      _BetaMessageStream_rejectConnectedPromise.set(this, () => {
      });
      _BetaMessageStream_endPromise.set(this, void 0);
      _BetaMessageStream_resolveEndPromise.set(this, () => {
      });
      _BetaMessageStream_rejectEndPromise.set(this, () => {
      });
      _BetaMessageStream_listeners.set(this, {});
      _BetaMessageStream_ended.set(this, false);
      _BetaMessageStream_errored.set(this, false);
      _BetaMessageStream_aborted.set(this, false);
      _BetaMessageStream_catchingPromiseCreated.set(this, false);
      _BetaMessageStream_response.set(this, void 0);
      _BetaMessageStream_request_id.set(this, void 0);
      _BetaMessageStream_workspace_id.set(this, void 0);
      _BetaMessageStream_logger.set(this, void 0);
      _BetaMessageStream_handleError.set(this, (error) => {
        __classPrivateFieldSet(this, _BetaMessageStream_errored, true, "f");
        if (isAbortError(error)) {
          error = new APIUserAbortError();
        }
        if (error instanceof APIUserAbortError) {
          __classPrivateFieldSet(this, _BetaMessageStream_aborted, true, "f");
          return this._emit("abort", error);
        }
        if (error instanceof AnthropicError) {
          return this._emit("error", error);
        }
        if (error instanceof Error) {
          const anthropicError = new AnthropicError(error.message);
          anthropicError.cause = error;
          return this._emit("error", anthropicError);
        }
        return this._emit("error", new AnthropicError(String(error)));
      });
      __classPrivateFieldSet(this, _BetaMessageStream_connectedPromise, new Promise((resolve, reject) => {
        __classPrivateFieldSet(this, _BetaMessageStream_resolveConnectedPromise, resolve, "f");
        __classPrivateFieldSet(this, _BetaMessageStream_rejectConnectedPromise, reject, "f");
      }), "f");
      __classPrivateFieldSet(this, _BetaMessageStream_endPromise, new Promise((resolve, reject) => {
        __classPrivateFieldSet(this, _BetaMessageStream_resolveEndPromise, resolve, "f");
        __classPrivateFieldSet(this, _BetaMessageStream_rejectEndPromise, reject, "f");
      }), "f");
      __classPrivateFieldGet(this, _BetaMessageStream_connectedPromise, "f").catch(() => {
      });
      __classPrivateFieldGet(this, _BetaMessageStream_endPromise, "f").catch(() => {
      });
      __classPrivateFieldSet(this, _BetaMessageStream_params, params, "f");
      __classPrivateFieldSet(this, _BetaMessageStream_logger, opts?.logger ?? console, "f");
    }
    get response() {
      return __classPrivateFieldGet(this, _BetaMessageStream_response, "f");
    }
    get request_id() {
      return __classPrivateFieldGet(this, _BetaMessageStream_request_id, "f");
    }
    get workspace_id() {
      return __classPrivateFieldGet(this, _BetaMessageStream_workspace_id, "f");
    }
    /**
     * Returns the `MessageStream` data, the raw `Response` instance and the ID of the request,
     * returned vie the `request-id` header which is useful for debugging requests and resporting
     * issues to Anthropic.
     *
     * This is the same as the `APIPromise.withResponse()` method.
     *
     * This method will raise an error if you created the stream using `MessageStream.fromReadableStream`
     * as no `Response` is available.
     */
    async withResponse() {
      __classPrivateFieldSet(this, _BetaMessageStream_catchingPromiseCreated, true, "f");
      const response = await __classPrivateFieldGet(this, _BetaMessageStream_connectedPromise, "f");
      if (!response) {
        throw new Error("Could not resolve a `Response` object");
      }
      return {
        data: this,
        response,
        request_id: response.headers.get("request-id"),
        workspace_id: response.headers.get("anthropic-workspace-id")
      };
    }
    /**
     * Intended for use on the frontend, consuming a stream produced with
     * `.toReadableStream()` on the backend.
     *
     * Note that messages sent to the model do not appear in `.on('message')`
     * in this context.
     */
    static fromReadableStream(stream2) {
      const runner = new BetaMessageStream2(null);
      runner._run(() => runner._fromReadableStream(stream2));
      return runner;
    }
    static createMessage(messages, params, options, { logger } = {}) {
      const runner = new BetaMessageStream2(params, { logger });
      for (const message of params.messages) {
        runner._addMessageParam(message);
      }
      __classPrivateFieldSet(runner, _BetaMessageStream_params, { ...params, stream: true }, "f");
      runner._run(() => runner._createMessage(messages, { ...params, stream: true }, { ...options, headers: { ...options?.headers, [STAINLESS_HELPER_METHOD_HEADER]: "stream" } }));
      return runner;
    }
    _run(executor) {
      executor().then(() => {
        this._emitFinal();
        this._emit("end");
      }, __classPrivateFieldGet(this, _BetaMessageStream_handleError, "f"));
    }
    _addMessageParam(message) {
      this.messages.push(message);
    }
    _addMessage(message, emit = true) {
      this.receivedMessages.push(message);
      if (emit) {
        this._emit("message", message);
      }
    }
    async _createMessage(messages, params, options) {
      const signal = options?.signal;
      let abortHandler;
      if (signal) {
        if (signal.aborted)
          this.controller.abort();
        abortHandler = this.controller.abort.bind(this.controller);
        signal.addEventListener("abort", abortHandler);
      }
      try {
        __classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_beginRequest).call(this);
        const { response, data: stream2 } = await messages.create({ ...params, stream: true }, { ...options, signal: this.controller.signal }).withResponse();
        this._connected(response);
        for await (const event of stream2) {
          __classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_addStreamEvent).call(this, event);
        }
        if (stream2.controller.signal?.aborted) {
          throw new APIUserAbortError();
        }
        __classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_endRequest).call(this);
      } finally {
        if (signal && abortHandler) {
          signal.removeEventListener("abort", abortHandler);
        }
      }
    }
    _connected(response) {
      if (this.ended)
        return;
      __classPrivateFieldSet(this, _BetaMessageStream_response, response, "f");
      __classPrivateFieldSet(this, _BetaMessageStream_request_id, response?.headers.get("request-id"), "f");
      __classPrivateFieldSet(this, _BetaMessageStream_workspace_id, response?.headers.get("anthropic-workspace-id"), "f");
      __classPrivateFieldGet(this, _BetaMessageStream_resolveConnectedPromise, "f").call(this, response);
      this._emit("connect");
    }
    get ended() {
      return __classPrivateFieldGet(this, _BetaMessageStream_ended, "f");
    }
    get errored() {
      return __classPrivateFieldGet(this, _BetaMessageStream_errored, "f");
    }
    get aborted() {
      return __classPrivateFieldGet(this, _BetaMessageStream_aborted, "f");
    }
    abort() {
      this.controller.abort();
    }
    /**
     * Adds the listener function to the end of the listeners array for the event.
     * No checks are made to see if the listener has already been added. Multiple calls passing
     * the same combination of event and listener will result in the listener being added, and
     * called, multiple times.
     * @returns this MessageStream, so that calls can be chained
     */
    on(event, listener) {
      const listeners = __classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] || (__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] = []);
      listeners.push({ listener });
      return this;
    }
    /**
     * Removes the specified listener from the listener array for the event.
     * off() will remove, at most, one instance of a listener from the listener array. If any single
     * listener has been added multiple times to the listener array for the specified event, then
     * off() must be called multiple times to remove each instance.
     * @returns this MessageStream, so that calls can be chained
     */
    off(event, listener) {
      const listeners = __classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event];
      if (!listeners)
        return this;
      const index = listeners.findIndex((l) => l.listener === listener);
      if (index >= 0)
        listeners.splice(index, 1);
      return this;
    }
    /**
     * Adds a one-time listener function for the event. The next time the event is triggered,
     * this listener is removed and then invoked.
     * @returns this MessageStream, so that calls can be chained
     */
    once(event, listener) {
      const listeners = __classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] || (__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] = []);
      listeners.push({ listener, once: true });
      return this;
    }
    /**
     * This is similar to `.once()`, but returns a Promise that resolves the next time
     * the event is triggered, instead of calling a listener callback.
     * @returns a Promise that resolves the next time given event is triggered,
     * or rejects if an error is emitted.  (If you request the 'error' event,
     * returns a promise that resolves with the error).
     *
     * Example:
     *
     *   const message = await stream.emitted('message') // rejects if the stream errors
     */
    emitted(event) {
      return new Promise((resolve, reject) => {
        __classPrivateFieldSet(this, _BetaMessageStream_catchingPromiseCreated, true, "f");
        if (event !== "error")
          this.once("error", reject);
        this.once(event, resolve);
      });
    }
    async done() {
      __classPrivateFieldSet(this, _BetaMessageStream_catchingPromiseCreated, true, "f");
      await __classPrivateFieldGet(this, _BetaMessageStream_endPromise, "f");
    }
    get currentMessage() {
      return __classPrivateFieldGet(this, _BetaMessageStream_currentMessageSnapshot, "f");
    }
    /**
     * @returns a promise that resolves with the the final assistant Message response,
     * or rejects if an error occurred or the stream ended prematurely without producing a Message.
     * If structured outputs were used, this will be a ParsedMessage with a `parsed` field.
     */
    async finalMessage() {
      await this.done();
      return __classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_getFinalMessage).call(this);
    }
    /**
     * @returns a promise that resolves with the the final assistant Message's text response, concatenated
     * together if there are more than one text blocks.
     * Rejects if an error occurred or the stream ended prematurely without producing a Message.
     */
    async finalText() {
      await this.done();
      return __classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_getFinalText).call(this);
    }
    _emit(event, ...args) {
      if (__classPrivateFieldGet(this, _BetaMessageStream_ended, "f"))
        return;
      if (event === "end") {
        __classPrivateFieldSet(this, _BetaMessageStream_ended, true, "f");
        __classPrivateFieldGet(this, _BetaMessageStream_resolveEndPromise, "f").call(this);
      }
      const listeners = __classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event];
      if (listeners) {
        __classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] = listeners.filter((l) => !l.once);
        listeners.forEach(({ listener }) => listener(...args));
      }
      if (event === "abort") {
        const error = args[0];
        if (!__classPrivateFieldGet(this, _BetaMessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
          Promise.reject(error);
        }
        __classPrivateFieldGet(this, _BetaMessageStream_rejectConnectedPromise, "f").call(this, error);
        __classPrivateFieldGet(this, _BetaMessageStream_rejectEndPromise, "f").call(this, error);
        this._emit("end");
        return;
      }
      if (event === "error") {
        const error = args[0];
        if (!__classPrivateFieldGet(this, _BetaMessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
          Promise.reject(error);
        }
        __classPrivateFieldGet(this, _BetaMessageStream_rejectConnectedPromise, "f").call(this, error);
        __classPrivateFieldGet(this, _BetaMessageStream_rejectEndPromise, "f").call(this, error);
        this._emit("end");
      }
    }
    _emitFinal() {
      const finalMessage = this.receivedMessages.at(-1);
      if (finalMessage) {
        this._emit("finalMessage", __classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_getFinalMessage).call(this));
      }
    }
    async _fromReadableStream(readableStream, options) {
      const signal = options?.signal;
      let abortHandler;
      if (signal) {
        if (signal.aborted)
          this.controller.abort();
        abortHandler = this.controller.abort.bind(this.controller);
        signal.addEventListener("abort", abortHandler);
      }
      try {
        __classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_beginRequest).call(this);
        this._connected(null);
        const stream2 = Stream.fromReadableStream(readableStream, this.controller);
        for await (const event of stream2) {
          __classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_addStreamEvent).call(this, event);
        }
        if (stream2.controller.signal?.aborted) {
          throw new APIUserAbortError();
        }
        __classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_endRequest).call(this);
      } finally {
        if (signal && abortHandler) {
          signal.removeEventListener("abort", abortHandler);
        }
      }
    }
    [(_BetaMessageStream_currentMessageSnapshot = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_params = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_connectedPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_resolveConnectedPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_rejectConnectedPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_endPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_resolveEndPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_rejectEndPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_listeners = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_ended = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_errored = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_aborted = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_catchingPromiseCreated = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_response = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_request_id = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_workspace_id = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_logger = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_handleError = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_instances = /* @__PURE__ */ new WeakSet(), _BetaMessageStream_getFinalMessage = function _BetaMessageStream_getFinalMessage2() {
      if (this.receivedMessages.length === 0) {
        throw new AnthropicError("stream ended without producing a Message with role=assistant");
      }
      return this.receivedMessages.at(-1);
    }, _BetaMessageStream_getFinalText = function _BetaMessageStream_getFinalText2() {
      if (this.receivedMessages.length === 0) {
        throw new AnthropicError("stream ended without producing a Message with role=assistant");
      }
      const textBlocks = this.receivedMessages.at(-1).content.filter((block) => block.type === "text").map((block) => block.text);
      if (textBlocks.length === 0) {
        throw new AnthropicError("stream ended without producing a content block with type=text");
      }
      return textBlocks.join(" ");
    }, _BetaMessageStream_beginRequest = function _BetaMessageStream_beginRequest2() {
      if (this.ended)
        return;
      __classPrivateFieldSet(this, _BetaMessageStream_currentMessageSnapshot, void 0, "f");
    }, _BetaMessageStream_addStreamEvent = function _BetaMessageStream_addStreamEvent2(event) {
      if (this.ended)
        return;
      const messageSnapshot = __classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_accumulateMessage).call(this, event);
      this._emit("streamEvent", event, messageSnapshot);
      switch (event.type) {
        case "content_block_delta": {
          const content = messageSnapshot.content.at(-1);
          switch (event.delta.type) {
            case "text_delta": {
              if (content.type === "text") {
                this._emit("text", event.delta.text, content.text || "");
              }
              break;
            }
            case "citations_delta": {
              if (content.type === "text") {
                this._emit("citation", event.delta.citation, content.citations ?? []);
              }
              break;
            }
            case "input_json_delta": {
              if (tracksToolInput2(content) && __classPrivateFieldGet(this, _BetaMessageStream_listeners, "f").inputJson?.length) {
                let jsonSnapshot;
                try {
                  jsonSnapshot = content.input;
                } catch (err) {
                  __classPrivateFieldGet(this, _BetaMessageStream_handleError, "f").call(this, __classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_toolInputParseError).call(this, content, err));
                  break;
                }
                this._emit("inputJson", event.delta.partial_json, jsonSnapshot);
              }
              break;
            }
            case "thinking_delta": {
              if (content.type === "thinking") {
                this._emit("thinking", event.delta.thinking, content.thinking);
              }
              break;
            }
            case "signature_delta": {
              if (content.type === "thinking") {
                this._emit("signature", content.signature);
              }
              break;
            }
            case "compaction_delta": {
              if (content.type === "compaction" && content.content) {
                this._emit("compaction", content.content);
              }
              break;
            }
            default:
              checkNever(event.delta);
          }
          break;
        }
        case "message_stop": {
          this._addMessageParam(messageSnapshot);
          this._addMessage(maybeParseBetaMessage(messageSnapshot, __classPrivateFieldGet(this, _BetaMessageStream_params, "f"), { logger: __classPrivateFieldGet(this, _BetaMessageStream_logger, "f") }), true);
          break;
        }
        case "content_block_stop": {
          this._emit("contentBlock", messageSnapshot.content.at(-1));
          break;
        }
        case "message_start": {
          __classPrivateFieldSet(this, _BetaMessageStream_currentMessageSnapshot, messageSnapshot, "f");
          break;
        }
        case "content_block_start":
        case "message_delta":
          break;
      }
    }, _BetaMessageStream_endRequest = function _BetaMessageStream_endRequest2() {
      if (this.ended) {
        throw new AnthropicError(`stream has ended, this shouldn't happen`);
      }
      const snapshot = __classPrivateFieldGet(this, _BetaMessageStream_currentMessageSnapshot, "f");
      if (!snapshot) {
        throw new AnthropicError(`request ended without sending any chunks`);
      }
      __classPrivateFieldSet(this, _BetaMessageStream_currentMessageSnapshot, void 0, "f");
      return maybeParseBetaMessage(snapshot, __classPrivateFieldGet(this, _BetaMessageStream_params, "f"), { logger: __classPrivateFieldGet(this, _BetaMessageStream_logger, "f") });
    }, _BetaMessageStream_accumulateMessage = function _BetaMessageStream_accumulateMessage2(event) {
      let snapshot = __classPrivateFieldGet(this, _BetaMessageStream_currentMessageSnapshot, "f");
      if (event.type === "message_start") {
        if (snapshot) {
          throw new AnthropicError(`Unexpected event order, got ${event.type} before receiving "message_stop"`);
        }
        return event.message;
      }
      if (!snapshot) {
        throw new AnthropicError(`Unexpected event order, got ${event.type} before "message_start"`);
      }
      switch (event.type) {
        case "message_stop":
          return snapshot;
        case "message_delta":
          snapshot.stop_reason = event.delta.stop_reason;
          snapshot.stop_sequence = event.delta.stop_sequence;
          snapshot.stop_details = event.delta.stop_details;
          snapshot.usage.output_tokens = event.usage.output_tokens;
          if (event.delta.container != null) {
            snapshot.container = event.delta.container;
          }
          if (event.context_management != null) {
            snapshot.context_management = event.context_management;
          }
          if (event.input_transformations != null) {
            snapshot.input_transformations = event.input_transformations;
          }
          if (event.usage.input_tokens != null) {
            snapshot.usage.input_tokens = event.usage.input_tokens;
          }
          if (event.usage.cache_creation_input_tokens != null) {
            snapshot.usage.cache_creation_input_tokens = event.usage.cache_creation_input_tokens;
          }
          if (event.usage.cache_read_input_tokens != null) {
            snapshot.usage.cache_read_input_tokens = event.usage.cache_read_input_tokens;
          }
          if (event.usage.server_tool_use != null) {
            snapshot.usage.server_tool_use = event.usage.server_tool_use;
          }
          if (event.usage.iterations != null) {
            snapshot.usage.iterations = event.usage.iterations;
          }
          if (event.usage.fallback_credit != null) {
            snapshot.usage.fallback_credit = event.usage.fallback_credit;
          }
          if (event.usage.output_tokens_details != null) {
            snapshot.usage.output_tokens_details = event.usage.output_tokens_details;
          }
          return snapshot;
        case "content_block_start":
          snapshot.content.push(event.content_block);
          if (event.content_block.type === "fallback") {
            snapshot.model = event.content_block.to.model;
          }
          return snapshot;
        case "content_block_delta": {
          const snapshotContent = snapshot.content.at(event.index);
          switch (event.delta.type) {
            case "text_delta": {
              if (snapshotContent?.type === "text") {
                snapshot.content[event.index] = {
                  ...snapshotContent,
                  text: (snapshotContent.text || "") + event.delta.text
                };
              }
              break;
            }
            case "citations_delta": {
              if (snapshotContent?.type === "text") {
                snapshot.content[event.index] = {
                  ...snapshotContent,
                  citations: [...snapshotContent.citations ?? [], event.delta.citation]
                };
              }
              break;
            }
            case "input_json_delta": {
              if (snapshotContent && tracksToolInput2(snapshotContent)) {
                const jsonBuf = (snapshotContent[JSON_BUF_PROPERTY] || "") + event.delta.partial_json;
                snapshot.content[event.index] = withLazyInput(snapshotContent, jsonBuf);
              }
              break;
            }
            case "thinking_delta": {
              if (snapshotContent?.type === "thinking") {
                snapshot.content[event.index] = {
                  ...snapshotContent,
                  thinking: snapshotContent.thinking + event.delta.thinking
                };
              }
              break;
            }
            case "signature_delta": {
              if (snapshotContent?.type === "thinking") {
                snapshot.content[event.index] = {
                  ...snapshotContent,
                  signature: event.delta.signature
                };
              }
              break;
            }
            case "compaction_delta": {
              if (snapshotContent?.type === "compaction") {
                const block = { ...snapshotContent, content: event.delta.content };
                if ("encrypted_content" in event.delta) {
                  block.encrypted_content = event.delta.encrypted_content;
                }
                snapshot.content[event.index] = block;
              }
              break;
            }
            default:
              checkNever(event.delta);
          }
          return snapshot;
        }
        case "content_block_stop": {
          const snapshotContent = snapshot.content.at(event.index);
          if (snapshotContent && tracksToolInput2(snapshotContent) && JSON_BUF_PROPERTY in snapshotContent) {
            let input;
            try {
              input = snapshotContent.input;
            } catch (err) {
              input = {};
              __classPrivateFieldGet(this, _BetaMessageStream_handleError, "f").call(this, __classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_toolInputParseError).call(this, snapshotContent, err));
            }
            Object.defineProperty(snapshotContent, "input", {
              value: input,
              enumerable: true,
              configurable: true,
              writable: true
            });
          }
          return snapshot;
        }
      }
    }, _BetaMessageStream_toolInputParseError = function _BetaMessageStream_toolInputParseError2(block, err) {
      const jsonBuf = block[JSON_BUF_PROPERTY];
      return new AnthropicError(`Unable to parse tool parameter JSON from model. Please retry your request or adjust your prompt. Error: ${err}. JSON: ${jsonBuf}`);
    }, Symbol.asyncIterator)]() {
      const pushQueue = [];
      const readQueue = [];
      let done = false;
      this.on("streamEvent", (event) => {
        const reader = readQueue.shift();
        if (reader) {
          reader.resolve(event);
        } else {
          pushQueue.push(event);
        }
      });
      this.on("end", () => {
        done = true;
        for (const reader of readQueue) {
          reader.resolve(void 0);
        }
        readQueue.length = 0;
      });
      this.on("abort", (err) => {
        done = true;
        for (const reader of readQueue) {
          reader.reject(err);
        }
        readQueue.length = 0;
      });
      this.on("error", (err) => {
        done = true;
        for (const reader of readQueue) {
          reader.reject(err);
        }
        readQueue.length = 0;
      });
      return {
        next: async () => {
          if (!pushQueue.length) {
            if (done) {
              return { value: void 0, done: true };
            }
            return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk2) => chunk2 ? { value: chunk2, done: false } : { value: void 0, done: true });
          }
          const chunk = pushQueue.shift();
          return { value: chunk, done: false };
        },
        return: async () => {
          this.abort();
          return { value: void 0, done: true };
        }
      };
    }
    toReadableStream() {
      const stream2 = new Stream(this[Symbol.asyncIterator].bind(this), this.controller);
      return stream2.toReadableStream();
    }
  }
  return BetaMessageStream2;
})();

// node_modules/@anthropic-ai/sdk/lib/internal/toolsets/family.mjs
var TOOLSET_TYPE_TO_FAMILY = {
  browser_toolset_20260801: "browser",
  computer_toolset_20260801: "computer"
};
function toolsetFamily(toolset) {
  return TOOLSET_TYPE_TO_FAMILY[toolset.type];
}
function isRunnableToolset(t) {
  return "run" in t && t.type != null && Object.prototype.hasOwnProperty.call(TOOLSET_TYPE_TO_FAMILY, t.type);
}

// node_modules/@anthropic-ai/sdk/lib/internal/toolsets/run.mjs
init_error();

// node_modules/@anthropic-ai/sdk/lib/internal/toolsets/errors.mjs
init_error();
var ToolsetUsageError = class extends AnthropicError {
  constructor(message, options) {
    super(message);
    this.name = "ToolsetUsageError";
    if (options && "cause" in options)
      this.cause = options.cause;
  }
};
var ToolsetContractError = class extends ToolsetUsageError {
  constructor(message, options) {
    super(message, options);
    this.name = "ToolsetContractError";
  }
};

// node_modules/@anthropic-ai/sdk/lib/internal/toolsets/run.mjs
var NOT_EXECUTED = "Not executed: an earlier action in this turn failed.";
var NOT_EXECUTED_BY_FAMILY = {
  browser: NOT_EXECUTED,
  computer: "Not executed: an earlier computer action in this turn failed."
};
function notExecutedText(family) {
  return Object.prototype.hasOwnProperty.call(NOT_EXECUTED_BY_FAMILY, family) ? NOT_EXECUTED_BY_FAMILY[family] : NOT_EXECUTED;
}
function toolsetResultBlock(toolUse, content, isError = false) {
  if (isError && (content === "" || Array.isArray(content) && content.length === 0)) {
    content = "The tool call failed with an empty error message.";
  }
  return {
    type: "tool_result",
    tool_use_id: toolUse.id,
    toolset_name: toolUse.toolset_name ?? null,
    content,
    ...isError ? { is_error: true } : {}
  };
}
function throwIfPropagates(error, ctx) {
  if (error instanceof ToolsetUsageError)
    throw error;
  throwIfAborted(ctx.signal);
}
function throwIfAborted(signal) {
  if (signal?.aborted)
    throw new APIUserAbortError();
}
async function runToolsetMember(toolset, toolUse, options = {}) {
  const family = toolsetFamily(toolset);
  if (toolUse.toolset_name !== family) {
    throw new ToolsetContractError(`tool_use ${JSON.stringify(toolUse.id)} (toolset_name=${JSON.stringify(toolUse.toolset_name ?? null)}, name=${JSON.stringify(toolUse.name)}) is not a member call of the ${JSON.stringify(family)} toolset`);
  }
  const ctx = { ...options, toolUse, toolUseBlock: toolUse };
  try {
    return toolsetResultBlock(toolUse, await toolset.run(ctx, toolUse));
  } catch (e) {
    throwIfPropagates(e, ctx);
    return toolsetResultBlock(toolUse, errorTextContent(e instanceof ToolError ? e.content : errorText(e)), true);
  }
}

// node_modules/@anthropic-ai/sdk/lib/tools/BetaToolRunner.mjs
init_error();

// node_modules/@anthropic-ai/sdk/resources/beta/organization/api-keys.mjs
var APIKeys = class extends APIResource {
  /**
   * Get API Key
   *
   * @example
   * ```ts
   * const betaAPIKey =
   *   await client.beta.organization.apiKeys.retrieve(
   *     'api_key_id',
   *   );
   * ```
   */
  retrieve(apiKeyID, options) {
    return this._client.get(path2`/v1/organizations/api_keys/${apiKeyID}?beta=true`, options);
  }
  /**
   * Update API Key
   *
   * @example
   * ```ts
   * const betaAPIKey =
   *   await client.beta.organization.apiKeys.update(
   *     'api_key_id',
   *   );
   * ```
   */
  update(apiKeyID, body, options) {
    return this._client.post(path2`/v1/organizations/api_keys/${apiKeyID}?beta=true`, { body, ...options });
  }
  /**
   * List API Keys
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAPIKey of client.beta.organization.apiKeys.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/api_keys?beta=true", Page, {
      query,
      ...options
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/artifacts.mjs
var Artifacts = class extends APIResource {
  /**
   * Get artifact-creation activity for a given day, broken out by MIME type.
   *
   * Returns the full (`artifact_type`, `is_shared`) cube for the organization;
   * `next_page` is null except for grouped queries, which paginate. The cube can be
   * broken out per product, per member, or per RBAC group via `group_by[]`, and
   * scoped via `filter[]`. Requires an API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsArtifactActivity of client.beta.organization.analytics.artifacts.list(
   *   { date: '2019-12-27' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(query, options) {
    return this._client.getAPIList("/v1/organizations/analytics/artifacts?beta=true", PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/connectors.mjs
var Connectors = class extends APIResource {
  /**
   * Get per-connector usage for a given day, with cursor-based pagination.
   *
   * Returns connector usage metrics for the organization, sorted by connector name.
   * Connector names are normalized from their various sources — for example,
   * "Atlassian MCP server" and "mcp-atlassian" both appear as "atlassian". Use
   * `group_by[]` to break usage out per member, per RBAC group, or per product
   * surface, and `filter[]` to scope results; the parameter descriptions list the
   * supported dimensions. Available to organizations on a Claude Enterprise plan.
   * Requires an API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsConnectorActivity of client.beta.organization.analytics.connectors.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/analytics/connectors?beta=true", PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/cost-report.mjs
var CostReport = class extends APIResource {
  /**
   * Get cost in USD over time across a date range.
   *
   * Returns cost bucketed by minute, hour, or day, optionally broken down by
   * product, model, context window, inference region, speed, cost type, or token
   * type. Available to organizations on a Claude Enterprise plan. Requires an API
   * key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsCostReportTimeBucket of client.beta.organization.analytics.costReport.list(
   *   { starting_at: '2019-12-27T18:11:19.117Z' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(query, options) {
    return this._client.getAPIList("/v1/organizations/analytics/cost_report?beta=true", PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/plugins.mjs
var Plugins = class extends APIResource {
  /**
   * Get per-plugin install + invocation usage for a given day, with pagination.
   *
   * Returns plugin usage metrics for the organization across Cowork and Claude Code,
   * sorted by plugin name. The `plugin_name` value `third-party` is an aggregate
   * bucket, not a plugin: it collects plugin activity, from either surface, for
   * which the reporting client did not provide a plugin name — so an organization's
   * own plugins can contribute both to their own named rows and to this bucket. Use
   * `group_by[]` to break usage out per member, per RBAC group, or per product
   * surface (Cowork / Claude Code), and `filter[]` to scope results; the parameter
   * descriptions list the supported dimensions. Requires an API key with the
   * `read:analytics` scope. `starting_date` / `ending_date` select range-rollup mode
   * like `/skills`.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsPluginActivity of client.beta.organization.analytics.plugins.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/analytics/plugins?beta=true", PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/skills.mjs
var Skills = class extends APIResource {
  /**
   * Get per-skill usage for a given day, with cursor-based pagination.
   *
   * Returns skill usage metrics for the organization, sorted by skill name. Use
   * `group_by[]` to break usage out per member, per RBAC group, or per product
   * surface, and `filter[]` to scope results; the parameter descriptions list the
   * supported dimensions. Available to organizations on a Claude Enterprise plan.
   * Requires an API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsSkillActivity of client.beta.organization.analytics.skills.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/analytics/skills?beta=true", PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/summaries.mjs
var Summaries = class extends APIResource {
  /**
   * Get organization-wide activity summaries for a date range.
   *
   * Returns one entry per day from `starting_date` (inclusive) to `ending_date`
   * (exclusive) in `data`, the same `data` / `next_page` envelope as the other
   * analytics list endpoints; the series is currently returned in full, so
   * `next_page` is always null. Data is typically available with a 1-day lag and may
   * be revised by a few percent over the following days: when `ending_date` is
   * omitted it defaults to the most recent available day + 1, so the last entry
   * covers the most recent available day. The series can be scoped to an RBAC group
   * via `filter[]=rbac_group_id:{id}`. Available to organizations on a Claude
   * Enterprise plan. Requires an API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsSingleDayActivitySummary of client.beta.organization.analytics.summaries.list(
   *   { starting_date: '2019-12-27' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(query, options) {
    return this._client.getAPIList("/v1/organizations/analytics/summaries?beta=true", PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/usage-report.mjs
var UsageReport = class extends APIResource {
  /**
   * Get token usage over time across a date range.
   *
   * Returns token usage bucketed by minute, hour, or day, optionally broken down by
   * product, model, context window, inference region, or speed. Available to
   * organizations on a Claude Enterprise plan. Requires an API key with the
   * `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsUsageReportTimeBucket of client.beta.organization.analytics.usageReport.list(
   *   { starting_at: '2019-12-27T18:11:19.117Z' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(query, options) {
    return this._client.getAPIList("/v1/organizations/analytics/usage_report?beta=true", PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/user-cost-report.mjs
var UserCostReport = class extends APIResource {
  /**
   * Get per-user cost in USD across a date range.
   *
   * Returns one row per user, ranked by spend. Use this to see which users account
   * for the most cost. Only cost attributable to a seat user is included; for
   * organization-wide totals including direct API-key and automation traffic, use
   * the bucketed `/v1/organizations/analytics/cost_report` endpoint. Available to
   * organizations on a Claude Enterprise plan. Requires an API key with the
   * `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsCostUsersItem of client.beta.organization.analytics.userCostReport.list(
   *   { starting_at: '2019-12-27T18:11:19.117Z' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(query, options) {
    return this._client.getAPIList("/v1/organizations/analytics/user_cost_report?beta=true", PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/user-usage-report.mjs
var UserUsageReport = class extends APIResource {
  /**
   * Get per-user token usage across a date range.
   *
   * Returns one row per user, ranked by the chosen token metric. Use this to see
   * which users consume the most tokens. Only usage attributable to a seat user is
   * included; for organization-wide totals including direct API-key and automation
   * traffic, use the bucketed `/v1/organizations/analytics/usage_report` endpoint.
   * Available to organizations on a Claude Enterprise plan. Requires an API key with
   * the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsUsageUsersItem of client.beta.organization.analytics.userUsageReport.list(
   *   { starting_at: '2019-12-27T18:11:19.117Z' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(query, options) {
    return this._client.getAPIList("/v1/organizations/analytics/user_usage_report?beta=true", PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/users.mjs
var Users = class extends APIResource {
  /**
   * Get per-user activity for a given day, with cursor-based pagination.
   *
   * Returns activity metrics for each user in the organization, sorted by email
   * address. Use `group_by[]` for per-RBAC-group aggregates, or `filter[]` to scope
   * results to specific members, groups, or a chat project. Available to
   * organizations on a Claude Enterprise plan. Requires an API key with the
   * `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsUserActivity of client.beta.organization.analytics.users.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/analytics/users?beta=true", PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/apps/chat/projects.mjs
var Projects = class extends APIResource {
  /**
   * Get per-project activity for a given day, with cursor-based pagination.
   *
   * Returns activity metrics for each project in the organization, sorted by project
   * ID. Use `group_by[]` to break projects out per member or per RBAC group, and
   * `filter[]` to scope results; the parameter descriptions list the supported
   * dimensions. Available to organizations on a Claude Enterprise plan. Requires an
   * API key with the `read:analytics` scope.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaAnalyticsProjectActivity of client.beta.organization.analytics.apps.chat.projects.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/analytics/apps/chat/projects?beta=true", PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/apps/chat/chat.mjs
var Chat = /* @__PURE__ */ (() => {
  class Chat2 extends APIResource {
    constructor() {
      super(...arguments);
      this.projects = new Projects(this._client);
    }
  }
  Chat2.Projects = Projects;
  return Chat2;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/apps/apps.mjs
var Apps = /* @__PURE__ */ (() => {
  class Apps2 extends APIResource {
    constructor() {
      super(...arguments);
      this.chat = new Chat(this._client);
    }
  }
  Apps2.Chat = Chat;
  return Apps2;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/organization/analytics/analytics.mjs
var Analytics = /* @__PURE__ */ (() => {
  class Analytics2 extends APIResource {
    constructor() {
      super(...arguments);
      this.summaries = new Summaries(this._client);
      this.users = new Users(this._client);
      this.apps = new Apps(this._client);
      this.connectors = new Connectors(this._client);
      this.plugins = new Plugins(this._client);
      this.skills = new Skills(this._client);
      this.artifacts = new Artifacts(this._client);
      this.usageReport = new UsageReport(this._client);
      this.userUsageReport = new UserUsageReport(this._client);
      this.costReport = new CostReport(this._client);
      this.userCostReport = new UserCostReport(this._client);
    }
  }
  Analytics2.Summaries = Summaries;
  Analytics2.Users = Users;
  Analytics2.Apps = Apps;
  Analytics2.Connectors = Connectors;
  Analytics2.Plugins = Plugins;
  Analytics2.Skills = Skills;
  Analytics2.Artifacts = Artifacts;
  Analytics2.UsageReport = UsageReport;
  Analytics2.UserUsageReport = UserUsageReport;
  Analytics2.CostReport = CostReport;
  Analytics2.UserCostReport = UserCostReport;
  return Analytics2;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/organization/compliance-settings.mjs
var ComplianceSettings = class extends APIResource {
  /**
   * Retrieve your organization's Compliance Settings.
   *
   * Compliance Settings is a singleton resource: there is exactly one per
   * organization, addressed without an identifier. The `state` field reflects
   * whether the Compliance API is enabled. An organization with a parent
   * organization reads the state inherited from the parent's configuration.
   *
   * @example
   * ```ts
   * const betaComplianceSettings =
   *   await client.beta.organization.complianceSettings.retrieve();
   * ```
   */
  retrieve(options) {
    return this._client.get("/v1/organizations/compliance_settings?beta=true", options);
  }
  /**
   * Update your organization's Compliance Settings.
   *
   * Setting `state` to `enabled` turns on the Compliance API and begins capturing
   * organization activity events. Setting it to `disabled` turns both off. `state`
   * reflects whether the Compliance API is enabled.
   *
   * A request that sets `state` to its current value succeeds and leaves the
   * resource unchanged. A `disabled` request stays in effect until a later `enabled`
   * request or the organization's next provisioning action that enables Access
   * Transparency: enabling Access Transparency also enables the Compliance API,
   * which serves its activity events, so such provisioning (including re-runs)
   * re-enables the Compliance API even after a `disabled` request. Automated
   * provisioning never disables compliance settings.
   *
   * @example
   * ```ts
   * const betaComplianceSettings =
   *   await client.beta.organization.complianceSettings.update({
   *     state: { type: 'enabled' },
   *   });
   * ```
   */
  update(body, options) {
    return this._client.post("/v1/organizations/compliance_settings?beta=true", { body, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/external-keys.mjs
var ExternalKeys = class extends APIResource {
  /**
   * Create an external key config owned by the caller's organization.
   *
   * @example
   * ```ts
   * const betaExternalKey =
   *   await client.beta.organization.externalKeys.create({
   *     provider_config: {
   *       kms_arn:
   *         'arn:aws:kms:us-east-1:111122223333:key/abcd1234-5678-90ab-cdef-000011112222',
   *       type: 'aws',
   *     },
   *   });
   * ```
   */
  create(body, options) {
    return this._client.post("/v1/organizations/external_keys?beta=true", { body, ...options });
  }
  /**
   * Retrieve a single external key config in the caller's organization by ID.
   *
   * @example
   * ```ts
   * const betaExternalKey =
   *   await client.beta.organization.externalKeys.retrieve(
   *     'external_key_id',
   *   );
   * ```
   */
  retrieve(externalKeyID, options) {
    return this._client.get(path2`/v1/organizations/external_keys/${externalKeyID}?beta=true`, options);
  }
  /**
   * Partially update an external key config. Omitted fields are left unchanged.
   *
   * `display_name` is always editable. `geo` and `provider_config` cannot be changed
   * once any workspace references this config, because previously encrypted data
   * requires the original key identity to decrypt.
   *
   * @example
   * ```ts
   * const betaExternalKey =
   *   await client.beta.organization.externalKeys.update(
   *     'external_key_id',
   *   );
   * ```
   */
  update(externalKeyID, body, options) {
    return this._client.post(path2`/v1/organizations/external_keys/${externalKeyID}?beta=true`, {
      body,
      ...options
    });
  }
  /**
   * List external key configs in the caller's organization.
   *
   * Results are ordered by creation time (newest first). Use the `next_page` cursor
   * from the response to fetch subsequent pages.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaExternalKey of client.beta.organization.externalKeys.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/external_keys?beta=true", PageCursor, {
      query,
      ...options
    });
  }
  /**
   * Delete an external key config.
   *
   * The request is rejected if any workspace still references this config.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.beta.organization.externalKeys.delete(
   *     'external_key_id',
   *   );
   * ```
   */
  delete(externalKeyID, options) {
    return this._client.delete(path2`/v1/organizations/external_keys/${externalKeyID}?beta=true`, options);
  }
  /**
   * Validate an external key config against the customer's KMS.
   *
   * Anthropic performs an encrypt/decrypt roundtrip against the configured KMS key
   * and waits up to 30 seconds for the result. The response status is `success` if
   * the roundtrip succeeded, or `failure` with an error message if it failed or
   * timed out.
   *
   * @example
   * ```ts
   * const response =
   *   await client.beta.organization.externalKeys.validate(
   *     'external_key_id',
   *   );
   * ```
   */
  validate(externalKeyID, options) {
    return this._client.post(path2`/v1/organizations/external_keys/${externalKeyID}/validate?beta=true`, options);
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/federation/issuers.mjs
var Issuers = class extends APIResource {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Register an OIDC issuer that Anthropic will trust for workload identity
   * federation in your organization.
   *
   * The `jwks` field controls how the issuer's signing keys are obtained and takes
   * one of three shapes selected by `type`: `discovery` (resolve keys through OIDC
   * discovery), `explicit_url` (fetch keys from a fixed JWKS URL), or `inline`
   * (provide a static key set). When `jwks.type` is `discovery` and no
   * `discovery_base` is set, the issuer URL must be publicly reachable over HTTPS so
   * Anthropic can fetch the discovery document; for `explicit_url` and `inline`
   * modes the issuer URL is only matched as the JWT's `iss` claim and is not
   * fetched.
   *
   * @example
   * ```ts
   * const betaFederationIssuer =
   *   await client.beta.organization.federation.issuers.create({
   *     issuer_url: 'x',
   *     name: 'x',
   *   });
   * ```
   */
  create(params, options) {
    const { betas, ...body } = params;
    return this._client.post("/v1/organizations/federation_issuers?beta=true", {
      body,
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Retrieve a federation issuer by its ID (`fdis_...`).
   *
   * @example
   * ```ts
   * const betaFederationIssuer =
   *   await client.beta.organization.federation.issuers.retrieve(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  retrieve(federationIssuerID, params = {}, options) {
    const { betas } = params ?? {};
    return this._client.get(path2`/v1/organizations/federation_issuers/${federationIssuerID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Partially update a federation issuer.
   *
   * Setting `jwks` replaces the full JWKS shape at once. Archived issuers cannot be
   * updated; this returns 400. Create a new issuer instead.
   *
   * Updating an issuer that backs a rule with a scope outside `workspace:developer`
   * or `workspace:inference` requires a Console session.
   *
   * @example
   * ```ts
   * const betaFederationIssuer =
   *   await client.beta.organization.federation.issuers.update(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  update(federationIssuerID, params, options) {
    const { betas, ...body } = params;
    return this._client.post(path2`/v1/organizations/federation_issuers/${federationIssuerID}?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List federation issuers in your organization.
   *
   * Archived issuers are excluded unless `include_archived=true`.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaFederationIssuer of client.beta.organization.federation.issuers.list()) {
   *   // ...
   * }
   * ```
   */
  list(params = {}, options) {
    const { betas, ...query } = params ?? {};
    return this._client.getAPIList("/v1/organizations/federation_issuers?beta=true", PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Archive a federation issuer.
   *
   * Idempotent; re-archiving returns the issuer with its original `archived_at`.
   * Rejected with 400 if any live (non-archived) federation rule still references
   * the issuer; archive those rules first (a rule's issuer cannot be changed), or
   * recreate them against another issuer.
   *
   * @example
   * ```ts
   * const betaFederationIssuer =
   *   await client.beta.organization.federation.issuers.archive(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  archive(federationIssuerID, params = {}, options) {
    const { betas } = params ?? {};
    return this._client.post(path2`/v1/organizations/federation_issuers/${federationIssuerID}/archive?beta=true`, {
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/federation/rules/workspaces.mjs
var Workspaces = class extends APIResource {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List workspaces where this federation rule is enabled.
   *
   * Returns all workspace enablements in a single response; the `limit` and `page`
   * parameters are accepted but have no effect, and `next_page` is always `null`.
   * Returns explicit per-workspace enablements only; for rules with
   * `applies_to_all_workspaces` or a legacy single `workspace_id`, check those
   * fields on the rule itself.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaFederationRuleWorkspace of client.beta.organization.federation.rules.workspaces.list(
   *   'federation_rule_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(federationRuleID, params = {}, options) {
    const { betas, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/organizations/federation_rules/${federationRuleID}/workspaces?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Enable a federation rule for a workspace.
   *
   * Idempotent; re-enabling returns the existing enablement. The rule and workspace
   * must both belong to your organization. Membership of the rule's target service
   * account in this workspace is not checked at enablement: token exchange into this
   * workspace is rejected unless the target is a member (it is implicitly a member
   * of the default workspace). Archived rules are rejected with 400. OAuth callers
   * may only manage rules whose `oauth_scope` is `workspace:developer` or
   * `workspace:inference`; other scopes require a Console session.
   *
   * @example
   * ```ts
   * const betaFederationRuleWorkspace =
   *   await client.beta.organization.federation.rules.workspaces.add(
   *     'federation_rule_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  add(federationRuleID, params, options) {
    const { betas, ...body } = params;
    return this._client.post(path2`/v1/organizations/federation_rules/${federationRuleID}/workspaces?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Disable a federation rule for a workspace.
   *
   * Idempotent; succeeds even if the enablement was already removed. OAuth callers
   * may only manage rules whose `oauth_scope` is `workspace:developer` or
   * `workspace:inference`; other scopes require a Console session.
   *
   * @example
   * ```ts
   * const workspace =
   *   await client.beta.organization.federation.rules.workspaces.remove(
   *     'workspace_id',
   *     { federation_rule_id: 'federation_rule_id' },
   *   );
   * ```
   */
  remove(workspaceID, params, options) {
    const { federation_rule_id, betas } = params;
    return this._client.delete(path2`/v1/organizations/federation_rules/${federation_rule_id}/workspaces/${workspaceID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/federation/rules/rules.mjs
var Rules = /* @__PURE__ */ (() => {
  class Rules3 extends APIResource {
    constructor() {
      super(...arguments);
      this.workspaces = new Workspaces(this._client);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Create a federation rule owned by your organization.
     *
     * The referenced issuer and the target service account must already exist in the
     * same organization; invalid references are rejected with a 400 error. The
     * workspace reference is validated. Membership is not checked at rule creation:
     * token exchange resolves a single enabled workspace per call and is rejected
     * unless the target service account is a member of that workspace (it is
     * implicitly a member of the default workspace). Rules on well-known shared
     * issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud, Google) must
     * constrain tenant identity via an identity-bearing claim, a tenant-pinning
     * subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition referencing one
     * of those identity claims (e.g. `claims.repository_owner`). OAuth callers may
     * only manage rules whose `oauth_scope` is `workspace:developer` or
     * `workspace:inference`; other scopes require a Console session.
     *
     * @example
     * ```ts
     * const betaFederationRule =
     *   await client.beta.organization.federation.rules.create({
     *     issuer_id: 'issuer_id',
     *     match: {},
     *     name: 'x',
     *     oauth_scope: 'x',
     *     target: {
     *       service_account_id: 'svac_01SDCCSbTxrXDpWc1phhtcfK',
     *       type: 'service_account',
     *     },
     *   });
     * ```
     */
    create(params, options) {
      const { betas, ...body } = params;
      return this._client.post("/v1/organizations/federation_rules?beta=true", {
        body,
        ...options,
        headers: buildHeaders([
          { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
          options?.headers
        ])
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Retrieve a federation rule by its ID (`fdrl_...`).
     *
     * @example
     * ```ts
     * const betaFederationRule =
     *   await client.beta.organization.federation.rules.retrieve(
     *     'federation_rule_id',
     *   );
     * ```
     */
    retrieve(federationRuleID, params = {}, options) {
      const { betas } = params ?? {};
      return this._client.get(path2`/v1/organizations/federation_rules/${federationRuleID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
          options?.headers
        ])
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Partially update a federation rule.
     *
     * `issuer_id` is immutable. `match` and `target` are replaced as whole objects
     * when set. Referenced service accounts and workspaces must exist in your
     * organization; invalid references are rejected with a 400 error. Archived rules
     * cannot be updated; this returns 400. Create a new rule instead. Rules on
     * well-known shared issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud,
     * Google) must constrain tenant identity via an identity-bearing claim, a
     * tenant-pinning subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition
     * referencing one of those identity claims (e.g. `claims.repository_owner`). On
     * these issuers the requirement is re-checked on every update; if an existing
     * rule's stored match does not yet constrain tenant identity, any update (even a
     * rename or description change) must also supply a conforming `match` in the same
     * request. OAuth callers may only manage rules whose `oauth_scope` is
     * `workspace:developer` or `workspace:inference`; other scopes require a Console
     * session.
     *
     * @example
     * ```ts
     * const betaFederationRule =
     *   await client.beta.organization.federation.rules.update(
     *     'federation_rule_id',
     *   );
     * ```
     */
    update(federationRuleID, params, options) {
      const { betas, ...body } = params;
      return this._client.post(path2`/v1/organizations/federation_rules/${federationRuleID}?beta=true`, {
        body,
        ...options,
        headers: buildHeaders([
          { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
          options?.headers
        ])
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * List federation rules in your organization.
     *
     * Optionally filter by issuer with `issuer_id`. Archived rules are excluded unless
     * `include_archived=true`.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaFederationRule of client.beta.organization.federation.rules.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
      const { betas, ...query } = params ?? {};
      return this._client.getAPIList("/v1/organizations/federation_rules?beta=true", PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
          options?.headers
        ])
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Archive a federation rule.
     *
     * Token exchange through this rule stops immediately. Idempotent; re-archiving
     * returns the rule with its original `archived_at`. Archiving clears the rule's
     * workspace targeting (`workspace_id` and `workspace_ids` are emptied). Tokens
     * already minted before archive remain valid until they expire. OAuth callers may
     * only manage rules whose `oauth_scope` is `workspace:developer` or
     * `workspace:inference`; other scopes require a Console session.
     *
     * @example
     * ```ts
     * const betaFederationRule =
     *   await client.beta.organization.federation.rules.archive(
     *     'federation_rule_id',
     *   );
     * ```
     */
    archive(federationRuleID, params = {}, options) {
      const { betas } = params ?? {};
      return this._client.post(path2`/v1/organizations/federation_rules/${federationRuleID}/archive?beta=true`, {
        ...options,
        headers: buildHeaders([
          { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
          options?.headers
        ])
      });
    }
  }
  Rules3.Workspaces = Workspaces;
  return Rules3;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/organization/federation/federation.mjs
var Federation = /* @__PURE__ */ (() => {
  class Federation3 extends APIResource {
    constructor() {
      super(...arguments);
      this.issuers = new Issuers(this._client);
      this.rules = new Rules(this._client);
    }
  }
  Federation3.Issuers = Issuers;
  Federation3.Rules = Rules;
  return Federation3;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/organization/invites.mjs
var Invites = class extends APIResource {
  /**
   * Invite a user to join the organization by email.
   *
   * On plans that draw members from a finite pool of purchased seats, the invite
   * automatically consumes a seat from the lowest tier with availability; there is
   * no seat-tier parameter. When no seat is free the request fails with a 400 error
   * rather than purchasing a seat.
   *
   * @example
   * ```ts
   * const betaOrganizationInvite =
   *   await client.beta.organization.invites.create({
   *     email: 'user@emaildomain.com',
   *     role: 'user',
   *   });
   * ```
   */
  create(body, options) {
    return this._client.post("/v1/organizations/invites?beta=true", { body, ...options });
  }
  /**
   * Retrieve an invite by ID.
   *
   * @example
   * ```ts
   * const betaOrganizationInvite =
   *   await client.beta.organization.invites.retrieve(
   *     'invite_id',
   *   );
   * ```
   */
  retrieve(inviteID, options) {
    return this._client.get(path2`/v1/organizations/invites/${inviteID}?beta=true`, options);
  }
  /**
   * List the organization's invites.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaOrganizationInvite of client.beta.organization.invites.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/invites?beta=true", Page, {
      query,
      ...options
    });
  }
  /**
   * Delete a pending invite.
   *
   * @example
   * ```ts
   * const invite =
   *   await client.beta.organization.invites.delete(
   *     'invite_id',
   *   );
   * ```
   */
  delete(inviteID, options) {
    return this._client.delete(path2`/v1/organizations/invites/${inviteID}?beta=true`, options);
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/plugin-marketplaces.mjs
var PluginMarketplaces = class extends APIResource {
  /**
   * Retrieve a plugin marketplace by ID.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginMarketplace =
   *   await client.beta.organization.pluginMarketplaces.retrieve(
   *     'marketplace_id',
   *   );
   * ```
   */
  retrieve(marketplaceID, params = {}, options) {
    const { betas, ...query } = params ?? {};
    return this._client.get(path2`/v1/organizations/plugin_marketplaces/${marketplaceID}?beta=true`, {
      query,
      ...options,
      headers: buildHeaders([
        { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
        options?.headers
      ])
    });
  }
  /**
   * Set the default installation setting of one of the organization's own plugin
   * marketplaces. Every Plugin in it without a setting of its own gets this default
   * as its organization-wide setting, including Plugins added later.
   *
   * Pass it as `default_installation_preference`. A member's personal marketplace
   * cannot be updated here (403).
   *
   * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginMarketplace =
   *   await client.beta.organization.pluginMarketplaces.update(
   *     'marketplace_id',
   *     { default_installation_preference: 'available' },
   *   );
   * ```
   */
  update(marketplaceID, params, options) {
    const { betas, ...body } = params;
    return this._client.post(path2`/v1/organizations/plugin_marketplaces/${marketplaceID}?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
        options?.headers
      ])
    });
  }
  /**
   * List the plugin marketplaces Plugins live in, newest first: the organization's
   * own and its members' personal ones.
   *
   * Plugin marketplaces are created, connected to a repository and deleted in
   * claude.ai, not through this API. The organization's library marketplace, the
   * organization-owned `manual` marketplace that uploads go to when no marketplace
   * is named, is created the first time something is put in it and is listed from
   * then on.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaPluginMarketplace of client.beta.organization.pluginMarketplaces.list()) {
   *   // ...
   * }
   * ```
   */
  list(params = {}, options) {
    const { betas, ...query } = params ?? {};
    return this._client.getAPIList("/v1/organizations/plugin_marketplaces?beta=true", PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
        options?.headers
      ])
    });
  }
  /**
   * Check whether a plugin marketplace, uploaded as a `.zip` of the marketplace
   * directory, would synchronize into claude.ai, without connecting or storing it.
   *
   * To check a public GitHub repository instead, use Validate Plugin Marketplace
   * Repository.
   *
   * The report says whether `marketplace.json` is well-formed, which plugins a
   * synchronization would skip and why, and which plugins would synchronize only in
   * part, with some files left out. An archive that cannot be read as a marketplace
   * is reported, not refused: the response is a report with `valid: false`. Plugin
   * sources outside the marketplace are fetched anonymously from GitHub, so a
   * private one is reported as not found; a source on any other host is not fetched
   * here, and the report notes that it will be checked when the marketplace actually
   * synchronizes.
   *
   * Nothing is recorded on the Compliance API activity feed.
   *
   * For a worked example, see
   * [Validate marketplace content](/docs/en/manage-claude/plugins-api#validate-marketplace-content)
   * in the Plugins API guide.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `write:plugins` scope; `read:org_audit` and `read:compliance_org_data` do not
   * grant it.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginMarketplaceValidationReport =
   *   await client.beta.organization.pluginMarketplaces.validateArchive(
   *     { archive: fs.createReadStream('path/to/file') },
   *   );
   * ```
   */
  validateArchive(params, options) {
    const { betas, ...body } = params;
    return this._client.post("/v1/organizations/plugin_marketplaces/validate_archive?beta=true", multipartFormRequestOptions({
      body,
      ...options,
      headers: buildHeaders([
        { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
        options?.headers
      ])
    }, this._client));
  }
  /**
   * Check whether a plugin marketplace held in a public GitHub repository would
   * synchronize into claude.ai, without connecting or storing it.
   *
   * To check a `.zip` of the marketplace directory instead, use Validate Plugin
   * Marketplace Archive.
   *
   * The report says whether `marketplace.json` is well-formed, which plugins a
   * synchronization would skip and why, and which plugins would synchronize only in
   * part, with some files left out. A repository that is missing, private, or has no
   * such branch or commit is reported, not refused: the response is a report with
   * `valid: false`. Plugin sources outside the marketplace are fetched anonymously
   * from GitHub, so a private one is reported as not found; a source on any other
   * host is not fetched here, and the report notes that it will be checked when the
   * marketplace actually synchronizes.
   *
   * Nothing is recorded on the Compliance API activity feed.
   *
   * For a worked example, see
   * [Validate marketplace content](/docs/en/manage-claude/plugins-api#validate-marketplace-content)
   * in the Plugins API guide.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `write:plugins` scope; `read:org_audit` and `read:compliance_org_data` do not
   * grant it.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginMarketplaceValidationReport =
   *   await client.beta.organization.pluginMarketplaces.validateRepository(
   *     {
   *       repository_url:
   *         'https://github.com/example-org/example-marketplace',
   *     },
   *   );
   * ```
   */
  validateRepository(params, options) {
    const { betas, ...body } = params;
    return this._client.post("/v1/organizations/plugin_marketplaces/validate_repository?beta=true", {
      body,
      ...options,
      headers: buildHeaders([
        { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/rate-limits.mjs
var RateLimits = class extends APIResource {
  /**
   * List Messages API rate limits for your organization.
   *
   * Each entry corresponds to one rate-limit group (either a model family or an
   * API-surface category such as the Message Batches API or the web search tool) and
   * contains the set of limiter values that apply to it.
   *
   * When `limit` is omitted, every matching entry is returned in a single page; when
   * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaOrganizationRateLimit of client.beta.organization.rateLimits.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/rate_limits?beta=true", PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/users.mjs
var Users2 = class extends APIResource {
  /**
   * Retrieve a member of the organization by user ID.
   *
   * @example
   * ```ts
   * const betaOrganizationUser =
   *   await client.beta.organization.users.retrieve('user_id');
   * ```
   */
  retrieve(userID, options) {
    return this._client.get(path2`/v1/organizations/users/${userID}?beta=true`, options);
  }
  /**
   * Update a member's organization role.
   *
   * @example
   * ```ts
   * const betaOrganizationUser =
   *   await client.beta.organization.users.update('user_id', {
   *     role: 'user',
   *   });
   * ```
   */
  update(userID, body, options) {
    return this._client.post(path2`/v1/organizations/users/${userID}?beta=true`, { body, ...options });
  }
  /**
   * List the organization's members.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaOrganizationUser of client.beta.organization.users.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/users?beta=true", Page, {
      query,
      ...options
    });
  }
  /**
   * Remove a member from the organization.
   *
   * @example
   * ```ts
   * const user = await client.beta.organization.users.remove(
   *   'user_id',
   * );
   * ```
   */
  remove(userID, options) {
    return this._client.delete(path2`/v1/organizations/users/${userID}?beta=true`, options);
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/plugins/installation-settings.mjs
var InstallationSettings = class extends APIResource {
  /**
   * List an organization-owned Plugin's installation settings, which say which
   * members it is for, most recently created first.
   *
   * The list holds the Plugin's own organization-wide setting (absent while the
   * Plugin inherits its marketplace's default) and each RBAC Group's own setting. A
   * member-owned Plugin has shares instead, so this path returns 404 for one.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaPluginInstallationSetting of client.beta.organization.plugins.installationSettings.list(
   *   'plugin_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(pluginID, params = {}, options) {
    const { betas, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/organizations/plugins/${pluginID}/installation_settings?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
        options?.headers
      ])
    });
  }
  /**
   * Remove an organization-owned Plugin's own installation setting for the whole
   * organization or for one RBAC Group.
   *
   * Removing the `organization` target returns the Plugin to its marketplace's
   * default installation setting and leaves the groups' settings in place. Removing
   * a group's setting makes the group's members fall back to the Plugin's
   * organization-wide setting or to the settings of their other groups.
   *
   * A target that holds no setting of its own returns 404 (a Plugin that already
   * inherits its marketplace's default holds no `organization` setting), and so does
   * a member-owned Plugin.
   *
   * A removal counts as one of the Plugin's installation-setting writes: send all of
   * those writes one at a time. If several arrive for the same Plugin at the same
   * time, the server handles them one after another and can answer some of them with
   * `503` and `x-should-retry: true` instead of applying them; wait a second or two
   * and send the removal again. A `404` on the repeat means the setting is already
   * gone.
   *
   * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaDeletedPluginInstallationSetting =
   *   await client.beta.organization.plugins.installationSettings.remove(
   *     'target',
   *     { plugin_id: 'plugin_id' },
   *   );
   * ```
   */
  remove(target, params, options) {
    const { plugin_id, betas } = params;
    return this._client.delete(path2`/v1/organizations/plugins/${plugin_id}/installation_settings/${target}?beta=true`, {
      ...options,
      headers: buildHeaders([
        { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
        options?.headers
      ])
    });
  }
  /**
   * Set or change an organization-owned Plugin's installation setting for the whole
   * organization or for one RBAC Group.
   *
   * Writing the value a target already holds of its own changes nothing.
   *
   * A member-owned Plugin has shares instead of installation settings, so this path
   * returns 404 for one.
   *
   * Send a Plugin's installation-setting writes one at a time. If several writes for
   * the same Plugin arrive at the same time, the server handles them one after
   * another and can answer some of them with `503` instead of applying them. That
   * `503` carries `x-should-retry: true`, and the write is safe to repeat: wait a
   * second or two, then send it again.
   *
   * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginInstallationSetting =
   *   await client.beta.organization.plugins.installationSettings.set(
   *     'target',
   *     {
   *       plugin_id: 'plugin_id',
   *       installation_preference: 'required',
   *     },
   *   );
   * ```
   */
  set(target, params, options) {
    const { plugin_id, betas, ...body } = params;
    return this._client.post(path2`/v1/organizations/plugins/${plugin_id}/installation_settings/${target}?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/plugins/shares.mjs
var Shares = class extends APIResource {
  /**
   * List the shares the owner of a member-owned Plugin has given — to every member
   * of the organization, to an RBAC Group, or to one member — most recently granted
   * first.
   *
   * Shares are read-only in this API: members give and withdraw them in claude.ai,
   * and who gave a share is recorded on the Compliance API activity feed rather than
   * on the share. An organization-owned Plugin has installation settings instead, so
   * this path returns 404 for one.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaPluginShare of client.beta.organization.plugins.shares.list(
   *   'plugin_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(pluginID, params = {}, options) {
    const { betas, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/organizations/plugins/${pluginID}/shares?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/plugins/versions.mjs
var Versions2 = class extends APIResource {
  /**
   * Add a version to an organization-owned Plugin by uploading the new version's
   * files; it becomes the version served to members unless the Plugin's served
   * version has been pinned.
   *
   * The upload is the same `multipart/form-data` as creating a Plugin: the version's
   * files (`files`, each part sent as `files[]`) and optional `release_notes`. The
   * uploaded manifest's `name` must equal the Plugin's `name`. Returns the stored
   * version; read the Plugin back to see which version it serves.
   *
   * Only a Plugin in a `manual` marketplace takes uploads; a Plugin synchronized
   * from a repository gets its versions from the repository. When the Plugin is in
   * the organization's library marketplace, a version that adds a skill with the
   * name of an organization skill (a skill an administrator uploaded for the whole
   * organization in claude.ai) is refused with a 409: `error_code`
   * `skill_name_taken`, with that name in `details.skill_name`. A 503 with
   * `error_code` `registration_pending` means the version was stored but is not yet
   * usable; a later version create on the Plugin completes it.
   *
   * For a worked example, see
   * [Create a version](/docs/en/manage-claude/plugins-api#create-a-version) in the
   * Plugins API guide.
   *
   * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginVersion =
   *   await client.beta.organization.plugins.versions.create(
   *     'plugin_id',
   *     { files: [fs.createReadStream('path/to/file')] },
   *   );
   * ```
   */
  create(pluginID, params, options) {
    const { betas, ...body } = params;
    return this._client.post(path2`/v1/organizations/plugins/${pluginID}/versions?beta=true`, multipartFormRequestOptions({
      body,
      ...options,
      headers: buildHeaders([
        { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
        options?.headers
      ])
    }, this._client));
  }
  /**
   * Retrieve one version of a Plugin by its ID, or the Plugin's newest version.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const betaPluginVersion =
   *   await client.beta.organization.plugins.versions.retrieve(
   *     'version',
   *     { plugin_id: 'plugin_id' },
   *   );
   * ```
   */
  retrieve(version, params, options) {
    const { plugin_id, betas, ...query } = params;
    return this._client.get(path2`/v1/organizations/plugins/${plugin_id}/versions/${version}?beta=true`, {
      query,
      ...options,
      headers: buildHeaders([
        { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
        options?.headers
      ])
    });
  }
  /**
   * List a Plugin's versions, newest first.
   *
   * The first item of the first page is the version the Plugin's `latest_version_id`
   * refers to.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaPluginVersion of client.beta.organization.plugins.versions.list(
   *   'plugin_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(pluginID, params = {}, options) {
    const { betas, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/organizations/plugins/${pluginID}/versions?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
        options?.headers
      ])
    });
  }
  /**
   * Download one version's `.zip` archive, exactly as stored. Each download of a
   * Plugin from a member's personal plugin marketplace is recorded on the Compliance
   * API activity feed.
   *
   * The response body is the archive (`Content-Type: application/zip`), sent as an
   * attachment whose filename is derived from the Plugin's name; name saved files
   * from the IDs in the request path, since that filename is not unique.
   *
   * **Accepted credentials:** an Admin API key with the `read:plugins` or
   * `read:org_audit` scope, or a Compliance Access Key with the
   * `read:compliance_org_data` scope.
   *
   * Every read scope above (`read:plugins`, `read:org_audit`, and
   * `read:compliance_org_data`) can download the files of plugins in members'
   * personal marketplaces, including files that claude.ai's admin settings do not
   * show, and a `read:org_audit` or `read:compliance_org_data` key created for all
   * of your parent organization's linked organizations can do this in any
   * organization under it that has access to this API, by passing `organization_id`.
   * Each such download records a `claude_plugin_archive_accessed` event on the
   * Compliance API activity feed, identifying the key, the plugin, the version, and
   * the member. Downloads of organization-owned plugins are not recorded.
   *
   * Every request must include the beta header
   * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
   * exactly as if the endpoint did not exist. The Plugins API is in beta and is
   * available to Claude Enterprise organizations only. It is not available to Claude
   * Platform (Claude Console) organizations, or to organizations with HIPAA
   * readiness enabled.
   *
   * @example
   * ```ts
   * const response =
   *   await client.beta.organization.plugins.versions.download(
   *     'version',
   *     { plugin_id: 'plugin_id' },
   *   );
   *
   * const content = await response.blob();
   * console.log(content);
   * ```
   */
  download(version, params, options) {
    const { plugin_id, betas, ...query } = params;
    return this._client.get(path2`/v1/organizations/plugins/${plugin_id}/versions/${version}/content?beta=true`, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString(),
          Accept: "application/binary"
        },
        options?.headers
      ]),
      __binaryResponse: true
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/plugins/plugins.mjs
var Plugins2 = /* @__PURE__ */ (() => {
  class Plugins3 extends APIResource {
    constructor() {
      super(...arguments);
      this.versions = new Versions2(this._client);
      this.installationSettings = new InstallationSettings(this._client);
      this.shares = new Shares(this._client);
    }
    /**
     * Create an organization-owned Plugin and its first version by uploading the
     * version's files.
     *
     * The upload is `multipart/form-data`: the version's files (`files`, each part
     * sent as `files[]`), with an optional `marketplace_id` and `release_notes`. The
     * manifest's `name` becomes the Plugin's `name`, and `display_name`, `description`
     * and `manifest_version` come from the manifest too.
     *
     * `name` may contain lowercase letters (from any alphabet), digits, and hyphens,
     * up to 64 characters. Uppercase letters, spaces, underscores, and other
     * punctuation are rejected.
     *
     * The `name` must be unique within the marketplace: a name already taken returns a
     * 409 with `error_code` `plugin_name_taken` and, when a Plugin holds it, that
     * Plugin's ID in `details.plugin_id`. A Plugin going into the organization's
     * library marketplace is also refused with a 409 when one of its skills has the
     * name of an organization skill (a skill an administrator uploaded for the whole
     * organization in claude.ai): `error_code` `skill_name_taken`, with that name in
     * `details.skill_name`; rename the skill, or remove the organization skill in
     * claude.ai. A 503 with `error_code` `registration_pending` means the Plugin and
     * its version were stored (their IDs are in `details`) but are not yet usable in
     * claude.ai: do not retry the create (the retry would return `plugin_name_taken`);
     * create a version on the stored Plugin instead, which completes it.
     *
     * For a worked example, see
     * [Create a plugin](/docs/en/manage-claude/plugins-api#create-a-plugin) in the
     * Plugins API guide.
     *
     * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPlugin =
     *   await client.beta.organization.plugins.create({
     *     files: [fs.createReadStream('path/to/file')],
     *   });
     * ```
     */
    create(params, options) {
      const { betas, ...body } = params;
      return this._client.post("/v1/organizations/plugins?beta=true", multipartFormRequestOptions({
        body,
        ...options,
        headers: buildHeaders([
          { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
          options?.headers
        ])
      }, this._client));
    }
    /**
     * Retrieve a Plugin by ID.
     *
     * **Accepted credentials:** an Admin API key with the `read:plugins` or
     * `read:org_audit` scope, or a Compliance Access Key with the
     * `read:compliance_org_data` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPlugin =
     *   await client.beta.organization.plugins.retrieve(
     *     'plugin_id',
     *   );
     * ```
     */
    retrieve(pluginID, params = {}, options) {
      const { betas, ...query } = params ?? {};
      return this._client.get(path2`/v1/organizations/plugins/${pluginID}?beta=true`, {
        query,
        ...options,
        headers: buildHeaders([
          { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
          options?.headers
        ])
      });
    }
    /**
     * Change which stored version of an organization-owned Plugin is served to
     * members, for example to roll back to an earlier one. This pins the served
     * version: later uploads are stored but no longer change what is served, and
     * pinning cannot currently be undone, here or in claude.ai.
     *
     * Pass the version as `served_version_id`: an earlier one to roll back, a later
     * one to start serving a version that was stored without being served, or the one
     * already served to pin it without changing what is served. No new version is
     * created.
     *
     * When the organization has content scanning enabled, a version whose scan is
     * still running is refused with a 409 (`error_code` `scan_pending`; retry once the
     * scan finishes) and one whose scan failed, errored or reached no verdict with a
     * 400 (`scan_failed`; a `warn` is accepted). When the Plugin is in the
     * organization's library marketplace, a version other than the one served is also
     * refused with a 409 when one of its skills has a name that an organization skill
     * (one an administrator uploaded for the whole organization in claude.ai) has
     * since taken: `error_code` `skill_name_taken`, with that name in
     * `details.skill_name`. A member-owned Plugin cannot be updated here (403).
     *
     * This endpoint does not write installation settings; they are written at
     * `/v1/organizations/plugins/{plugin_id}/installation_settings/{target}`.
     *
     * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaPlugin =
     *   await client.beta.organization.plugins.update(
     *     'plugin_id',
     *     {
     *       served_version_id:
     *         'pluginver_01KaZmQpRsTuVwXyZ2b4c6d8',
     *     },
     *   );
     * ```
     */
    update(pluginID, params, options) {
      const { betas, ...body } = params;
      return this._client.post(path2`/v1/organizations/plugins/${pluginID}?beta=true`, {
        body,
        ...options,
        headers: buildHeaders([
          { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
          options?.headers
        ])
      });
    }
    /**
     * List the Plugins created under the organization, newest first: those in the
     * organization's own plugin marketplaces and those in members' personal plugin
     * marketplaces.
     *
     * Plugins in members' personal marketplaces are listed with the same detail as the
     * organization's own, and their files can be downloaded through the version
     * archive endpoint, which records each such download on the Compliance API
     * activity feed.
     *
     * **Accepted credentials:** an Admin API key with the `read:plugins` or
     * `read:org_audit` scope, or a Compliance Access Key with the
     * `read:compliance_org_data` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaPlugin of client.beta.organization.plugins.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
      const { betas, ...query } = params ?? {};
      return this._client.getAPIList("/v1/organizations/plugins?beta=true", PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
          options?.headers
        ])
      });
    }
    /**
     * Permanently delete a Plugin and every version it holds, exactly as when an
     * administrator deletes it in claude.ai. The Plugin may belong to the organization
     * or to a member, including a member who has since left the organization.
     *
     * An organization-owned Plugin's installation settings go with it; a member-owned
     * Plugin's shares are withdrawn and its owner no longer has it.
     *
     * To take an organization-owned Plugin out of use reversibly, set its
     * organization-wide installation setting to `not_available` instead (and remove or
     * change any group settings, which override it for their members). Only a Plugin
     * in a `manual` marketplace can be deleted here; one synchronized from a
     * repository is removed by removing it from the repository (400).
     *
     * **Accepted credentials:** an Admin API key with the `write:plugins` scope.
     *
     * Every request must include the beta header
     * `anthropic-beta: ce-plugins-2026-09-01`. A request without it returns `404`,
     * exactly as if the endpoint did not exist. The Plugins API is in beta and is
     * available to Claude Enterprise organizations only. It is not available to Claude
     * Platform (Claude Console) organizations, or to organizations with HIPAA
     * readiness enabled.
     *
     * @example
     * ```ts
     * const betaDeletedPlugin =
     *   await client.beta.organization.plugins.delete(
     *     'plugin_id',
     *   );
     * ```
     */
    delete(pluginID, params = {}, options) {
      const { betas } = params ?? {};
      return this._client.delete(path2`/v1/organizations/plugins/${pluginID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          { "anthropic-beta": [...betas ?? [], "ce-plugins-2026-09-01"].toString() },
          options?.headers
        ])
      });
    }
  }
  Plugins3.Versions = Versions2;
  Plugins3.InstallationSettings = InstallationSettings;
  Plugins3.Shares = Shares;
  return Plugins3;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/organization/rbac-groups/members.mjs
var Members = class extends APIResource {
  /**
   * List members of an RBAC Group.
   *
   * The RBAC Groups API is available to Claude Enterprise organizations only.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaRBACGroupMember of client.beta.organization.rbacGroups.members.list(
   *   'rbac_group_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(rbacGroupID, query = {}, options) {
    return this._client.getAPIList(path2`/v1/organizations/rbac_groups/${rbacGroupID}/members?beta=true`, PageCursor, { query, ...options });
  }
  /**
   * Add a User to an RBAC Group. Membership of groups provisioned by an identity
   * provider (source type `"scim"`) cannot be modified via the API while an
   * organization in the tenant uses SCIM provisioning.
   *
   * The RBAC Groups API is available to Claude Enterprise organizations only.
   *
   * @example
   * ```ts
   * const betaRBACGroupMember =
   *   await client.beta.organization.rbacGroups.members.add(
   *     'rbac_group_id',
   *     { user_id: 'user_01WCz1FkmYMm4gnmykNKUu3Q' },
   *   );
   * ```
   */
  add(rbacGroupID, body, options) {
    return this._client.post(path2`/v1/organizations/rbac_groups/${rbacGroupID}/members?beta=true`, {
      body,
      ...options
    });
  }
  /**
   * Remove a User from an RBAC Group. Membership of groups provisioned by an
   * identity provider (source type `"scim"`) cannot be modified via the API while an
   * organization in the tenant uses SCIM provisioning.
   *
   * The RBAC Groups API is available to Claude Enterprise organizations only.
   *
   * @example
   * ```ts
   * const member =
   *   await client.beta.organization.rbacGroups.members.remove(
   *     'user_id',
   *     { rbac_group_id: 'rbac_group_id' },
   *   );
   * ```
   */
  remove(userID, params, options) {
    const { rbac_group_id } = params;
    return this._client.delete(path2`/v1/organizations/rbac_groups/${rbac_group_id}/members/${userID}?beta=true`, options);
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/rbac-groups/rbac-groups.mjs
var RBACGroups = /* @__PURE__ */ (() => {
  class RBACGroups2 extends APIResource {
    constructor() {
      super(...arguments);
      this.members = new Members(this._client);
    }
    /**
     * Create an RBAC Group in the Claude Enterprise tenant. Groups created via the API
     * have source type `"direct"`.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const betaRBACGroup =
     *   await client.beta.organization.rbacGroups.create({
     *     name: 'Engineering',
     *   });
     * ```
     */
    create(body, options) {
      return this._client.post("/v1/organizations/rbac_groups?beta=true", { body, ...options });
    }
    /**
     * Retrieve an RBAC Group by ID.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const betaRBACGroup =
     *   await client.beta.organization.rbacGroups.retrieve(
     *     'rbac_group_id',
     *   );
     * ```
     */
    retrieve(rbacGroupID, options) {
      return this._client.get(path2`/v1/organizations/rbac_groups/${rbacGroupID}?beta=true`, options);
    }
    /**
     * Update an RBAC Group's name. Groups provisioned by an identity provider (source
     * type `"scim"`) cannot be modified via the API while an organization in the
     * tenant uses SCIM provisioning.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const betaRBACGroup =
     *   await client.beta.organization.rbacGroups.update(
     *     'rbac_group_id',
     *   );
     * ```
     */
    update(rbacGroupID, body, options) {
      return this._client.post(path2`/v1/organizations/rbac_groups/${rbacGroupID}?beta=true`, {
        body,
        ...options
      });
    }
    /**
     * List RBAC Groups in the Claude Enterprise tenant.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaRBACGroup of client.beta.organization.rbacGroups.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
      return this._client.getAPIList("/v1/organizations/rbac_groups?beta=true", PageCursor, {
        query,
        ...options
      });
    }
    /**
     * Delete an RBAC Group. Groups provisioned by an identity provider (source type
     * `"scim"`) cannot be deleted via the API while an organization in the tenant uses
     * SCIM provisioning.
     *
     * The RBAC Groups API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const rbacGroup =
     *   await client.beta.organization.rbacGroups.delete(
     *     'rbac_group_id',
     *   );
     * ```
     */
    delete(rbacGroupID, options) {
      return this._client.delete(path2`/v1/organizations/rbac_groups/${rbacGroupID}?beta=true`, options);
    }
  }
  RBACGroups2.Members = Members;
  return RBACGroups2;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/organization/rbac-roles/permissions.mjs
var Permissions = class extends APIResource {
  /**
   * List the permissions an RBAC Role grants.
   *
   * The RBAC Roles API is available to Claude Enterprise organizations only.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaRBACRolePermission of client.beta.organization.rbacRoles.permissions.list(
   *   'rbac_role_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(rbacRoleID, query = {}, options) {
    return this._client.getAPIList(path2`/v1/organizations/rbac_roles/${rbacRoleID}/permissions?beta=true`, PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/rbac-roles/rbac-roles.mjs
var RBACRoles = /* @__PURE__ */ (() => {
  class RBACRoles2 extends APIResource {
    constructor() {
      super(...arguments);
      this.permissions = new Permissions(this._client);
    }
    /**
     * Retrieve an RBAC Role by ID.
     *
     * The RBAC Roles API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * const betaRBACRole =
     *   await client.beta.organization.rbacRoles.retrieve(
     *     'rbac_role_id',
     *   );
     * ```
     */
    retrieve(rbacRoleID, options) {
      return this._client.get(path2`/v1/organizations/rbac_roles/${rbacRoleID}?beta=true`, options);
    }
    /**
     * List RBAC Roles in the organization.
     *
     * The RBAC Roles API is available to Claude Enterprise organizations only.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaRBACRole of client.beta.organization.rbacRoles.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
      return this._client.getAPIList("/v1/organizations/rbac_roles?beta=true", PageCursor, {
        query,
        ...options
      });
    }
  }
  RBACRoles2.Permissions = Permissions;
  return RBACRoles2;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/organization/service-accounts/workspaces.mjs
var Workspaces2 = class extends APIResource {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List the workspaces a service account is a member of.
   *
   * Each entry includes the service account's `workspace_role` in that workspace.
   * Use `limit` and the `next_page` cursor to paginate. When the service account has
   * no explicit default-workspace membership, the implicit (`implicit: true`)
   * membership is returned as the first entry on the first page; with `limit=1` the
   * first page may return up to 2 entries (the implicit entry plus one explicit
   * membership) so a pagination cursor can be derived. Memberships are returned only
   * while the service account is active. Without a `page` cursor, an archived
   * service account returns an empty list. A `page` cursor that does not match an
   * active membership returns a 400 invalid-request error. A cursor stops matching
   * when the membership is removed, the workspace is deleted, or the service account
   * is archived. Restart pagination from the first page to recover.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaServiceAccountWorkspaceMember of client.beta.organization.serviceAccounts.workspaces.list(
   *   'service_account_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(serviceAccountID, params = {}, options) {
    const { betas, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/organizations/service_accounts/${serviceAccountID}/workspaces?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Add a service account to a workspace with the given `workspace_role`.
   *
   * Mirror of `POST /workspaces/{workspace_id}/service_accounts`, addressed from the
   * service-account side; both create the same membership. If the service account is
   * already an explicit member of the workspace, its `workspace_role` is replaced
   * with the value supplied here. Archived workspaces return 400. Archived service
   * accounts cannot be added and are rejected.
   *
   * @example
   * ```ts
   * const betaServiceAccountWorkspaceMember =
   *   await client.beta.organization.serviceAccounts.workspaces.add(
   *     'service_account_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(serviceAccountID, params, options) {
    const { betas, ...body } = params;
    return this._client.post(path2`/v1/organizations/service_accounts/${serviceAccountID}/workspaces?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Remove a service account from a workspace.
   *
   * Mirror of
   * `DELETE /workspaces/{workspace_id}/service_accounts/{service_account_id}`,
   * addressed from the service-account side. Removal is idempotent (returns 200 even
   * if the membership was already removed). A DELETE against the implicit
   * default-workspace membership returns 200 but is a no-op and the membership
   * persists; deleting an explicit default-workspace row reverts to the implicit
   * `workspace_user` membership. Archived workspaces return 400.
   *
   * @example
   * ```ts
   * const workspace =
   *   await client.beta.organization.serviceAccounts.workspaces.remove(
   *     'workspace_id',
   *     { service_account_id: 'service_account_id' },
   *   );
   * ```
   */
  remove(workspaceID, params, options) {
    const { service_account_id, betas } = params;
    return this._client.delete(path2`/v1/organizations/service_accounts/${service_account_id}/workspaces/${workspaceID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/service-accounts/service-accounts.mjs
var ServiceAccounts = /* @__PURE__ */ (() => {
  class ServiceAccounts5 extends APIResource {
    constructor() {
      super(...arguments);
      this.workspaces = new Workspaces2(this._client);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Create a service account.
     *
     * A service account is a named workload identity that federation rules target.
     * `organization_role` is `developer` (default) or `admin`; a rule may only be
     * created or retargeted to grant `org:admin` scope when the target's
     * `organization_role` is `admin`. Creating an `admin`-role service account
     * requires an interactive credential (a user OAuth token or a Console session) — a
     * workload may only create `developer`-role service accounts.
     *
     * @example
     * ```ts
     * const betaServiceAccount =
     *   await client.beta.organization.serviceAccounts.create({
     *     name: 'ci-deploy-bot',
     *   });
     * ```
     */
    create(params, options) {
      const { betas, ...body } = params;
      return this._client.post("/v1/organizations/service_accounts?beta=true", {
        body,
        ...options,
        headers: buildHeaders([
          { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
          options?.headers
        ])
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Retrieve a service account by its ID (`svac_...`).
     *
     * @example
     * ```ts
     * const betaServiceAccount =
     *   await client.beta.organization.serviceAccounts.retrieve(
     *     'service_account_id',
     *   );
     * ```
     */
    retrieve(serviceAccountID, params = {}, options) {
      const { betas } = params ?? {};
      return this._client.get(path2`/v1/organizations/service_accounts/${serviceAccountID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
          options?.headers
        ])
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Update a service account.
     *
     * Only `description` and `organization_role` are mutable; `name` cannot be
     * changed. Archived service accounts cannot be updated; this returns 400. Setting
     * `organization_role` to `admin` (even when unchanged) requires an interactive
     * credential (a user OAuth token or a Console session).
     *
     * @example
     * ```ts
     * const betaServiceAccount =
     *   await client.beta.organization.serviceAccounts.update(
     *     'service_account_id',
     *   );
     * ```
     */
    update(serviceAccountID, params, options) {
      const { betas, ...body } = params;
      return this._client.post(path2`/v1/organizations/service_accounts/${serviceAccountID}?beta=true`, {
        body,
        ...options,
        headers: buildHeaders([
          { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
          options?.headers
        ])
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * List service accounts in the caller's organization.
     *
     * Results are ordered by creation time, newest first. Use `limit` and the
     * `next_page` cursor to paginate; set `include_archived=true` to include archived
     * service accounts.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaServiceAccount of client.beta.organization.serviceAccounts.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
      const { betas, ...query } = params ?? {};
      return this._client.getAPIList("/v1/organizations/service_accounts?beta=true", PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
          options?.headers
        ])
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Archive a service account.
     *
     * Idempotent; re-archiving returns the service account with its original
     * `archived_at`. Rejected with 400 if any live (non-archived) federation rule
     * still targets this service account, same as issuer archival; archive those rules
     * first or change their target to another service account.
     *
     * @example
     * ```ts
     * const betaServiceAccount =
     *   await client.beta.organization.serviceAccounts.archive(
     *     'service_account_id',
     *   );
     * ```
     */
    archive(serviceAccountID, params = {}, options) {
      const { betas } = params ?? {};
      return this._client.post(path2`/v1/organizations/service_accounts/${serviceAccountID}/archive?beta=true`, {
        ...options,
        headers: buildHeaders([
          { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
          options?.headers
        ])
      });
    }
  }
  ServiceAccounts5.Workspaces = Workspaces2;
  return ServiceAccounts5;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/organization/spend-limits/effective.mjs
var Effective = class extends APIResource {
  /**
   * List each member's effective spend limit and period-to-date spend.
   *
   * Returns one row per (member, period) the member resolves a spend limit for, with
   * the `source` scope the spend limit was inherited from. Paginates by member, so a
   * member's periods never split across pages. Listing Claude Console limits is in
   * an early access preview. To request access, contact your Anthropic account team.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaSpendSummary of client.beta.organization.spendLimits.effective.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/spend_limits/effective?beta=true", PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/spend-limits/increase-requests.mjs
var IncreaseRequests = class extends APIResource {
  /**
   * Retrieve a spend limit increase request.
   *
   * While `pending`, the response includes a live `spend_summary` for the requester
   * at the request's period.
   *
   * @example
   * ```ts
   * const betaSpendLimitIncreaseRequest =
   *   await client.beta.organization.spendLimits.increaseRequests.retrieve(
   *     'spend_limit_increase_request_id',
   *   );
   * ```
   */
  retrieve(spendLimitIncreaseRequestID, options) {
    return this._client.get(path2`/v1/organizations/spend_limit_increase_requests/${spendLimitIncreaseRequestID}?beta=true`, options);
  }
  /**
   * List spend limit increase requests, most recent first.
   *
   * Pending requests include a live `spend_summary` for the requester. Requests
   * whose requester is no longer a member are excluded.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaSpendLimitIncreaseRequest of client.beta.organization.spendLimits.increaseRequests.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/spend_limit_increase_requests?beta=true", PageCursor, { query, ...options });
  }
  /**
   * Approve a pending spend limit increase request.
   *
   * Writes a per-user spend limit at `amount` for the requester and transitions the
   * request to `approved`. `period` defaults to the period the member was blocked
   * on. Anthropic emails the requester unless `suppress_notification` is set.
   *
   * @example
   * ```ts
   * const response =
   *   await client.beta.organization.spendLimits.increaseRequests.approve(
   *     'spend_limit_increase_request_id',
   *     { amount: '50000' },
   *   );
   * ```
   */
  approve(spendLimitIncreaseRequestID, body, options) {
    return this._client.post(path2`/v1/organizations/spend_limit_increase_requests/${spendLimitIncreaseRequestID}/approve?beta=true`, { body, ...options });
  }
  /**
   * Deny a pending spend limit increase request.
   *
   * Idempotent on `denied`; denying an already-`approved` request returns 400.
   * Anthropic emails the requester unless `suppress_notification` is set.
   *
   * @example
   * ```ts
   * const betaSpendLimitIncreaseRequest =
   *   await client.beta.organization.spendLimits.increaseRequests.deny(
   *     'spend_limit_increase_request_id',
   *   );
   * ```
   */
  deny(spendLimitIncreaseRequestID, body, options) {
    return this._client.post(path2`/v1/organizations/spend_limit_increase_requests/${spendLimitIncreaseRequestID}/deny?beta=true`, { body, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/spend-limits/spend-limits.mjs
var SpendLimits = /* @__PURE__ */ (() => {
  class SpendLimits2 extends APIResource {
    constructor() {
      super(...arguments);
      this.effective = new Effective(this._client);
      this.increaseRequests = new IncreaseRequests(this._client);
    }
    /**
     * Retrieve a spend limit by ID.
     *
     * @example
     * ```ts
     * const betaSpendLimit =
     *   await client.beta.organization.spendLimits.retrieve(
     *     'spend_limit_id',
     *   );
     * ```
     */
    retrieve(spendLimitID, options) {
      return this._client.get(path2`/v1/organizations/spend_limits/${spendLimitID}?beta=true`, options);
    }
    /**
     * List the organization's spend limits.
     *
     * A Claude Console organization's limits come in an order that is stable across
     * pages. A Claude Enterprise organization's are grouped by scope type, in the
     * order `organization`, `seat_tier`, `rbac_group`, `organization_service`, `user`;
     * within a type they come in a fixed order that is not creation order. Listing
     * Claude Console limits is in an early access preview. To request access, contact
     * your Anthropic account team.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaSpendLimit of client.beta.organization.spendLimits.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
      const { betas, ...query } = params ?? {};
      return this._client.getAPIList("/v1/organizations/spend_limits?beta=true", PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          { "anthropic-beta": [...betas ?? [], "spend-limit-reads-2026-09-26"].toString() },
          options?.headers
        ])
      });
    }
    /**
     * Delete a spend limit.
     *
     * For a Claude Enterprise organization, this deletes a per-user override, and the
     * member falls back to any inherited spend limit at that period. Its seat-tier,
     * group, and organization-level rows cannot be deleted via this endpoint. A Claude
     * Console organization deletes its organization and workspace limits. Deleting
     * them through the API is in an early access preview.
     *
     * @example
     * ```ts
     * const spendLimit =
     *   await client.beta.organization.spendLimits.delete(
     *     'spend_limit_id',
     *   );
     * ```
     */
    delete(spendLimitID, options) {
      return this._client.delete(path2`/v1/organizations/spend_limits/${spendLimitID}?beta=true`, options);
    }
    /**
     * Set a spend limit.
     *
     * Upsert keyed on (scope, period): setting a limit that already exists overwrites
     * it in place. A Claude Enterprise organization sets `user` limits. Its seat-tier,
     * group, and organization-level defaults are configured in claude.ai. A Claude
     * Console organization sets `organization` and `workspace` limits, which are
     * monthly and always carry an amount. Setting those limits is in an early access
     * preview. To request access, contact your Anthropic account team.
     *
     * @example
     * ```ts
     * const betaSpendLimit =
     *   await client.beta.organization.spendLimits.set({
     *     amount: '50000',
     *     scope: {
     *       type: 'user',
     *       user_id: 'user_01WCz1FkmYMm4gnmykNKUu3Q',
     *     },
     *   });
     * ```
     */
    set(params, options) {
      const { betas, ...body } = params;
      return this._client.post("/v1/organizations/spend_limits?beta=true", {
        body,
        ...options,
        headers: buildHeaders([
          { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
          options?.headers
        ])
      });
    }
  }
  SpendLimits2.Effective = Effective;
  SpendLimits2.IncreaseRequests = IncreaseRequests;
  return SpendLimits2;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/organization/workspaces/members.mjs
var Members2 = class extends APIResource {
  /**
   * Get Workspace Member
   *
   * @example
   * ```ts
   * const betaWorkspaceMember =
   *   await client.beta.organization.workspaces.members.retrieve(
   *     'user_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  retrieve(userID, params, options) {
    const { workspace_id } = params;
    return this._client.get(path2`/v1/organizations/workspaces/${workspace_id}/members/${userID}?beta=true`, options);
  }
  /**
   * Update Workspace Member
   *
   * @example
   * ```ts
   * const betaWorkspaceMember =
   *   await client.beta.organization.workspaces.members.update(
   *     'user_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  update(userID, params, options) {
    const { workspace_id, ...body } = params;
    return this._client.post(path2`/v1/organizations/workspaces/${workspace_id}/members/${userID}?beta=true`, {
      body,
      ...options
    });
  }
  /**
   * List Workspace Members
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaWorkspaceMember of client.beta.organization.workspaces.members.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(workspaceID, query = {}, options) {
    return this._client.getAPIList(path2`/v1/organizations/workspaces/${workspaceID}/members?beta=true`, Page, { query, ...options });
  }
  /**
   * Create Workspace Member
   *
   * @example
   * ```ts
   * const betaWorkspaceMember =
   *   await client.beta.organization.workspaces.members.add(
   *     'workspace_id',
   *     {
   *       user_id: 'user_01WCz1FkmYMm4gnmykNKUu3Q',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(workspaceID, body, options) {
    return this._client.post(path2`/v1/organizations/workspaces/${workspaceID}/members?beta=true`, {
      body,
      ...options
    });
  }
  /**
   * Delete Workspace Member
   *
   * @example
   * ```ts
   * const member =
   *   await client.beta.organization.workspaces.members.remove(
   *     'user_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  remove(userID, params, options) {
    const { workspace_id } = params;
    return this._client.delete(path2`/v1/organizations/workspaces/${workspace_id}/members/${userID}?beta=true`, options);
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/workspaces/rate-limits.mjs
var RateLimits2 = class extends APIResource {
  /**
   * List a workspace's rate limits.
   *
   * By default, returns only the groups and limiter types that have a
   * workspace-level override. With `include_inherited=true`, returns every group
   * with organization-level limits the workspace can see, listing for each the
   * values it inherits from the organization as well as its own overrides. Each
   * value's `source` says which it is.
   *
   * When `limit` is omitted, every matching entry is returned in a single page; when
   * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaWorkspaceRateLimit of client.beta.organization.workspaces.rateLimits.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(workspaceID, query = {}, options) {
    return this._client.getAPIList(path2`/v1/organizations/workspaces/${workspaceID}/rate_limits?beta=true`, PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/workspaces/service-accounts.mjs
var ServiceAccounts2 = class extends APIResource {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Retrieve a service account's membership in a workspace.
   *
   * Returns the membership record, including the service account's `workspace_role`
   * in this workspace. Archived workspaces return 400. For the default workspace,
   * returns the implicit (`implicit: true`) membership when no explicit membership
   * exists; an explicitly added membership is returned with its assigned role. An
   * archived service account returns 404.
   *
   * @example
   * ```ts
   * const betaServiceAccountWorkspaceMember =
   *   await client.beta.organization.workspaces.serviceAccounts.retrieve(
   *     'service_account_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  retrieve(serviceAccountID, params, options) {
    const { workspace_id, betas } = params;
    return this._client.get(path2`/v1/organizations/workspaces/${workspace_id}/service_accounts/${serviceAccountID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Change a service account's role in a workspace.
   *
   * The new `workspace_role` replaces the current one. Only explicit memberships can
   * be updated; to set a role on the implicit default-workspace membership, add the
   * service account explicitly with
   * `POST /workspaces/{workspace_id}/service_accounts`. Archived workspaces
   * return 400. Archived service accounts cannot be updated and are rejected.
   *
   * @example
   * ```ts
   * const betaServiceAccountWorkspaceMember =
   *   await client.beta.organization.workspaces.serviceAccounts.update(
   *     'service_account_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  update(serviceAccountID, params, options) {
    const { workspace_id, betas, ...body } = params;
    return this._client.post(path2`/v1/organizations/workspaces/${workspace_id}/service_accounts/${serviceAccountID}?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List the service accounts that are members of a workspace.
   *
   * Each entry includes the service account's `workspace_role`. Use `limit` and the
   * `next_page` cursor to paginate. Archived workspaces return 400; use
   * `GET /service_accounts/{id}/workspaces` to audit memberships of an archived
   * workspace. The implicit default-workspace membership is not included in this
   * list. Memberships of archived service accounts are omitted from the results.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaServiceAccountWorkspaceMember of client.beta.organization.workspaces.serviceAccounts.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(workspaceID, params = {}, options) {
    const { betas, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/organizations/workspaces/${workspaceID}/service_accounts?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Add a service account to a workspace with the given `workspace_role`.
   *
   * The role determines what the service account can do in the workspace and which
   * workspace-scoped permissions it can be granted when authenticating through
   * federation. Every service account is already an implicit `workspace_user` member
   * of the default workspace; adding it explicitly assigns a chosen role. If the
   * service account is already an explicit member of the workspace, its
   * `workspace_role` is replaced with the value supplied here. Archived workspaces
   * return 400. Archived service accounts cannot be added and are rejected.
   *
   * @example
   * ```ts
   * const betaServiceAccountWorkspaceMember =
   *   await client.beta.organization.workspaces.serviceAccounts.add(
   *     'workspace_id',
   *     {
   *       service_account_id: 'service_account_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(workspaceID, params, options) {
    const { betas, ...body } = params;
    return this._client.post(path2`/v1/organizations/workspaces/${workspaceID}/service_accounts?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Remove a service account from a workspace.
   *
   * Removal is idempotent (returns 200 even if the membership was already removed).
   * A DELETE against the implicit default-workspace membership returns 200 but is a
   * no-op and the membership persists; deleting an explicit default-workspace row
   * reverts to the implicit `workspace_user` membership. Archived workspaces
   * return 400.
   *
   * @example
   * ```ts
   * const serviceAccount =
   *   await client.beta.organization.workspaces.serviceAccounts.remove(
   *     'service_account_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  remove(serviceAccountID, params, options) {
    const { workspace_id, betas } = params;
    return this._client.delete(path2`/v1/organizations/workspaces/${workspace_id}/service_accounts/${serviceAccountID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/organization/workspaces/workspaces.mjs
var Workspaces3 = /* @__PURE__ */ (() => {
  class Workspaces7 extends APIResource {
    constructor() {
      super(...arguments);
      this.rateLimits = new RateLimits2(this._client);
      this.members = new Members2(this._client);
      this.serviceAccounts = new ServiceAccounts2(this._client);
    }
    /**
     * Create Workspace
     *
     * @example
     * ```ts
     * const betaWorkspace =
     *   await client.beta.organization.workspaces.create({
     *     name: 'x',
     *   });
     * ```
     */
    create(params, options) {
      const { betas, ...body } = params;
      return this._client.post("/v1/organizations/workspaces?beta=true", {
        body,
        ...options,
        headers: buildHeaders([
          { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
          options?.headers
        ])
      });
    }
    /**
     * Get Workspace
     *
     * @example
     * ```ts
     * const betaWorkspace =
     *   await client.beta.organization.workspaces.retrieve(
     *     'workspace_id',
     *   );
     * ```
     */
    retrieve(workspaceID, options) {
      return this._client.get(path2`/v1/organizations/workspaces/${workspaceID}?beta=true`, options);
    }
    /**
     * Update Workspace
     *
     * @example
     * ```ts
     * const betaWorkspace =
     *   await client.beta.organization.workspaces.update(
     *     'workspace_id',
     *   );
     * ```
     */
    update(workspaceID, body, options) {
      return this._client.post(path2`/v1/organizations/workspaces/${workspaceID}?beta=true`, {
        body,
        ...options
      });
    }
    /**
     * List Workspaces
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaWorkspace of client.beta.organization.workspaces.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
      return this._client.getAPIList("/v1/organizations/workspaces?beta=true", Page, {
        query,
        ...options
      });
    }
    /**
     * Archive Workspace
     *
     * @example
     * ```ts
     * const betaWorkspace =
     *   await client.beta.organization.workspaces.archive(
     *     'workspace_id',
     *   );
     * ```
     */
    archive(workspaceID, options) {
      return this._client.post(path2`/v1/organizations/workspaces/${workspaceID}/archive?beta=true`, options);
    }
  }
  Workspaces7.RateLimits = RateLimits2;
  Workspaces7.Members = Members2;
  Workspaces7.ServiceAccounts = ServiceAccounts2;
  return Workspaces7;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/organization/organization.mjs
var Organization = /* @__PURE__ */ (() => {
  class Organization3 extends APIResource {
    constructor() {
      super(...arguments);
      this.apiKeys = new APIKeys(this._client);
      this.externalKeys = new ExternalKeys(this._client);
      this.federation = new Federation(this._client);
      this.invites = new Invites(this._client);
      this.serviceAccounts = new ServiceAccounts(this._client);
      this.users = new Users2(this._client);
      this.workspaces = new Workspaces3(this._client);
      this.rateLimits = new RateLimits(this._client);
      this.complianceSettings = new ComplianceSettings(this._client);
      this.analytics = new Analytics(this._client);
      this.spendLimits = new SpendLimits(this._client);
      this.rbacGroups = new RBACGroups(this._client);
      this.rbacRoles = new RBACRoles(this._client);
      this.plugins = new Plugins2(this._client);
      this.pluginMarketplaces = new PluginMarketplaces(this._client);
    }
    /**
     * Retrieve information about the organization associated with the authenticated
     * API key.
     *
     * @example
     * ```ts
     * const betaOrganization =
     *   await client.beta.organization.retrieve();
     * ```
     */
    retrieve(options) {
      return this._client.get("/v1/organizations/me?beta=true", options);
    }
  }
  Organization3.APIKeys = APIKeys;
  Organization3.ExternalKeys = ExternalKeys;
  Organization3.Federation = Federation;
  Organization3.Invites = Invites;
  Organization3.ServiceAccounts = ServiceAccounts;
  Organization3.Users = Users2;
  Organization3.Workspaces = Workspaces3;
  Organization3.RateLimits = RateLimits;
  Organization3.ComplianceSettings = ComplianceSettings;
  Organization3.Analytics = Analytics;
  Organization3.SpendLimits = SpendLimits;
  Organization3.RBACGroups = RBACGroups;
  Organization3.RBACRoles = RBACRoles;
  Organization3.Plugins = Plugins2;
  Organization3.PluginMarketplaces = PluginMarketplaces;
  return Organization3;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/events.mjs
var Events = /* @__PURE__ */ (() => {
  class Events3 extends APIResource {
    /**
     * List Events
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsSessionEvent of client.beta.sessions.events.list(
     *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(sessionID, params = {}, options) {
      const { betas, workspace_id, ...query } = params ?? {};
      return this._client.getAPIList(path2`/v1/sessions/${sessionID}/events?beta=true`, PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Send Events
     *
     * @example
     * ```ts
     * const betaManagedAgentsSendSessionEvents =
     *   await client.beta.sessions.events.send(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *     {
     *       events: [
     *         {
     *           content: [
     *             {
     *               text: 'Where is my order #1234?',
     *               type: 'text',
     *             },
     *           ],
     *           type: 'user.message',
     *         },
     *       ],
     *     },
     *   );
     * ```
     */
    send(sessionID, params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post(path2`/v1/sessions/${sessionID}/events?beta=true`, {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Stream Events
     *
     * @example
     * ```ts
     * const betaManagedAgentsStreamSessionEvents =
     *   await client.beta.sessions.events.stream(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *   );
     * ```
     */
    stream(sessionID, params = {}, options) {
      const { betas, workspace_id, ...query } = params ?? {};
      return this._client.get(path2`/v1/sessions/${sessionID}/events/stream?beta=true`, {
        query,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ]),
        stream: true
      });
    }
    /**
     * Attach to a session and dispatch every incoming `agent.tool_use` and
     * `agent.custom_tool_use` event to a local tool registry, sending the matching
     * result back (`user.tool_result` / `user.custom_tool_result`). The
     * sessions-side counterpart to `client.beta.messages.toolRunner`: yields one
     * entry per completed tool call so callers can observe each dispatch (and
     * `break` to abort cleanly).
     *
     * @example
     * ```ts
     * import { betaAgentToolset20260401 } from '@anthropic-ai/sdk/tools/agent-toolset/node';
     *
     * for await (const call of client.beta.sessions.events.toolRunner(work.data.id, {
     *   tools: [...betaAgentToolset20260401({ workdir }), myTool],
     * })) {
     *   console.log(`${call.name} -> ${call.isError ? 'error' : 'ok'}`);
     * }
     * ```
     */
    toolRunner(sessionID, opts) {
      return new SessionToolRunner(sessionID, { ...opts, client: this._client });
    }
  }
  Events3.SessionToolRunner = SessionToolRunner;
  return Events3;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/resources.mjs
var Resources = class extends APIResource {
  /**
   * Get Session Resource
   *
   * @example
   * ```ts
   * const resource =
   *   await client.beta.sessions.resources.retrieve(
   *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
   *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
   *   );
   * ```
   */
  retrieve(resourceID, params, options) {
    const { session_id, betas, workspace_id } = params;
    return this._client.get(path2`/v1/sessions/${session_id}/resources/${resourceID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Update Session Resource
   *
   * @example
   * ```ts
   * const resource =
   *   await client.beta.sessions.resources.update(
   *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
   *     {
   *       session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7',
   *       authorization_token: 'ghp_exampletoken',
   *     },
   *   );
   * ```
   */
  update(resourceID, params, options) {
    const { session_id, betas, workspace_id, ...body } = params;
    return this._client.post(path2`/v1/sessions/${session_id}/resources/${resourceID}?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * List Session Resources
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsSessionResource of client.beta.sessions.resources.list(
   *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(sessionID, params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/sessions/${sessionID}/resources?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Delete Session Resource
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeleteSessionResource =
   *   await client.beta.sessions.resources.delete(
   *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
   *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
   *   );
   * ```
   */
  delete(resourceID, params, options) {
    const { session_id, betas, workspace_id } = params;
    return this._client.delete(path2`/v1/sessions/${session_id}/resources/${resourceID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Add Session Resource
   *
   * @example
   * ```ts
   * const betaManagedAgentsFileResource =
   *   await client.beta.sessions.resources.add(
   *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
   *     {
   *       file_id: 'file_011CNha8iCJcU1wXNR6q4V8w',
   *       type: 'file',
   *     },
   *   );
   * ```
   */
  add(sessionID, params, options) {
    const { betas, workspace_id, ...body } = params;
    return this._client.post(path2`/v1/sessions/${sessionID}/resources?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/threads/events.mjs
var Events2 = class extends APIResource {
  /**
   * List Session Thread Events
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsSessionEvent of client.beta.sessions.threads.events.list(
   *   'sthr_011CZkZVWa6oJjw1rgXZpnBt',
   *   { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
   * )) {
   *   // ...
   * }
   * ```
   */
  list(threadID, params, options) {
    const { session_id, betas, workspace_id, ...query } = params;
    return this._client.getAPIList(path2`/v1/sessions/${session_id}/threads/${threadID}/events?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Stream Session Thread Events
   *
   * @example
   * ```ts
   * const betaManagedAgentsStreamSessionThreadEvents =
   *   await client.beta.sessions.threads.events.stream(
   *     'sthr_011CZkZVWa6oJjw1rgXZpnBt',
   *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
   *   );
   * ```
   */
  stream(threadID, params, options) {
    const { session_id, betas, workspace_id, ...query } = params;
    return this._client.get(path2`/v1/sessions/${session_id}/threads/${threadID}/stream?beta=true`, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ]),
      stream: true
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/threads/threads.mjs
var Threads = /* @__PURE__ */ (() => {
  class Threads2 extends APIResource {
    constructor() {
      super(...arguments);
      this.events = new Events2(this._client);
    }
    /**
     * Get Session Thread
     *
     * @example
     * ```ts
     * const betaManagedAgentsSessionThread =
     *   await client.beta.sessions.threads.retrieve(
     *     'sthr_011CZkZVWa6oJjw1rgXZpnBt',
     *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
     *   );
     * ```
     */
    retrieve(threadID, params, options) {
      const { session_id, betas, workspace_id } = params;
      return this._client.get(path2`/v1/sessions/${session_id}/threads/${threadID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * List Session Threads
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsSessionThread of client.beta.sessions.threads.list(
     *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(sessionID, params = {}, options) {
      const { betas, workspace_id, ...query } = params ?? {};
      return this._client.getAPIList(path2`/v1/sessions/${sessionID}/threads?beta=true`, PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Archive Session Thread
     *
     * @example
     * ```ts
     * const betaManagedAgentsSessionThread =
     *   await client.beta.sessions.threads.archive(
     *     'sthr_011CZkZVWa6oJjw1rgXZpnBt',
     *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
     *   );
     * ```
     */
    archive(threadID, params, options) {
      const { session_id, betas, workspace_id } = params;
      return this._client.post(path2`/v1/sessions/${session_id}/threads/${threadID}/archive?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
  }
  Threads2.Events = Events2;
  return Threads2;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/sessions.mjs
var Sessions = /* @__PURE__ */ (() => {
  class Sessions2 extends APIResource {
    constructor() {
      super(...arguments);
      this.events = new Events(this._client);
      this.resources = new Resources(this._client);
      this.threads = new Threads(this._client);
    }
    /**
     * Create Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsSession =
     *   await client.beta.sessions.create({
     *     agent: 'agent_011CZkYpogX7uDKUyvBTophP',
     *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
     *     initial_events: [
     *       {
     *         type: 'user.message',
     *         content: [
     *           {
     *             type: 'text',
     *             text: 'Where is my order #1234?',
     *           },
     *         ],
     *       },
     *     ],
     *   });
     * ```
     */
    create(params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post("/v1/sessions?beta=true", {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Get Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsSession =
     *   await client.beta.sessions.retrieve(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *   );
     * ```
     */
    retrieve(sessionID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.get(path2`/v1/sessions/${sessionID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Update Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsSession =
     *   await client.beta.sessions.update(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *   );
     * ```
     */
    update(sessionID, params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post(path2`/v1/sessions/${sessionID}?beta=true`, {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * List Sessions
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsSession of client.beta.sessions.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
      const { betas, workspace_id, ...query } = params ?? {};
      return this._client.getAPIList("/v1/sessions?beta=true", BidirectionalPageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Delete Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeletedSession =
     *   await client.beta.sessions.delete(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *   );
     * ```
     */
    delete(sessionID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.delete(path2`/v1/sessions/${sessionID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Archive Session
     *
     * @example
     * ```ts
     * const betaManagedAgentsSession =
     *   await client.beta.sessions.archive(
     *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
     *   );
     * ```
     */
    archive(sessionID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.post(path2`/v1/sessions/${sessionID}/archive?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
  }
  Sessions2.Events = Events;
  Sessions2.Resources = Resources;
  Sessions2.Threads = Threads;
  return Sessions2;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/skills/versions.mjs
var Versions3 = class extends APIResource {
  /**
   * Create Skill Version
   *
   * @example
   * ```ts
   * const betaSkillVersion =
   *   await client.beta.skills.versions.create('skill_id', {
   *     files: [fs.createReadStream('path/to/file')],
   *   });
   * ```
   */
  create(skillID, params, options) {
    const { betas, workspace_id, ...body } = params;
    return this._client.post(path2`/v1/skills/${skillID}/versions?beta=true`, multipartFormRequestOptions({
      body,
      ...options,
      headers: buildHeaders([
        {
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    }, this._client, false));
  }
  /**
   * Get Skill Version
   *
   * @example
   * ```ts
   * const betaSkillVersion =
   *   await client.beta.skills.versions.retrieve('version', {
   *     skill_id: 'skill_id',
   *   });
   * ```
   */
  retrieve(version, params, options) {
    const { skill_id, betas, workspace_id } = params;
    return this._client.get(path2`/v1/skills/${skill_id}/versions/${version}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * List Skill Versions
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaSkillVersion of client.beta.skills.versions.list(
   *   'skill_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(skillID, params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/skills/${skillID}/versions?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        {
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Delete Skill Version
   *
   * @example
   * ```ts
   * const betaDeletedSkillVersion =
   *   await client.beta.skills.versions.delete('version', {
   *     skill_id: 'skill_id',
   *   });
   * ```
   */
  delete(version, params, options) {
    const { skill_id, betas, workspace_id } = params;
    return this._client.delete(path2`/v1/skills/${skill_id}/versions/${version}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Download a skill version's content as a zip archive.
   *
   * @example
   * ```ts
   * const response = await client.beta.skills.versions.download(
   *   'version',
   *   { skill_id: 'skill_id' },
   * );
   *
   * const content = await response.blob();
   * console.log(content);
   * ```
   */
  download(version, params, options) {
    const { skill_id, betas, workspace_id } = params;
    return this._client.get(path2`/v1/skills/${skill_id}/versions/${version}/content?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          Accept: "application/binary",
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ]),
      __binaryResponse: true
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/skills/skills.mjs
var Skills2 = /* @__PURE__ */ (() => {
  class Skills4 extends APIResource {
    constructor() {
      super(...arguments);
      this.versions = new Versions3(this._client);
    }
    /**
     * Create Skill
     *
     * @example
     * ```ts
     * const betaSkill = await client.beta.skills.create({
     *   files: [fs.createReadStream('path/to/file')],
     * });
     * ```
     */
    create(params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post("/v1/skills?beta=true", multipartFormRequestOptions({
        body,
        ...options,
        headers: buildHeaders([
          {
            ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      }, this._client, false));
    }
    /**
     * Get Skill
     *
     * @example
     * ```ts
     * const betaSkill = await client.beta.skills.retrieve(
     *   'skill_id',
     * );
     * ```
     */
    retrieve(skillID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.get(path2`/v1/skills/${skillID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * List Skills
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaSkill of client.beta.skills.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
      const { betas, workspace_id, ...query } = params ?? {};
      return this._client.getAPIList("/v1/skills?beta=true", PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          {
            ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Delete Skill
     *
     * @example
     * ```ts
     * const betaDeletedSkill = await client.beta.skills.delete(
     *   'skill_id',
     * );
     * ```
     */
    delete(skillID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.delete(path2`/v1/skills/${skillID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
  }
  Skills4.Versions = Versions3;
  return Skills4;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/tunnels/certificates.mjs
var Certificates = class extends APIResource {
  /**
   * The Tunnels API is in research preview. It requires the
   * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
   * deprecation period. It supersedes the Admin API endpoints at
   * `/v1/organizations/tunnels`, which remain available during a migration window.
   *
   * Registers a public CA certificate on a tunnel. Anthropic verifies the gateway's
   * server certificate against this CA when it terminates the inner TLS session. A
   * tunnel holds at most two non-archived certificates.
   *
   * @example
   * ```ts
   * const betaTunnelCertificate =
   *   await client.beta.tunnels.certificates.create(
   *     'tunnel_id',
   *     { ca_certificate_pem: 'ca_certificate_pem' },
   *   );
   * ```
   */
  create(tunnelID, params, options) {
    const { betas, workspace_id, ...body } = params;
    return this._client.post(path2`/v1/tunnels/${tunnelID}/certificates?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * The Tunnels API is in research preview. It requires the
   * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
   * deprecation period. It supersedes the Admin API endpoints at
   * `/v1/organizations/tunnels`, which remain available during a migration window.
   *
   * Fetches a tunnel certificate by ID.
   *
   * @example
   * ```ts
   * const betaTunnelCertificate =
   *   await client.beta.tunnels.certificates.retrieve(
   *     'certificate_id',
   *     { tunnel_id: 'tunnel_id' },
   *   );
   * ```
   */
  retrieve(certificateID, params, options) {
    const { tunnel_id, betas, workspace_id } = params;
    return this._client.get(path2`/v1/tunnels/${tunnel_id}/certificates/${certificateID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * The Tunnels API is in research preview. It requires the
   * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
   * deprecation period. It supersedes the Admin API endpoints at
   * `/v1/organizations/tunnels`, which remain available during a migration window.
   *
   * Lists the certificates registered on a tunnel. Archived certificates are
   * excluded unless include_archived is set.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaTunnelCertificate of client.beta.tunnels.certificates.list(
   *   'tunnel_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(tunnelID, params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/tunnels/${tunnelID}/certificates?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * The Tunnels API is in research preview. It requires the
   * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
   * deprecation period. It supersedes the Admin API endpoints at
   * `/v1/organizations/tunnels`, which remain available during a migration window.
   *
   * Archives a tunnel certificate, removing it from the set Anthropic trusts for the
   * tunnel. The certificate record is retained. Archiving the last non-archived
   * certificate is permitted; the tunnel rejects MCP traffic until a new certificate
   * is added.
   *
   * @example
   * ```ts
   * const betaTunnelCertificate =
   *   await client.beta.tunnels.certificates.archive(
   *     'certificate_id',
   *     { tunnel_id: 'tunnel_id' },
   *   );
   * ```
   */
  archive(certificateID, params, options) {
    const { tunnel_id, betas, workspace_id } = params;
    return this._client.post(path2`/v1/tunnels/${tunnel_id}/certificates/${certificateID}/archive?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/tunnels/tunnels.mjs
var Tunnels = /* @__PURE__ */ (() => {
  class Tunnels2 extends APIResource {
    constructor() {
      super(...arguments);
      this.certificates = new Certificates(this._client);
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Creates a tunnel. Creation allocates a fresh hostname and provisions the tunnel;
     * it is not idempotent. The new tunnel rejects MCP traffic until at least one CA
     * certificate is added.
     *
     * @example
     * ```ts
     * const betaTunnel = await client.beta.tunnels.create();
     * ```
     */
    create(params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post("/v1/tunnels?beta=true", {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Fetches a tunnel by ID.
     *
     * @example
     * ```ts
     * const betaTunnel = await client.beta.tunnels.retrieve(
     *   'tunnel_id',
     * );
     * ```
     */
    retrieve(tunnelID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.get(path2`/v1/tunnels/${tunnelID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Lists tunnels. Results are ordered by creation time, newest first; archived
     * tunnels are excluded unless include_archived is set.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaTunnel of client.beta.tunnels.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
      const { betas, workspace_id, ...query } = params ?? {};
      return this._client.getAPIList("/v1/tunnels?beta=true", PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Archives a tunnel. Archival is irreversible: every non-archived certificate on
     * the tunnel is archived in the same operation, the hostname is retired and never
     * re-allocated, and the tunnel token is invalidated. Retrying against an
     * already-archived tunnel returns the existing record unchanged.
     *
     * @example
     * ```ts
     * const betaTunnel = await client.beta.tunnels.archive(
     *   'tunnel_id',
     * );
     * ```
     */
    archive(tunnelID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.post(path2`/v1/tunnels/${tunnelID}/archive?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Reveals a tunnel's connector token. The value is fetched live on each call;
     * Anthropic does not store it. Repeated calls return the same value until the
     * token is rotated. Exposed as POST so the token does not appear in intermediary
     * access logs.
     *
     * @example
     * ```ts
     * const betaTunnelToken =
     *   await client.beta.tunnels.revealToken('tunnel_id');
     * ```
     */
    revealToken(tunnelID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.post(path2`/v1/tunnels/${tunnelID}/reveal_token?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * The Tunnels API is in research preview. It requires the
     * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
     * deprecation period. It supersedes the Admin API endpoints at
     * `/v1/organizations/tunnels`, which remain available during a migration window.
     *
     * Rotates a tunnel's connector token. Rotation invalidates the current token for
     * new connections and returns a fresh value; established connections are not
     * severed. A connector restarted after rotation must use the new value.
     *
     * @example
     * ```ts
     * const betaTunnelToken =
     *   await client.beta.tunnels.rotateToken('tunnel_id');
     * ```
     */
    rotateToken(tunnelID, params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post(path2`/v1/tunnels/${tunnelID}/rotate_token?beta=true`, {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
  }
  Tunnels2.Certificates = Certificates;
  return Tunnels2;
})();

// node_modules/@anthropic-ai/sdk/resources/beta/vaults/credentials.mjs
var Credentials = class extends APIResource {
  /**
   * Create Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredential =
   *   await client.beta.vaults.credentials.create(
   *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
   *     {
   *       auth: {
   *         token: 'bearer_exampletoken',
   *         mcp_server_url:
   *           'https://example-server.modelcontextprotocol.io/sse',
   *         type: 'static_bearer',
   *       },
   *     },
   *   );
   * ```
   */
  create(vaultID, params, options) {
    const { betas, workspace_id, ...body } = params;
    return this._client.post(path2`/v1/vaults/${vaultID}/credentials?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Get Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredential =
   *   await client.beta.vaults.credentials.retrieve(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  retrieve(credentialID, params, options) {
    const { vault_id, betas, workspace_id } = params;
    return this._client.get(path2`/v1/vaults/${vault_id}/credentials/${credentialID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Update Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredential =
   *   await client.beta.vaults.credentials.update(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  update(credentialID, params, options) {
    const { vault_id, betas, workspace_id, ...body } = params;
    return this._client.post(path2`/v1/vaults/${vault_id}/credentials/${credentialID}?beta=true`, {
      body,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * List Credentials
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const betaManagedAgentsCredential of client.beta.vaults.credentials.list(
   *   'vlt_011CZkZDLs7fYzm1hXNPeRjv',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(vaultID, params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/vaults/${vaultID}/credentials?beta=true`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Delete Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsDeletedCredential =
   *   await client.beta.vaults.credentials.delete(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  delete(credentialID, params, options) {
    const { vault_id, betas, workspace_id } = params;
    return this._client.delete(path2`/v1/vaults/${vault_id}/credentials/${credentialID}?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Archive Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredential =
   *   await client.beta.vaults.credentials.archive(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  archive(credentialID, params, options) {
    const { vault_id, betas, workspace_id } = params;
    return this._client.post(path2`/v1/vaults/${vault_id}/credentials/${credentialID}/archive?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * Validate Credential
   *
   * @example
   * ```ts
   * const betaManagedAgentsCredentialValidation =
   *   await client.beta.vaults.credentials.mcpOAuthValidate(
   *     'vcrd_011CZkZEMt8gZan2iYPQfSkw',
   *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
   *   );
   * ```
   */
  mcpOAuthValidate(credentialID, params, options) {
    const { vault_id, betas, workspace_id } = params;
    return this._client.post(path2`/v1/vaults/${vault_id}/credentials/${credentialID}/mcp_oauth_validate?beta=true`, {
      ...options,
      headers: buildHeaders([
        {
          "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/beta/vaults/vaults.mjs
var Vaults = /* @__PURE__ */ (() => {
  class Vaults2 extends APIResource {
    constructor() {
      super(...arguments);
      this.credentials = new Credentials(this._client);
    }
    /**
     * Create Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.create({
     *     display_name: 'Example vault',
     *   });
     * ```
     */
    create(params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post("/v1/vaults?beta=true", {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Get Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.retrieve(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    retrieve(vaultID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.get(path2`/v1/vaults/${vaultID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Update Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.update(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    update(vaultID, params, options) {
      const { betas, workspace_id, ...body } = params;
      return this._client.post(path2`/v1/vaults/${vaultID}?beta=true`, {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * List Vaults
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsVault of client.beta.vaults.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
      const { betas, workspace_id, ...query } = params ?? {};
      return this._client.getAPIList("/v1/vaults?beta=true", PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Delete Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeletedVault =
     *   await client.beta.vaults.delete(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    delete(vaultID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.delete(path2`/v1/vaults/${vaultID}?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    /**
     * Archive Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.archive(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    archive(vaultID, params = {}, options) {
      const { betas, workspace_id } = params ?? {};
      return this._client.post(path2`/v1/vaults/${vaultID}/archive?beta=true`, {
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
  }
  Vaults2.Credentials = Credentials;
  return Vaults2;
})();

// node_modules/@anthropic-ai/sdk/lib/internal/BetaToolRunnerStream.mjs
var _BetaToolRunnerStream_instances;
var _BetaToolRunnerStream_onToolCall;
var _BetaToolRunnerStream_emitted;
var _BetaToolRunnerStream_readers;
var _BetaToolRunnerStream_toolCalls;
var _BetaToolRunnerStream_closed;
var _BetaToolRunnerStream_ready;
var _BetaToolRunnerStream_fallback;
var _BetaToolRunnerStream_track;
var _BetaToolRunnerStream_release;
var _BetaToolRunnerStream_removeReader;
var BetaToolRunnerStream = /* @__PURE__ */ (() => {
  class BetaToolRunnerStream2 extends BetaMessageStream {
    constructor(params, onToolCall) {
      super(params);
      _BetaToolRunnerStream_instances.add(this);
      _BetaToolRunnerStream_onToolCall.set(this, void 0);
      _BetaToolRunnerStream_emitted.set(this, 0);
      _BetaToolRunnerStream_readers.set(this, []);
      _BetaToolRunnerStream_toolCalls.set(this, []);
      _BetaToolRunnerStream_closed.set(this, void 0);
      _BetaToolRunnerStream_ready.set(this, []);
      _BetaToolRunnerStream_fallback.set(this, false);
      __classPrivateFieldSet(this, _BetaToolRunnerStream_onToolCall, onToolCall, "f");
    }
    /** The `tool_use` blocks that have finished streaming, in the model's order */
    get toolCalls() {
      return __classPrivateFieldGet(this, _BetaToolRunnerStream_toolCalls, "f");
    }
    /** Sends the request as `client.beta.messages.stream()` does. */
    static start(messages, params, options, onToolCall) {
      const stream2 = new BetaToolRunnerStream2({ ...params, stream: true }, onToolCall);
      for (const message of params.messages) {
        stream2._addMessageParam(message);
      }
      stream2._run(() => stream2._createMessage(messages, { ...params, stream: true }, { ...options, headers: { ...options?.headers, [STAINLESS_HELPER_METHOD_HEADER]: "stream" } }));
      return stream2;
    }
    _emit(event, ...args) {
      var _a2;
      if (event !== "streamEvent" || this.ended) {
        super._emit(event, ...args);
        return;
      }
      __classPrivateFieldSet(this, _BetaToolRunnerStream_emitted, (_a2 = __classPrivateFieldGet(this, _BetaToolRunnerStream_emitted, "f"), _a2++, _a2), "f");
      const [streamEvent, snapshot] = args;
      const block = streamEvent.type === "content_block_stop" ? snapshot.content[streamEvent.index] : void 0;
      const closed = block?.type === "tool_use" ? block : void 0;
      if (closed) {
        __classPrivateFieldGet(this, _BetaToolRunnerStream_toolCalls, "f").push(closed);
      }
      super._emit(event, ...args);
      __classPrivateFieldGet(this, _BetaToolRunnerStream_instances, "m", _BetaToolRunnerStream_track).call(this, streamEvent, closed);
      __classPrivateFieldGet(this, _BetaToolRunnerStream_instances, "m", _BetaToolRunnerStream_release).call(this);
    }
    [(_BetaToolRunnerStream_onToolCall = /* @__PURE__ */ new WeakMap(), _BetaToolRunnerStream_emitted = /* @__PURE__ */ new WeakMap(), _BetaToolRunnerStream_readers = /* @__PURE__ */ new WeakMap(), _BetaToolRunnerStream_toolCalls = /* @__PURE__ */ new WeakMap(), _BetaToolRunnerStream_closed = /* @__PURE__ */ new WeakMap(), _BetaToolRunnerStream_ready = /* @__PURE__ */ new WeakMap(), _BetaToolRunnerStream_fallback = /* @__PURE__ */ new WeakMap(), _BetaToolRunnerStream_instances = /* @__PURE__ */ new WeakSet(), Symbol.asyncIterator)]() {
      const iterator = super[Symbol.asyncIterator]();
      const reader = { handled: __classPrivateFieldGet(this, _BetaToolRunnerStream_emitted, "f") };
      __classPrivateFieldGet(this, _BetaToolRunnerStream_readers, "f").push(reader);
      let holdsEvent = false;
      return {
        next: async () => {
          if (holdsEvent) {
            holdsEvent = false;
            reader.handled++;
            __classPrivateFieldGet(this, _BetaToolRunnerStream_instances, "m", _BetaToolRunnerStream_release).call(this);
          }
          try {
            const result = await iterator.next();
            holdsEvent = !result.done;
            if (result.done) {
              __classPrivateFieldGet(this, _BetaToolRunnerStream_instances, "m", _BetaToolRunnerStream_removeReader).call(this, reader);
            }
            return result;
          } catch (error) {
            __classPrivateFieldGet(this, _BetaToolRunnerStream_instances, "m", _BetaToolRunnerStream_removeReader).call(this, reader);
            throw error;
          }
        },
        return: async () => {
          const result = iterator.return?.();
          __classPrivateFieldGet(this, _BetaToolRunnerStream_instances, "m", _BetaToolRunnerStream_removeReader).call(this, reader);
          return await result ?? { value: void 0, done: true };
        }
      };
    }
  }
  _BetaToolRunnerStream_track = function _BetaToolRunnerStream_track2(event, closed) {
    if (__classPrivateFieldGet(this, _BetaToolRunnerStream_fallback, "f")) {
      return;
    }
    if (event.type === "content_block_start" && event.content_block.type === "fallback") {
      __classPrivateFieldSet(this, _BetaToolRunnerStream_fallback, true, "f");
      __classPrivateFieldSet(this, _BetaToolRunnerStream_closed, void 0, "f");
      return;
    }
    const movedOn = event.type === "content_block_start" || event.type === "message_delta" && event.delta.stop_reason === "tool_use";
    if (__classPrivateFieldGet(this, _BetaToolRunnerStream_closed, "f") && movedOn) {
      __classPrivateFieldGet(this, _BetaToolRunnerStream_ready, "f").push({ toolUse: __classPrivateFieldGet(this, _BetaToolRunnerStream_closed, "f"), event: __classPrivateFieldGet(this, _BetaToolRunnerStream_emitted, "f") });
      __classPrivateFieldSet(this, _BetaToolRunnerStream_closed, void 0, "f");
    }
    if (closed) {
      __classPrivateFieldSet(this, _BetaToolRunnerStream_closed, closed, "f");
    }
  }, _BetaToolRunnerStream_release = function _BetaToolRunnerStream_release2() {
    if (this.errored || this.controller.signal.aborted) {
      return;
    }
    const handled = Math.min(__classPrivateFieldGet(this, _BetaToolRunnerStream_emitted, "f"), ...__classPrivateFieldGet(this, _BetaToolRunnerStream_readers, "f").map((reader) => reader.handled));
    while (__classPrivateFieldGet(this, _BetaToolRunnerStream_ready, "f")[0] && __classPrivateFieldGet(this, _BetaToolRunnerStream_ready, "f")[0].event <= handled) {
      __classPrivateFieldGet(this, _BetaToolRunnerStream_onToolCall, "f").call(this, __classPrivateFieldGet(this, _BetaToolRunnerStream_ready, "f").shift().toolUse);
    }
  }, _BetaToolRunnerStream_removeReader = function _BetaToolRunnerStream_removeReader2(reader) {
    const index = __classPrivateFieldGet(this, _BetaToolRunnerStream_readers, "f").indexOf(reader);
    if (index >= 0) {
      __classPrivateFieldGet(this, _BetaToolRunnerStream_readers, "f").splice(index, 1);
      __classPrivateFieldGet(this, _BetaToolRunnerStream_instances, "m", _BetaToolRunnerStream_release).call(this);
    }
  };
  return BetaToolRunnerStream2;
})();

// node_modules/@anthropic-ai/sdk/internal/utils/promise.mjs
function promiseWithResolvers() {
  let resolve;
  let reject;
  const promise = new Promise((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

// node_modules/@anthropic-ai/sdk/lib/tools/BetaToolRunner.mjs
var _BetaToolRunner_instances;
var _BetaToolRunner_consumed;
var _BetaToolRunner_mutated;
var _BetaToolRunner_state;
var _BetaToolRunner_options;
var _BetaToolRunner_message;
var _BetaToolRunner_stream;
var _BetaToolRunner_toolResponse;
var _BetaToolRunner_completion;
var _BetaToolRunner_iterationCount;
var _BetaToolRunner_compaction;
var _BetaToolRunner_calls;
var _BetaToolRunner_lastStopReason;
var _BetaToolRunner_toolOverrides;
var _BetaToolRunner_pendingToolChanges;
var _BetaToolRunner_send;
var _BetaToolRunner_streamThatStartsTools;
var _BetaToolRunner_startedCallsSettled;
var _BetaToolRunner_compact;
var _BetaToolRunner_runnableTools;
var _BetaToolRunner_availableToolNames;
var _BetaToolRunner_recordRemovalsFromHistory;
var _BetaToolRunner_compactAfterFinalTurn;
var _BetaToolRunner_generateToolResponse;
var _BetaToolRunner_toolsetFamilies;
var _BetaToolRunner_flushPendingToolChanges;
var _BetaToolRunner_pendingToolChangesMessage;
var USE_A_NEW_RUNNER = "a tool runner's toolsets come only from its tools param; change them with setMessagesParams(), or build a new runner";
var REMOVE_WITH_A_NEW_RUNNER = "a tool runner's toolsets come only from its tools param; remove it there with setMessagesParams(), or build a new runner without it";
var BetaToolRunner = /* @__PURE__ */ (() => {
  class BetaToolRunner2 {
    constructor(client, params, options) {
      _BetaToolRunner_instances.add(this);
      this.client = client;
      _BetaToolRunner_consumed.set(this, false);
      _BetaToolRunner_mutated.set(this, false);
      _BetaToolRunner_state.set(this, void 0);
      _BetaToolRunner_options.set(this, void 0);
      _BetaToolRunner_message.set(this, void 0);
      _BetaToolRunner_stream.set(this, void 0);
      _BetaToolRunner_toolResponse.set(this, void 0);
      _BetaToolRunner_completion.set(this, void 0);
      _BetaToolRunner_iterationCount.set(this, 0);
      _BetaToolRunner_compaction.set(this, { status: "idle" });
      _BetaToolRunner_calls.set(this, void 0);
      _BetaToolRunner_lastStopReason.set(this, null);
      _BetaToolRunner_toolOverrides.set(this, /* @__PURE__ */ new Map());
      _BetaToolRunner_pendingToolChanges.set(this, []);
      rejectCompactionParam(params);
      rejectCompactionControl(params);
      rejectRunToolsEagerlyWithoutStream(params);
      __classPrivateFieldSet(this, _BetaToolRunner_state, {
        params: {
          // You can't clone the entire params since there are functions as handlers.
          // You also don't really need to clone params.messages, but it probably will prevent a foot gun
          // somewhere.
          ...params,
          // Not structuredClone(): it throws on a function, and a runnable tool written by value into a
          // `tool_addition` block has `run`. A JSON copy is the messages as they are sent, which drops it.
          messages: JSON.parse(JSON.stringify(withToolDefinitions(params.messages)))
        }
      }, "f");
      const collected = collectStainlessHelpers(params.tools, params.messages);
      __classPrivateFieldSet(this, _BetaToolRunner_options, {
        ...options,
        headers: buildHeaders([
          helperHeader("BetaToolRunner"),
          collected.length ? { [STAINLESS_HELPER_HEADER]: collected.join(", ") } : void 0,
          options?.headers
        ])
      }, "f");
      __classPrivateFieldSet(this, _BetaToolRunner_completion, promiseWithResolvers(), "f");
    }
    async *[(_BetaToolRunner_consumed = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_mutated = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_state = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_options = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_message = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_stream = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_toolResponse = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_completion = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_iterationCount = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_compaction = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_calls = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_lastStopReason = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_toolOverrides = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_pendingToolChanges = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_instances = /* @__PURE__ */ new WeakSet(), Symbol.asyncIterator)]() {
      var _a2;
      if (__classPrivateFieldGet(this, _BetaToolRunner_consumed, "f")) {
        throw new AnthropicError("Cannot iterate over a consumed stream");
      }
      __classPrivateFieldSet(this, _BetaToolRunner_consumed, true, "f");
      __classPrivateFieldSet(this, _BetaToolRunner_mutated, true, "f");
      __classPrivateFieldSet(this, _BetaToolRunner_toolResponse, void 0, "f");
      try {
        while (true) {
          try {
            if (__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.max_iterations && __classPrivateFieldGet(this, _BetaToolRunner_iterationCount, "f") >= __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.max_iterations) {
              break;
            }
            __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_flushPendingToolChanges).call(this);
            if (__classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").status === "scheduled" && determineNextStepFromStopReason(__classPrivateFieldGet(this, _BetaToolRunner_lastStopReason, "f")) !== "resume") {
              yield* __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_compact).call(this, __classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").config);
              continue;
            }
            __classPrivateFieldSet(this, _BetaToolRunner_mutated, false, "f");
            __classPrivateFieldSet(this, _BetaToolRunner_toolResponse, void 0, "f");
            __classPrivateFieldSet(this, _BetaToolRunner_iterationCount, (_a2 = __classPrivateFieldGet(this, _BetaToolRunner_iterationCount, "f"), _a2++, _a2), "f");
            __classPrivateFieldSet(this, _BetaToolRunner_message, void 0, "f");
            const { max_iterations, runToolsEagerly, ...params } = __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params;
            yield* __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_send).call(this, params);
            if (!__classPrivateFieldGet(this, _BetaToolRunner_mutated, "f")) {
              const message = await __classPrivateFieldGet(this, _BetaToolRunner_message, "f");
              const nextStep = determineNextStepFromStopReason(message.stop_reason);
              __classPrivateFieldSet(this, _BetaToolRunner_lastStopReason, message.stop_reason, "f");
              __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages.push({
                role: message.role,
                content: asContentParam(message.content)
              });
              const { container } = __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params;
              if (message.container) {
                if (container == null) {
                  __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.container = message.container.id;
                } else if (typeof container === "object" && container.id == null) {
                  __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.container = { ...container, id: message.container.id };
                }
              }
              if (nextStep === "stop") {
                yield* __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_compactAfterFinalTurn).call(this);
                break;
              }
              if (nextStep === "resume") {
                continue;
              }
            } else {
              __classPrivateFieldSet(this, _BetaToolRunner_lastStopReason, null, "f");
            }
            const toolMessage = await __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_generateToolResponse).call(this, __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages.at(-1));
            if (toolMessage) {
              __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages.push(toolMessage);
            } else if (!__classPrivateFieldGet(this, _BetaToolRunner_mutated, "f")) {
              yield* __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_compactAfterFinalTurn).call(this);
              break;
            }
          } finally {
            __classPrivateFieldGet(this, _BetaToolRunner_stream, "f")?.abort();
            __classPrivateFieldSet(this, _BetaToolRunner_stream, void 0, "f");
          }
        }
        await __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_startedCallsSettled).call(this);
        if (!__classPrivateFieldGet(this, _BetaToolRunner_message, "f")) {
          throw new AnthropicError("ToolRunner concluded without a message from the server");
        }
        __classPrivateFieldGet(this, _BetaToolRunner_completion, "f").resolve(await __classPrivateFieldGet(this, _BetaToolRunner_message, "f"));
      } catch (error) {
        __classPrivateFieldSet(this, _BetaToolRunner_consumed, false, "f");
        __classPrivateFieldGet(this, _BetaToolRunner_completion, "f").promise.catch(() => {
        });
        __classPrivateFieldGet(this, _BetaToolRunner_completion, "f").reject(error);
        __classPrivateFieldSet(this, _BetaToolRunner_completion, promiseWithResolvers(), "f");
        throw error;
      }
    }
    setMessagesParams(paramsOrMutator) {
      const params = typeof paramsOrMutator === "function" ? paramsOrMutator(__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params) : paramsOrMutator;
      rejectCompactionParam(params);
      rejectRunToolsEagerlyWithoutStream(params);
      if (__classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").status !== "idle") {
        rejectCompactionEdit(params);
      }
      if (__classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").status === "in_flight" && params.messages !== __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages) {
        throw new AnthropicError("Message params can't be changed while the conversation is being compacted, because the compaction response is about to replace them. Change them after this iteration instead.");
      }
      __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params = params;
      __classPrivateFieldSet(this, _BetaToolRunner_mutated, true, "f");
      __classPrivateFieldSet(this, _BetaToolRunner_toolResponse, void 0, "f");
    }
    setRequestOptions(optionsOrMutator) {
      if (typeof optionsOrMutator === "function") {
        __classPrivateFieldSet(this, _BetaToolRunner_options, optionsOrMutator(__classPrivateFieldGet(this, _BetaToolRunner_options, "f")), "f");
      } else {
        __classPrivateFieldSet(this, _BetaToolRunner_options, { ...__classPrivateFieldGet(this, _BetaToolRunner_options, "f"), ...optionsOrMutator }, "f");
      }
    }
    /**
     * Get the tool response for the last message from the assistant.
     * Avoids redundant tool executions by caching results. With `runToolsEagerly`, it reuses the calls of
     * the reply that have started and runs the rest, including the ones `deferToolCall()` is holding, so that no
     * call runs twice.
     *
     * @returns A promise that resolves to a BetaMessageParam containing tool results, or null if no tools need to be executed
     *
     * @example
     * const toolResponse = await runner.generateToolResponse();
     * if (toolResponse) {
     *   console.log('Tool results:', toolResponse.content);
     * }
     */
    async generateToolResponse(signal = __classPrivateFieldGet(this, _BetaToolRunner_options, "f").signal) {
      const message = await __classPrivateFieldGet(this, _BetaToolRunner_message, "f") ?? this.params.messages.at(-1);
      if (!message) {
        return null;
      }
      return __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_generateToolResponse).call(this, message, signal);
    }
    /**
     * Hold a tool call of the current reply until you are done with the reply, which is when it runs without
     * streaming: at the end of the loop body, or when you call `generateToolResponse()`.
     *
     * With `runToolsEagerly` the runner otherwise starts each call while the reply streams, as soon as
     * the model has moved on from it: when the next block starts, or the reply stops with `tool_use`. A call
     * never starts before your stream listeners and any `for await` over the stream have handled that event, so
     * you can call this from either once you have seen the call. The other calls of the reply still start early,
     * except the later calls of the same toolset, which a toolset runs in order.
     * It does nothing for a call that has started, outside the loop body, and without `runToolsEagerly`.
     *
     * @param toolUse - The `tool_use` block of the call, or its id
     *
     * @example
     * for await (const stream of runner) {
     *   stream.on('contentBlock', (block) => {
     *     if (block.type === 'tool_use' && block.name === 'delete_file') {
     *       runner.deferToolCall(block);
     *     }
     *   });
     *   await stream.finalMessage();
     *   // No `delete_file` call has started yet.
     * }
     */
    deferToolCall(toolUse) {
      const id = typeof toolUse === "string" ? toolUse : toolUse.id;
      if (__classPrivateFieldGet(this, _BetaToolRunner_calls, "f") && !__classPrivateFieldGet(this, _BetaToolRunner_calls, "f").has(id)) {
        __classPrivateFieldGet(this, _BetaToolRunner_calls, "f").set(id, { status: "held" });
      }
    }
    /**
     * The tool calls of the current reply that `deferToolCall()` is holding, in the model's order, as their
     * `tool_use` blocks. A call is in the list once its block has finished streaming, so read the list when you
     * are done with the stream. A call that has started is not in it. It is empty without
     * `runToolsEagerly`.
     *
     * Held calls are listed whatever the reply's `stop_reason`, because `generateToolResponse()` runs them
     * whatever it is. After `max_tokens` the input of the last call can be cut off.
     *
     * @example
     * for await (const stream of runner) {
     *   stream.on('contentBlock', (block) => {
     *     if (block.type === 'tool_use' && block.name === 'delete_file') {
     *       runner.deferToolCall(block);
     *     }
     *   });
     *   await stream.finalMessage();
     *
     *   const held = runner.deferredToolCalls;
     *   if (held.length > 0 && !(await confirm(held))) break;
     * }
     */
    get deferredToolCalls() {
      const stream2 = __classPrivateFieldGet(this, _BetaToolRunner_stream, "f");
      const calls = __classPrivateFieldGet(this, _BetaToolRunner_calls, "f");
      if (!(stream2 instanceof BetaToolRunnerStream) || !calls) {
        return [];
      }
      return stream2.toolCalls.filter((toolUse) => calls.get(toolUse.id)?.status === "held");
    }
    /**
     * Wait for the async iterator to complete. This works even if the async iterator hasn't yet started, and
     * will wait for an instance to start and go to completion.
     *
     * @returns A promise that resolves to the final BetaMessage when the iterator completes
     *
     * @example
     * // Start consuming the iterator
     * for await (const message of runner) {
     *   console.log('Message:', message.content);
     * }
     *
     * // Meanwhile, wait for completion from another part of the code
     * const finalMessage = await runner.done();
     * console.log('Final response:', finalMessage.content);
     */
    done() {
      return __classPrivateFieldGet(this, _BetaToolRunner_completion, "f").promise;
    }
    /**
     * Returns a promise indicating that the stream is done. Unlike .done(), this will eagerly read the stream:
     * * If the iterator has not been consumed, consume the entire iterator and return the final message from the
     * assistant.
     * * If the iterator has been consumed, waits for it to complete and returns the final message.
     *
     * @returns A promise that resolves to the final BetaMessage from the conversation
     * @throws {AnthropicError} If no messages were processed during the conversation
     *
     * @example
     * const finalMessage = await runner.runUntilDone();
     * console.log('Final response:', finalMessage.content);
     */
    async runUntilDone() {
      if (!__classPrivateFieldGet(this, _BetaToolRunner_consumed, "f")) {
        for await (const _ of this) {
        }
      }
      return this.done();
    }
    /**
     * Get the current parameters being used by the ToolRunner.
     *
     * @returns A readonly view of the current ToolRunnerParams
     *
     * @example
     * const currentParams = runner.params;
     * console.log('Current model:', currentParams.model);
     * console.log('Message count:', currentParams.messages.length);
     */
    get params() {
      return __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params;
    }
    /**
     * Add one or more messages to the conversation history.
     *
     * @param messages - One or more BetaMessageParam objects to add to the conversation
     *
     * @example
     * runner.pushMessages(
     *   { role: 'user', content: 'Also, what about the weather in NYC?' }
     * );
     *
     * @example
     * // Adding multiple messages
     * runner.pushMessages(
     *   { role: 'user', content: 'What about NYC?' },
     *   { role: 'user', content: 'And Boston?' }
     * );
     */
    pushMessages(...messages) {
      this.setMessagesParams((params) => ({
        ...params,
        messages: [...params.messages, ...messages]
      }));
    }
    /**
     * Schedule a compaction of the conversation. Once the current turn has finished, including any tool
     * calls, the runner requests a summary and replaces the message history with the compaction response,
     * which is yielded like any other message. Requires the `compact-2026-09-04` beta.
     *
     * @param compaction - The config to send, as `messages.create()` takes it. Defaults to `{ type: 'summarize' }`
     *
     * @example
     * for await (const message of runner) {
     *   if (message.usage.input_tokens > 100_000) {
     *     runner.compactBeforeNextTurn();
     *   }
     * }
     */
    compactBeforeNextTurn(compaction) {
      if (__classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").status === "in_flight") {
        return;
      }
      rejectCompactionEdit(__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params);
      __classPrivateFieldSet(this, _BetaToolRunner_compaction, { status: "scheduled", config: compaction ?? { type: "summarize" } }, "f");
    }
    /**
     * Give the model more tools without changing `params.tools`, which would miss the prompt cache.
     *
     * Each tool's whole definition is sent in a `tool_addition` block with the next request, and a
     * runnable tool replaces a runnable tool of the same name straight away, even for a call already in
     * the message being handled. A call that started while the reply streamed keeps the old one. A raw definition
     * is only sent: the runner never runs it, and stops running a tool of the same name. Passing a runnable toolset,
     * or a raw definition of a toolset the runner has, throws `ToolsetContractError` and adds nothing: a runner's
     * toolsets come only from `params.tools`. A tool named like one of its toolsets is left to the API, which rejects
     * it with the next request. Requires the `inline-tools-2026-09-15` beta, which the runner does not add for you.
     *
     * @param tools - Runnable tools (for example from `betaZodTool()`) or raw tool definitions
     *
     * @example
     * runner.addTools(queryDatabaseTool);
     */
    addTools(...tools) {
      const families = __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_toolsetFamilies).call(this);
      for (const tool of tools) {
        if (isRunnableToolset(tool)) {
          throw new ToolsetContractError(`addTools() can't add the '${quotedName(toolsetFamily(tool))}' toolset: ${USE_A_NEW_RUNNER}`);
        }
        const family = definitionFamily(tool);
        if (families.has(family)) {
          throw new ToolsetContractError(`addTools() can't replace the '${quotedName(family)}' toolset: ${USE_A_NEW_RUNNER}`);
        }
      }
      for (const tool of tools) {
        if ("name" in tool) {
          __classPrivateFieldGet(this, _BetaToolRunner_toolOverrides, "f").set(tool.name, "run" in tool ? tool : null);
        }
        __classPrivateFieldGet(this, _BetaToolRunner_pendingToolChanges, "f").push({ type: "addition", tool });
      }
    }
    /**
     * Take tools away from the model without changing `params.tools`, which would miss the prompt cache.
     *
     * The tools stop being run straight away: a call to one of them, even one in the message being
     * handled, gets the same "not found" error result as a call to an unknown tool. A call that started while the
     * reply streamed finishes as usual. The model is told in a `tool_removal` block with the next request. Use
     * {@link addTools} to bring a tool back. Passing the name of one of the runner's toolsets throws
     * `ToolsetContractError` and removes nothing. Requires the `inline-tools-2026-09-15` beta, which the runner does
     * not add for you.
     *
     * @param tools - The tools to remove, or their names
     *
     * @example
     * runner.removeTools('query_database');
     */
    removeTools(...tools) {
      const families = __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_toolsetFamilies).call(this);
      for (const tool of tools) {
        const name = typeof tool === "string" ? tool : tool.name;
        if (families.has(name)) {
          throw new ToolsetContractError(`removeTools() can't remove the '${quotedName(name)}' toolset: ${REMOVE_WITH_A_NEW_RUNNER}`);
        }
      }
      for (const tool of tools) {
        const name = typeof tool === "string" ? tool : tool.name;
        __classPrivateFieldGet(this, _BetaToolRunner_toolOverrides, "f").set(name, null);
        __classPrivateFieldGet(this, _BetaToolRunner_pendingToolChanges, "f").push({ type: "removal", name });
      }
    }
    /**
     * Makes the ToolRunner directly awaitable, equivalent to calling .runUntilDone()
     * This allows using `await runner` instead of `await runner.runUntilDone()`
     */
    then(onfulfilled, onrejected) {
      return this.runUntilDone().then(onfulfilled, onrejected);
    }
  }
  _BetaToolRunner_send = /**
   * Sends one request and yields its message, or its stream when streaming. `#message` and `#stream` are set
   * before the yield, so they are there while the caller handles the item; the loop aborts the stream at the
   * end of the iteration.
   */
  async function* _BetaToolRunner_send2(params) {
    await __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_startedCallsSettled).call(this);
    __classPrivateFieldSet(this, _BetaToolRunner_calls, void 0, "f");
    params = {
      ...params,
      ...params.tools && { tools: params.tools.map(toolDefinition) },
      messages: withToolDefinitions(params.messages)
    };
    if (params.stream) {
      __classPrivateFieldSet(this, _BetaToolRunner_stream, __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.runToolsEagerly ? __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_streamThatStartsTools).call(this, params) : this.client.beta.messages.stream({ ...params }, __classPrivateFieldGet(this, _BetaToolRunner_options, "f")), "f");
      __classPrivateFieldSet(this, _BetaToolRunner_message, __classPrivateFieldGet(this, _BetaToolRunner_stream, "f").finalMessage(), "f");
      __classPrivateFieldGet(this, _BetaToolRunner_message, "f").catch(() => {
      });
      yield __classPrivateFieldGet(this, _BetaToolRunner_stream, "f");
    } else {
      __classPrivateFieldSet(this, _BetaToolRunner_message, this.client.beta.messages.create({ ...params, stream: false }, __classPrivateFieldGet(this, _BetaToolRunner_options, "f")), "f");
      yield __classPrivateFieldGet(this, _BetaToolRunner_message, "f");
    }
  }, _BetaToolRunner_streamThatStartsTools = function _BetaToolRunner_streamThatStartsTools2(params) {
    const calls = /* @__PURE__ */ new Map();
    __classPrivateFieldSet(this, _BetaToolRunner_calls, calls, "f");
    const toolsets = /* @__PURE__ */ new Map();
    return BetaToolRunnerStream.start(this.client.beta.messages, params, __classPrivateFieldGet(this, _BetaToolRunner_options, "f"), (toolUse) => {
      const known = calls.has(toolUse.id);
      const malformed = !toolUse.toolset_name && __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_toolsetFamilies).call(this).has(toolUse.name);
      const family = malformed ? toolUse.name : toolUse.toolset_name;
      if (family) {
        if (known || malformed || toolsets.has(family)) {
          toolsets.set(family, "waiting");
          return;
        }
        toolsets.set(family, "running");
        const result2 = runToolsetCall(__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params, family, toolUse, __classPrivateFieldGet(this, _BetaToolRunner_options, "f"));
        calls.set(toolUse.id, { status: "started", result: result2 });
        result2.then(({ is_error }) => {
          if (is_error || toolsets.get(family) === "waiting")
            toolsets.set(family, "waiting");
          else
            toolsets.delete(family);
        }, () => toolsets.set(family, "waiting"));
        return;
      }
      if (known) {
        return;
      }
      const result = runToolCall(__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_runnableTools).call(this), __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_availableToolNames).call(this), toolUse, __classPrivateFieldGet(this, _BetaToolRunner_options, "f"));
      result.catch(() => {
      });
      calls.set(toolUse.id, { status: "started", result });
    });
  }, _BetaToolRunner_startedCallsSettled = /** Waits for the calls of the last streamed reply that have started, whether or not their results were sent. */
  async function _BetaToolRunner_startedCallsSettled2() {
    const started = [...__classPrivateFieldGet(this, _BetaToolRunner_calls, "f")?.values() ?? []].filter((call) => call.status === "started");
    await Promise.allSettled(started.map((call) => call.result));
  }, _BetaToolRunner_compact = async function* _BetaToolRunner_compact2(compaction) {
    rejectCompactionEdit(__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params);
    const { max_iterations, runToolsEagerly, ...requestParams } = __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params;
    const params = withoutCompactionIncompatibleParams(requestParams);
    __classPrivateFieldSet(this, _BetaToolRunner_compaction, { status: "in_flight" }, "f");
    __classPrivateFieldSet(this, _BetaToolRunner_toolResponse, void 0, "f");
    const lastMessage = __classPrivateFieldGet(this, _BetaToolRunner_message, "f");
    try {
      yield* __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_send).call(this, { ...params, compaction });
      const message = await __classPrivateFieldGet(this, _BetaToolRunner_message, "f");
      if (message.content.some((block) => block.type === "compaction" && block.content)) {
        __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_recordRemovalsFromHistory).call(this);
        __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages = [{ role: message.role, content: message.content }];
      } else {
        loggerFor(this.client).warn("Compaction produced no summary; keeping the conversation as it is.");
        __classPrivateFieldSet(this, _BetaToolRunner_message, lastMessage, "f");
      }
    } finally {
      __classPrivateFieldSet(this, _BetaToolRunner_compaction, { status: "idle" }, "f");
    }
  }, _BetaToolRunner_runnableTools = function _BetaToolRunner_runnableTools2() {
    const runnable = /* @__PURE__ */ new Map();
    for (const tool of __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.tools) {
      if ("run" in tool && "name" in tool) {
        runnable.set(tool.name, tool);
      }
    }
    for (const [name, tool] of __classPrivateFieldGet(this, _BetaToolRunner_toolOverrides, "f")) {
      if (tool) {
        runnable.set(name, tool);
      } else {
        runnable.delete(name);
      }
    }
    return runnable;
  }, _BetaToolRunner_availableToolNames = function _BetaToolRunner_availableToolNames2() {
    const available = new Set(__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_runnableTools).call(this).keys());
    for (const message of [...__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages, __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_pendingToolChangesMessage).call(this)]) {
      if (typeof message.content === "string") {
        continue;
      }
      for (const block of message.content) {
        if (message.role === "system") {
          applyToolChange(block, available);
        } else if (message.role === "assistant" && block.type === "compaction") {
          for (const change of block.tool_changes ?? []) {
            applyToolChange(change, available);
          }
        }
      }
    }
    return available;
  }, _BetaToolRunner_recordRemovalsFromHistory = function _BetaToolRunner_recordRemovalsFromHistory2() {
    const available = __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_availableToolNames).call(this);
    for (const name of __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_runnableTools).call(this).keys()) {
      if (!available.has(name)) {
        __classPrivateFieldGet(this, _BetaToolRunner_toolOverrides, "f").set(name, null);
      }
    }
  }, _BetaToolRunner_compactAfterFinalTurn = async function* _BetaToolRunner_compactAfterFinalTurn2() {
    if (__classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").status !== "scheduled") {
      return;
    }
    const lastContent = __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages.at(-1)?.content;
    if (Array.isArray(lastContent) && lastContent.some((block) => block.type === "tool_use")) {
      loggerFor(this.client).warn("The pending compaction was skipped because the last turn ended with tool calls that were not run. Call `compactBeforeNextTurn()` again if you continue the conversation.");
      __classPrivateFieldSet(this, _BetaToolRunner_compaction, { status: "idle" }, "f");
      return;
    }
    yield* __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_compact).call(this, __classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").config);
  }, _BetaToolRunner_generateToolResponse = async function _BetaToolRunner_generateToolResponse2(lastMessage, signal = __classPrivateFieldGet(this, _BetaToolRunner_options, "f").signal) {
    if (__classPrivateFieldGet(this, _BetaToolRunner_toolResponse, "f") !== void 0) {
      return __classPrivateFieldGet(this, _BetaToolRunner_toolResponse, "f");
    }
    __classPrivateFieldSet(this, _BetaToolRunner_toolResponse, generateToolResponse(__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params, __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_runnableTools).call(this), __classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_availableToolNames).call(this), lastMessage, { ...__classPrivateFieldGet(this, _BetaToolRunner_options, "f"), signal }, __classPrivateFieldGet(this, _BetaToolRunner_calls, "f")), "f");
    return __classPrivateFieldGet(this, _BetaToolRunner_toolResponse, "f");
  }, _BetaToolRunner_toolsetFamilies = function _BetaToolRunner_toolsetFamilies2() {
    return new Set(__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.tools.filter(isRunnableToolset).map(toolsetFamily));
  }, _BetaToolRunner_flushPendingToolChanges = function _BetaToolRunner_flushPendingToolChanges2() {
    if (__classPrivateFieldGet(this, _BetaToolRunner_lastStopReason, "f") === "pause_turn" || __classPrivateFieldGet(this, _BetaToolRunner_pendingToolChanges, "f").length === 0) {
      return;
    }
    __classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages.push(__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_pendingToolChangesMessage).call(this));
    __classPrivateFieldSet(this, _BetaToolRunner_pendingToolChanges, [], "f");
  }, _BetaToolRunner_pendingToolChangesMessage = function _BetaToolRunner_pendingToolChangesMessage2() {
    const content = [];
    for (const change of __classPrivateFieldGet(this, _BetaToolRunner_pendingToolChanges, "f")) {
      if (change.type === "removal") {
        content.push({ type: "tool_removal", tool: { type: "tool_reference", name: change.name } });
        continue;
      }
      const definition = toolDefinition(change.tool);
      content.push({ type: "tool_addition", tool: { type: "tool_definition", definition } });
    }
    return { role: "system", content };
  };
  return BetaToolRunner2;
})();
function rejectCompactionParam(params) {
  if ("compaction" in params && params.compaction != null) {
    throw new AnthropicError("`compaction` cannot be set on a tool runner: every request in the loop would compact again. Call `runner.compactBeforeNextTurn()` when the conversation should be compacted instead.");
  }
}
function rejectCompactionControl(params) {
  if ("compactionControl" in params && params.compactionControl != null) {
    throw new AnthropicError("`compactionControl` has been removed from the tool runner. Use server-side compaction instead: call `runner.compactBeforeNextTurn()` when the conversation should be compacted.");
  }
}
function rejectRunToolsEagerlyWithoutStream(params) {
  if (params.runToolsEagerly && !params.stream) {
    throw new TypeError("`runToolsEagerly: true` needs `stream: true` in the tool runner's params, because a reply that isn't streamed arrives whole.");
  }
}
function rejectCompactionEdit(params) {
  if (params.context_management?.edits?.some((edit) => edit.type.startsWith("compact_"))) {
    throw new AnthropicError("`compactBeforeNextTurn()` can't be used while `context_management` has a compaction edit, because the API doesn't accept a compaction block together with one. Remove the edit first.");
  }
}
function withoutCompactionIncompatibleParams(params) {
  const { context_management, stop_sequences, output_format, ...kept } = params;
  const withoutFormat = ({ format, ...outputConfig }) => outputConfig;
  if (kept.tool_choice?.type === "any" || kept.tool_choice?.type === "tool") {
    delete kept.tool_choice;
  }
  if (kept.output_config) {
    kept.output_config = withoutFormat(kept.output_config);
  }
  if (Array.isArray(kept.fallbacks)) {
    kept.fallbacks = kept.fallbacks.map((fallback) => fallback.output_config ? { ...fallback, output_config: withoutFormat(fallback.output_config) } : fallback);
  }
  return kept;
}
function toolDefinition(tool) {
  if (!("run" in tool)) {
    return tool;
  }
  const apiKeys = BETA_CLIENT_TOOL_UNION_KEYS;
  const fields = "toJSON" in tool && typeof tool.toJSON === "function" ? tool.toJSON() : tool;
  return {
    ...Object.fromEntries(Object.entries(fields).filter(([key]) => apiKeys.includes(key))),
    ...wasCreatedByStainlessHelper(tool) && { [SDK_HELPER_SYMBOL]: tool[SDK_HELPER_SYMBOL] }
  };
}
function withToolDefinitions(messages) {
  return messages.map((message) => {
    if (message.role !== "system" || typeof message.content === "string") {
      return message;
    }
    const content = message.content.map((block) => block.type === "tool_addition" && block.tool.type === "tool_definition" ? { ...block, tool: { ...block.tool, definition: toolDefinition(block.tool.definition) } } : block);
    return { ...message, content };
  });
}
async function generateToolResponse(params, runnable, available, lastMessage, requestOptions, calls) {
  if (!lastMessage || lastMessage.role !== "assistant" || !lastMessage.content || typeof lastMessage.content === "string") {
    return null;
  }
  const toolUseBlocks = lastMessage.content.filter((content) => content.type === "tool_use");
  if (toolUseBlocks.length === 0) {
    return null;
  }
  const sequences = /* @__PURE__ */ new Map();
  const toolResults = await Promise.all(toolUseBlocks.map(async (toolUse) => {
    const call = calls?.get(toolUse.id);
    const started = call?.status === "started" ? call.result : void 0;
    if (toolUse.toolset_name) {
      const family = toolUse.toolset_name;
      const sequence = sequences.get(family) ?? { tail: Promise.resolve(), failed: false };
      sequences.set(family, sequence);
      const registered = params.tools.some((t) => isRunnableToolset(t) && toolsetFamily(t) === family);
      const run = started ?? sequence.tail.then(() => sequence.failed ? toolsetResultBlock(toolUse, notExecutedText(family), true) : runToolsetCall(params, family, toolUse, requestOptions));
      sequence.tail = run.then(({ is_error }) => {
        if (is_error && registered)
          sequence.failed = true;
      }, () => {
        sequence.failed = true;
      });
      calls?.set(toolUse.id, { status: "started", result: run });
      return run;
    }
    if (started) {
      return started;
    }
    const tool = available.has(toolUse.name) ? runnable.get(toolUse.name) : void 0;
    if (!tool && params.tools.some((t) => isRunnableToolset(t) && toolsetFamily(t) === toolUse.name)) {
      const sequence = sequences.get(toolUse.name) ?? { tail: Promise.resolve(), failed: false };
      sequences.set(toolUse.name, sequence);
      sequence.tail = sequence.tail.then(() => {
        sequence.failed = true;
      });
      return malformedToolsetCallResult(toolUse);
    }
    const result = runToolCall(runnable, available, toolUse, requestOptions);
    calls?.set(toolUse.id, { status: "started", result });
    return result;
  }));
  return {
    role: "user",
    content: toolResults
  };
}
async function runToolsetCall(params, family, toolUse, requestOptions) {
  const toolset = params.tools.find((t) => isRunnableToolset(t) && toolsetFamily(t) === family);
  return toolset ? runToolsetMember(toolset, toolUse, { signal: requestOptions?.signal }) : toolsetResultBlock(toolUse, `Error: Toolset '${quotedName(family)}' member '${quotedName(toolUse.name)}' not found`, true);
}
async function runToolCall(runnable, available, toolUse, requestOptions) {
  const tool = available.has(toolUse.name) ? runnable.get(toolUse.name) : void 0;
  if (!tool) {
    return toolNotFoundResult(toolUse);
  }
  try {
    let input = toolUse.input;
    if ("parse" in tool && tool.parse) {
      input = tool.parse(input);
    }
    const result = await tool.run(input, {
      toolUse,
      toolUseBlock: toolUse,
      signal: requestOptions?.signal
    });
    return {
      type: "tool_result",
      tool_use_id: toolUse.id,
      content: result
    };
  } catch (error) {
    return {
      type: "tool_result",
      tool_use_id: toolUse.id,
      content: toolErrorContent(error),
      is_error: true
    };
  }
}
function asContentParam(content) {
  return content;
}
function definitionFamily(tool) {
  return (tool.type ?? "custom").replace(/_\d{8}$/, "").replace(/_toolset$/, "");
}
function toolNotFoundResult(toolUse) {
  return {
    type: "tool_result",
    tool_use_id: toolUse.id,
    content: `Error: Tool '${toolUse.name}' not found`,
    is_error: true
  };
}
function malformedToolsetCallResult(toolUse) {
  return {
    type: "tool_result",
    tool_use_id: toolUse.id,
    content: `Error: the '${quotedName(toolUse.name)}' toolset could not run this call${malformedActions(toolUse.input)}; nothing in the batch was executed`,
    is_error: true
  };
}
function malformedActions(input) {
  const fields = typeof input === "object" && input !== null ? input : {};
  if (!("actions" in fields)) {
    const action = "action" in fields ? fields.action : void 0;
    return typeof action === "string" ? `: the call has no 'actions' list (action: '${quotedName(action)}')` : ": the call has no 'actions' list";
  }
  const { actions } = fields;
  if (typeof actions === "string")
    return ": 'actions' is text, not a list of actions";
  if (!Array.isArray(actions))
    return ": 'actions' is not a list of actions";
  if (actions.length === 0)
    return ": the 'actions' list is empty";
  const names = [];
  for (const [i, entry] of actions.entries()) {
    const action = typeof entry === "object" && entry !== null && "action" in entry ? entry.action : void 0;
    if (typeof action !== "string")
      return `: action ${i} must be an object with a string 'action' field`;
    names.push(`'${quotedName(action)}'`);
  }
  const more = names.length > 10 ? `, and ${names.length - 10} more` : "";
  return `: its actions could not be run as sent (actions: ${names.slice(0, 10).join(", ")}${more})`;
}
function applyToolChange(block, available) {
  switch (block.type) {
    case "tool_removal":
    case "tool_addition":
      applyToolReference(block, available);
      break;
  }
}
function applyToolReference(block, available) {
  const name = changedToolName(block.tool);
  if (name === void 0)
    return;
  if (block.type === "tool_removal") {
    available.delete(name);
  } else {
    available.add(name);
  }
}
function changedToolName(tool) {
  switch (tool.type) {
    case "tool_reference":
      return tool.name;
    case "tool_definition":
      return "name" in tool.definition ? tool.definition.name : void 0;
    default:
      return void 0;
  }
}
function determineNextStepFromStopReason(stopReason) {
  if (stopReason === null)
    return "stop";
  switch (stopReason) {
    case "tool_use":
      return "run_tools";
    case "pause_turn":
    // pause_after_compaction hands the turn back before the model answers; sending it back
    // unchanged continues it.
    case "compaction":
      return "resume";
    case "end_turn":
    case "stop_sequence":
    case "max_tokens":
    case "model_context_window_exceeded":
    case "refusal":
      return "stop";
    default:
      checkNever(stopReason);
      return "stop";
  }
}

// node_modules/@anthropic-ai/sdk/resources/beta/messages/messages.mjs
var DEPRECATED_MODELS2 = {
  "claude-sonnet-4-5": "November 30th, 2026",
  "claude-sonnet-4-5-20250929": "November 30th, 2026"
};
var MODELS_TO_WARN_WITH_THINKING_ENABLED2 = ["claude-mythos-preview", "claude-opus-4-6"];
var Messages2 = /* @__PURE__ */ (() => {
  class Messages3 extends APIResource {
    constructor() {
      super(...arguments);
      this.batches = new Batches2(this._client);
    }
    create(params, options) {
      const modifiedParams = transformOutputFormat(params);
      const { betas, user_profile_id, workspace_id, ...body } = modifiedParams;
      if (body.model in DEPRECATED_MODELS2) {
        console.warn(`The model '${body.model}' is deprecated and will reach end-of-life on ${DEPRECATED_MODELS2[body.model]}
Please migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.`);
      }
      if (MODELS_TO_WARN_WITH_THINKING_ENABLED2.includes(body.model) && body.thinking && body.thinking.type === "enabled") {
        console.warn(`Using Claude with ${body.model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking`);
      }
      let timeout = options?.timeout ?? this._client._options.timeout;
      if (!body.stream && timeout == null) {
        const maxNonstreamingTokens = MODEL_NONSTREAMING_TOKENS[body.model] ?? void 0;
        timeout = this._client.calculateNonstreamingTimeout(body.max_tokens, maxNonstreamingTokens);
      }
      const helperHeader2 = stainlessHelperHeader(body.tools, body.messages);
      return this._client.post("/v1/messages?beta=true", {
        body,
        timeout: timeout ?? 6e5,
        ...options,
        headers: buildHeaders([
          {
            ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
            ...user_profile_id != null ? { "anthropic-user-profile-id": user_profile_id } : void 0,
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          helperHeader2,
          options?.headers
        ]),
        stream: modifiedParams.stream ?? false
      });
    }
    /**
     * Send a structured list of input messages with text and/or image content, along with an expected `output_format` and
     * the response will be automatically parsed and available in the `parsed_output` property of the message.
     *
     * @example
     * ```ts
     * const message = await client.beta.messages.parse({
     *   model: 'claude-3-5-sonnet-20241022',
     *   max_tokens: 1024,
     *   messages: [{ role: 'user', content: 'What is 2+2?' }],
     *   output_format: zodOutputFormat(z.object({ answer: z.number() }), 'math'),
     * });
     *
     * console.log(message.parsed_output?.answer); // 4
     * ```
     */
    parse(params, options) {
      options = {
        ...options,
        headers: buildHeaders([
          { "anthropic-beta": [...params.betas ?? [], "structured-outputs-2025-12-15"].toString() },
          options?.headers
        ])
      };
      return this.create(params, options).then((message) => parseBetaMessage(message, params, { logger: this._client.logger ?? console }));
    }
    /**
     * Create a Message stream
     */
    stream(body, options) {
      return BetaMessageStream.createMessage(this, body, options);
    }
    /**
     * Count the number of tokens in a Message.
     *
     * The Token Count API can be used to count the number of tokens in a Message,
     * including tools, images, and documents, without creating it.
     *
     * Learn more about token counting in our
     * [user guide](https://platform.claude.com/docs/en/build-with-claude/token-counting)
     *
     * @example
     * ```ts
     * const betaMessageTokensCount =
     *   await client.beta.messages.countTokens({
     *     messages: [{ content: 'Hello, world', role: 'user' }],
     *     model: 'claude-opus-5',
     *   });
     * ```
     */
    countTokens(params, options) {
      const modifiedParams = transformOutputFormat(params);
      const { betas, user_profile_id, workspace_id, ...body } = modifiedParams;
      return this._client.post("/v1/messages/count_tokens?beta=true", {
        body,
        ...options,
        headers: buildHeaders([
          {
            "anthropic-beta": [...betas ?? [], "token-counting-2024-11-01"].toString(),
            ...user_profile_id != null ? { "anthropic-user-profile-id": user_profile_id } : void 0,
            ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
          },
          options?.headers
        ])
      });
    }
    toolRunner(body, options) {
      return new BetaToolRunner(this._client, body, options);
    }
  }
  Messages3.Batches = Batches2;
  Messages3.BetaToolRunner = BetaToolRunner;
  Messages3.ToolError = ToolError;
  return Messages3;
})();
function transformOutputFormat(params) {
  if (!params.output_format) {
    return params;
  }
  if (params.output_config?.format) {
    throw new AnthropicError("Both output_format and output_config.format were provided. Please use only output_config.format (output_format is deprecated).");
  }
  const { output_format, ...rest } = params;
  return {
    ...rest,
    output_config: {
      ...params.output_config,
      format: output_format
    }
  };
}
var BETA_CLIENT_TOOL_UNION_KEYS = [
  "input_schema",
  "name",
  "allowed_callers",
  "cache_control",
  "defer_loading",
  "description",
  "eager_input_streaming",
  "input_examples",
  "strict",
  "type",
  "configs",
  "display_height_px",
  "display_width_px",
  "display_number",
  "enable_zoom",
  "max_characters"
];

// node_modules/@anthropic-ai/sdk/resources/beta/beta.mjs
var Beta = /* @__PURE__ */ (() => {
  class Beta2 extends APIResource {
    constructor() {
      super(...arguments);
      this.models = new Models(this._client);
      this.messages = new Messages2(this._client);
      this.agents = new Agents(this._client);
      this.environments = new Environments(this._client);
      this.sessions = new Sessions(this._client);
      this.deployments = new Deployments(this._client);
      this.deploymentRuns = new DeploymentRuns(this._client);
      this.vaults = new Vaults(this._client);
      this.memoryStores = new MemoryStores(this._client);
      this.files = new Files(this._client);
      this.skills = new Skills2(this._client);
      this.webhooks = new Webhooks(this._client);
      this.userProfiles = new UserProfiles(this._client);
      this.dreams = new Dreams(this._client);
      this.tunnels = new Tunnels(this._client);
      this.organization = new Organization(this._client);
    }
  }
  Beta2.Models = Models;
  Beta2.Messages = Messages2;
  Beta2.Agents = Agents;
  Beta2.Environments = Environments;
  Beta2.Sessions = Sessions;
  Beta2.Deployments = Deployments;
  Beta2.DeploymentRuns = DeploymentRuns;
  Beta2.Vaults = Vaults;
  Beta2.MemoryStores = MemoryStores;
  Beta2.Files = Files;
  Beta2.Skills = Skills2;
  Beta2.Webhooks = Webhooks;
  Beta2.UserProfiles = UserProfiles;
  Beta2.Dreams = Dreams;
  Beta2.Tunnels = Tunnels;
  Beta2.Organization = Organization;
  return Beta2;
})();

// node_modules/@anthropic-ai/sdk/resources/completions.mjs
var Completions = class extends APIResource {
  create(params, options) {
    const { betas, workspace_id, ...body } = params;
    return this._client.post("/v1/complete", {
      body,
      timeout: this._client._options.timeout ?? 6e5,
      ...options,
      headers: buildHeaders([
        {
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ]),
      stream: params.stream ?? false
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/files.mjs
var Files2 = class extends APIResource {
  /**
   * List Files
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const fileMetadata of client.files.list()) {
   *   // ...
   * }
   * ```
   */
  list(params = {}, options) {
    const { workspace_id, ...query } = params ?? {};
    return this._client.getAPIList("/v1/files", PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * Delete File
   *
   * @example
   * ```ts
   * const deletedFile = await client.files.delete('file_id');
   * ```
   */
  delete(fileID, params = {}, options) {
    const { workspace_id } = params ?? {};
    return this._client.delete(path2`/v1/files/${fileID}`, {
      ...options,
      headers: buildHeaders([
        { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * Download File
   *
   * @example
   * ```ts
   * const response = await client.files.download('file_id');
   *
   * const content = await response.blob();
   * console.log(content);
   * ```
   */
  download(fileID, params = {}, options) {
    const { workspace_id } = params ?? {};
    return this._client.get(path2`/v1/files/${fileID}/content`, {
      ...options,
      headers: buildHeaders([
        {
          Accept: "application/binary",
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ]),
      __binaryResponse: true
    });
  }
  /**
   * Get File Metadata
   *
   * @example
   * ```ts
   * const fileMetadata = await client.files.retrieveMetadata(
   *   'file_id',
   * );
   * ```
   */
  retrieveMetadata(fileID, params = {}, options) {
    const { workspace_id } = params ?? {};
    return this._client.get(path2`/v1/files/${fileID}`, {
      ...options,
      headers: buildHeaders([
        { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * Upload File
   *
   * @example
   * ```ts
   * const fileMetadata = await client.files.upload({
   *   file: fs.createReadStream('path/to/file'),
   * });
   * ```
   */
  upload(params, options) {
    const { workspace_id, ...body } = params;
    return this._client.post("/v1/files", multipartFormRequestOptions({
      body,
      ...options,
      headers: buildHeaders([
        { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
        stainlessHelperHeaderFromFile(body.file),
        options?.headers
      ])
    }, this._client));
  }
};

// node_modules/@anthropic-ai/sdk/resources/models.mjs
var Models2 = class extends APIResource {
  /**
   * Get a specific model.
   *
   * The Models API response can be used to determine information about a specific
   * model or resolve a model alias to a model ID.
   *
   * @example
   * ```ts
   * const modelInfo = await client.models.retrieve('model_id');
   * ```
   */
  retrieve(modelID, params = {}, options) {
    const { betas, workspace_id } = params ?? {};
    return this._client.get(path2`/v1/models/${modelID}`, {
      ...options,
      headers: buildHeaders([
        {
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
  /**
   * List available models.
   *
   * The Models API response can be used to determine which models are available for
   * use in the API. More recently released models are listed first.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const modelInfo of client.models.list()) {
   *   // ...
   * }
   * ```
   */
  list(params = {}, options) {
    const { betas, workspace_id, ...query } = params ?? {};
    return this._client.getAPIList("/v1/models", Page, {
      query,
      ...options,
      headers: buildHeaders([
        {
          ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
          ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
        },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/organization/api-keys.mjs
var APIKeys2 = class extends APIResource {
  /**
   * Get API Key
   *
   * @example
   * ```ts
   * const apiKey = await client.organization.apiKeys.retrieve(
   *   'api_key_id',
   * );
   * ```
   */
  retrieve(apiKeyID, options) {
    return this._client.get(path2`/v1/organizations/api_keys/${apiKeyID}`, options);
  }
  /**
   * Update API Key
   *
   * @example
   * ```ts
   * const apiKey = await client.organization.apiKeys.update(
   *   'api_key_id',
   * );
   * ```
   */
  update(apiKeyID, body, options) {
    return this._client.post(path2`/v1/organizations/api_keys/${apiKeyID}`, { body, ...options });
  }
  /**
   * List API Keys
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const apiKey of client.organization.apiKeys.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/api_keys", Page, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/organization/compliance-settings.mjs
var ComplianceSettings2 = class extends APIResource {
  /**
   * Retrieve your organization's Compliance Settings.
   *
   * Compliance Settings is a singleton resource: there is exactly one per
   * organization, addressed without an identifier. The `state` field reflects
   * whether the Compliance API is enabled. An organization with a parent
   * organization reads the state inherited from the parent's configuration.
   *
   * @example
   * ```ts
   * const organizationComplianceSettings =
   *   await client.organization.complianceSettings.retrieve();
   * ```
   */
  retrieve(options) {
    return this._client.get("/v1/organizations/compliance_settings", options);
  }
  /**
   * Update your organization's Compliance Settings.
   *
   * Setting `state` to `enabled` turns on the Compliance API and begins capturing
   * organization activity events. Setting it to `disabled` turns both off. `state`
   * reflects whether the Compliance API is enabled.
   *
   * A request that sets `state` to its current value succeeds and leaves the
   * resource unchanged. A `disabled` request stays in effect until a later `enabled`
   * request or the organization's next provisioning action that enables Access
   * Transparency: enabling Access Transparency also enables the Compliance API,
   * which serves its activity events, so such provisioning (including re-runs)
   * re-enables the Compliance API even after a `disabled` request. Automated
   * provisioning never disables compliance settings.
   *
   * @example
   * ```ts
   * const organizationComplianceSettings =
   *   await client.organization.complianceSettings.update({
   *     state: { type: 'enabled' },
   *   });
   * ```
   */
  update(body, options) {
    return this._client.post("/v1/organizations/compliance_settings", { body, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/organization/external-keys.mjs
var ExternalKeys2 = class extends APIResource {
  /**
   * Create an external key config owned by the caller's organization.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.organization.externalKeys.create({
   *     provider_config: {
   *       kms_arn:
   *         'arn:aws:kms:us-east-1:111122223333:key/abcd1234-5678-90ab-cdef-000011112222',
   *       type: 'aws',
   *     },
   *   });
   * ```
   */
  create(body, options) {
    return this._client.post("/v1/organizations/external_keys", { body, ...options });
  }
  /**
   * Retrieve a single external key config in the caller's organization by ID.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.organization.externalKeys.retrieve(
   *     'external_key_id',
   *   );
   * ```
   */
  retrieve(externalKeyID, options) {
    return this._client.get(path2`/v1/organizations/external_keys/${externalKeyID}`, options);
  }
  /**
   * Partially update an external key config. Omitted fields are left unchanged.
   *
   * `display_name` is always editable. `geo` and `provider_config` cannot be changed
   * once any workspace references this config, because previously encrypted data
   * requires the original key identity to decrypt.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.organization.externalKeys.update(
   *     'external_key_id',
   *   );
   * ```
   */
  update(externalKeyID, body, options) {
    return this._client.post(path2`/v1/organizations/external_keys/${externalKeyID}`, { body, ...options });
  }
  /**
   * List external key configs in the caller's organization.
   *
   * Results are ordered by creation time (newest first). Use the `next_page` cursor
   * from the response to fetch subsequent pages.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const externalKey of client.organization.externalKeys.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/external_keys", PageCursor, {
      query,
      ...options
    });
  }
  /**
   * Delete an external key config.
   *
   * The request is rejected if any workspace still references this config.
   *
   * @example
   * ```ts
   * const externalKey =
   *   await client.organization.externalKeys.delete(
   *     'external_key_id',
   *   );
   * ```
   */
  delete(externalKeyID, options) {
    return this._client.delete(path2`/v1/organizations/external_keys/${externalKeyID}`, options);
  }
  /**
   * Validate an external key config against the customer's KMS.
   *
   * Anthropic performs an encrypt/decrypt roundtrip against the configured KMS key
   * and waits up to 30 seconds for the result. The response status is `success` if
   * the roundtrip succeeded, or `failure` with an error message if it failed or
   * timed out.
   *
   * @example
   * ```ts
   * const response =
   *   await client.organization.externalKeys.validate(
   *     'external_key_id',
   *   );
   * ```
   */
  validate(externalKeyID, options) {
    return this._client.post(path2`/v1/organizations/external_keys/${externalKeyID}/validate`, options);
  }
};

// node_modules/@anthropic-ai/sdk/resources/organization/invites.mjs
var Invites2 = class extends APIResource {
  /**
   * Invite a user to join the organization by email.
   *
   * On plans that draw members from a finite pool of purchased seats, the invite
   * automatically consumes a seat from the lowest tier with availability; there is
   * no seat-tier parameter. When no seat is free the request fails with a 400 error
   * rather than purchasing a seat.
   *
   * @example
   * ```ts
   * const organizationInvite =
   *   await client.organization.invites.create({
   *     email: 'user@emaildomain.com',
   *     role: 'user',
   *   });
   * ```
   */
  create(body, options) {
    return this._client.post("/v1/organizations/invites", { body, ...options });
  }
  /**
   * Retrieve an invite by ID.
   *
   * @example
   * ```ts
   * const organizationInvite =
   *   await client.organization.invites.retrieve('invite_id');
   * ```
   */
  retrieve(inviteID, options) {
    return this._client.get(path2`/v1/organizations/invites/${inviteID}`, options);
  }
  /**
   * List the organization's invites.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const organizationInvite of client.organization.invites.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/invites", Page, {
      query,
      ...options
    });
  }
  /**
   * Delete a pending invite.
   *
   * @example
   * ```ts
   * const invite = await client.organization.invites.delete(
   *   'invite_id',
   * );
   * ```
   */
  delete(inviteID, options) {
    return this._client.delete(path2`/v1/organizations/invites/${inviteID}`, options);
  }
};

// node_modules/@anthropic-ai/sdk/resources/organization/rate-limits.mjs
var RateLimits3 = class extends APIResource {
  /**
   * List Messages API rate limits for your organization.
   *
   * Each entry corresponds to one rate-limit group (either a model family or an
   * API-surface category such as the Message Batches API or the web search tool) and
   * contains the set of limiter values that apply to it.
   *
   * When `limit` is omitted, every matching entry is returned in a single page; when
   * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const organizationRateLimit of client.organization.rateLimits.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/rate_limits", PageCursor, {
      query,
      ...options
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/organization/users.mjs
var Users3 = class extends APIResource {
  /**
   * Retrieve a member of the organization by user ID.
   *
   * @example
   * ```ts
   * const organizationUser =
   *   await client.organization.users.retrieve('user_id');
   * ```
   */
  retrieve(userID, options) {
    return this._client.get(path2`/v1/organizations/users/${userID}`, options);
  }
  /**
   * Update a member's organization role.
   *
   * @example
   * ```ts
   * const organizationUser =
   *   await client.organization.users.update('user_id', {
   *     role: 'user',
   *   });
   * ```
   */
  update(userID, body, options) {
    return this._client.post(path2`/v1/organizations/users/${userID}`, { body, ...options });
  }
  /**
   * List the organization's members.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const organizationUser of client.organization.users.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/users", Page, { query, ...options });
  }
  /**
   * Remove a member from the organization.
   *
   * @example
   * ```ts
   * const user = await client.organization.users.remove(
   *   'user_id',
   * );
   * ```
   */
  remove(userID, options) {
    return this._client.delete(path2`/v1/organizations/users/${userID}`, options);
  }
};

// node_modules/@anthropic-ai/sdk/resources/organization/federation/issuers.mjs
var Issuers2 = class extends APIResource {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Register an OIDC issuer that Anthropic will trust for workload identity
   * federation in your organization.
   *
   * The `jwks` field controls how the issuer's signing keys are obtained and takes
   * one of three shapes selected by `type`: `discovery` (resolve keys through OIDC
   * discovery), `explicit_url` (fetch keys from a fixed JWKS URL), or `inline`
   * (provide a static key set). When `jwks.type` is `discovery` and no
   * `discovery_base` is set, the issuer URL must be publicly reachable over HTTPS so
   * Anthropic can fetch the discovery document; for `explicit_url` and `inline`
   * modes the issuer URL is only matched as the JWT's `iss` claim and is not
   * fetched.
   *
   * @example
   * ```ts
   * const federationIssuer =
   *   await client.organization.federation.issuers.create({
   *     issuer_url: 'x',
   *     name: 'x',
   *   });
   * ```
   */
  create(body, options) {
    return this._client.post("/v1/organizations/federation_issuers", { body, ...options });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Retrieve a federation issuer by its ID (`fdis_...`).
   *
   * @example
   * ```ts
   * const federationIssuer =
   *   await client.organization.federation.issuers.retrieve(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  retrieve(federationIssuerID, options) {
    return this._client.get(path2`/v1/organizations/federation_issuers/${federationIssuerID}`, options);
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Partially update a federation issuer.
   *
   * Setting `jwks` replaces the full JWKS shape at once. Archived issuers cannot be
   * updated; this returns 400. Create a new issuer instead.
   *
   * Updating an issuer that backs a rule with a scope outside `workspace:developer`
   * or `workspace:inference` requires a Console session.
   *
   * @example
   * ```ts
   * const federationIssuer =
   *   await client.organization.federation.issuers.update(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  update(federationIssuerID, body, options) {
    return this._client.post(path2`/v1/organizations/federation_issuers/${federationIssuerID}`, {
      body,
      ...options
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List federation issuers in your organization.
   *
   * Archived issuers are excluded unless `include_archived=true`.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const federationIssuer of client.organization.federation.issuers.list()) {
   *   // ...
   * }
   * ```
   */
  list(query = {}, options) {
    return this._client.getAPIList("/v1/organizations/federation_issuers", PageCursor, {
      query,
      ...options
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Archive a federation issuer.
   *
   * Idempotent; re-archiving returns the issuer with its original `archived_at`.
   * Rejected with 400 if any live (non-archived) federation rule still references
   * the issuer; archive those rules first (a rule's issuer cannot be changed), or
   * recreate them against another issuer.
   *
   * @example
   * ```ts
   * const federationIssuer =
   *   await client.organization.federation.issuers.archive(
   *     'federation_issuer_id',
   *   );
   * ```
   */
  archive(federationIssuerID, options) {
    return this._client.post(path2`/v1/organizations/federation_issuers/${federationIssuerID}/archive`, options);
  }
};

// node_modules/@anthropic-ai/sdk/resources/organization/federation/rules/workspaces.mjs
var Workspaces4 = class extends APIResource {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List workspaces where this federation rule is enabled.
   *
   * Returns all workspace enablements in a single response; the `limit` and `page`
   * parameters are accepted but have no effect, and `next_page` is always `null`.
   * Returns explicit per-workspace enablements only; for rules with
   * `applies_to_all_workspaces` or a legacy single `workspace_id`, check those
   * fields on the rule itself.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const federationRuleWorkspace of client.organization.federation.rules.workspaces.list(
   *   'federation_rule_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(federationRuleID, query = {}, options) {
    return this._client.getAPIList(path2`/v1/organizations/federation_rules/${federationRuleID}/workspaces`, PageCursor, { query, ...options });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Enable a federation rule for a workspace.
   *
   * Idempotent; re-enabling returns the existing enablement. The rule and workspace
   * must both belong to your organization. Membership of the rule's target service
   * account in this workspace is not checked at enablement: token exchange into this
   * workspace is rejected unless the target is a member (it is implicitly a member
   * of the default workspace). Archived rules are rejected with 400. OAuth callers
   * may only manage rules whose `oauth_scope` is `workspace:developer` or
   * `workspace:inference`; other scopes require a Console session.
   *
   * @example
   * ```ts
   * const federationRuleWorkspace =
   *   await client.organization.federation.rules.workspaces.add(
   *     'federation_rule_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  add(federationRuleID, body, options) {
    return this._client.post(path2`/v1/organizations/federation_rules/${federationRuleID}/workspaces`, {
      body,
      ...options
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Disable a federation rule for a workspace.
   *
   * Idempotent; succeeds even if the enablement was already removed. OAuth callers
   * may only manage rules whose `oauth_scope` is `workspace:developer` or
   * `workspace:inference`; other scopes require a Console session.
   *
   * @example
   * ```ts
   * const workspace =
   *   await client.organization.federation.rules.workspaces.remove(
   *     'workspace_id',
   *     { federation_rule_id: 'federation_rule_id' },
   *   );
   * ```
   */
  remove(workspaceID, params, options) {
    const { federation_rule_id } = params;
    return this._client.delete(path2`/v1/organizations/federation_rules/${federation_rule_id}/workspaces/${workspaceID}`, options);
  }
};

// node_modules/@anthropic-ai/sdk/resources/organization/federation/rules/rules.mjs
var Rules2 = /* @__PURE__ */ (() => {
  class Rules3 extends APIResource {
    constructor() {
      super(...arguments);
      this.workspaces = new Workspaces4(this._client);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Create a federation rule owned by your organization.
     *
     * The referenced issuer and the target service account must already exist in the
     * same organization; invalid references are rejected with a 400 error. The
     * workspace reference is validated. Membership is not checked at rule creation:
     * token exchange resolves a single enabled workspace per call and is rejected
     * unless the target service account is a member of that workspace (it is
     * implicitly a member of the default workspace). Rules on well-known shared
     * issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud, Google) must
     * constrain tenant identity via an identity-bearing claim, a tenant-pinning
     * subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition referencing one
     * of those identity claims (e.g. `claims.repository_owner`). OAuth callers may
     * only manage rules whose `oauth_scope` is `workspace:developer` or
     * `workspace:inference`; other scopes require a Console session.
     *
     * @example
     * ```ts
     * const federationRule =
     *   await client.organization.federation.rules.create({
     *     issuer_id: 'issuer_id',
     *     match: {},
     *     name: 'x',
     *     oauth_scope: 'x',
     *     target: {
     *       service_account_id: 'svac_01SDCCSbTxrXDpWc1phhtcfK',
     *       type: 'service_account',
     *     },
     *   });
     * ```
     */
    create(body, options) {
      return this._client.post("/v1/organizations/federation_rules", { body, ...options });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Retrieve a federation rule by its ID (`fdrl_...`).
     *
     * @example
     * ```ts
     * const federationRule =
     *   await client.organization.federation.rules.retrieve(
     *     'federation_rule_id',
     *   );
     * ```
     */
    retrieve(federationRuleID, options) {
      return this._client.get(path2`/v1/organizations/federation_rules/${federationRuleID}`, options);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Partially update a federation rule.
     *
     * `issuer_id` is immutable. `match` and `target` are replaced as whole objects
     * when set. Referenced service accounts and workspaces must exist in your
     * organization; invalid references are rejected with a 400 error. Archived rules
     * cannot be updated; this returns 400. Create a new rule instead. Rules on
     * well-known shared issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud,
     * Google) must constrain tenant identity via an identity-bearing claim, a
     * tenant-pinning subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition
     * referencing one of those identity claims (e.g. `claims.repository_owner`). On
     * these issuers the requirement is re-checked on every update; if an existing
     * rule's stored match does not yet constrain tenant identity, any update (even a
     * rename or description change) must also supply a conforming `match` in the same
     * request. OAuth callers may only manage rules whose `oauth_scope` is
     * `workspace:developer` or `workspace:inference`; other scopes require a Console
     * session.
     *
     * @example
     * ```ts
     * const federationRule =
     *   await client.organization.federation.rules.update(
     *     'federation_rule_id',
     *   );
     * ```
     */
    update(federationRuleID, body, options) {
      return this._client.post(path2`/v1/organizations/federation_rules/${federationRuleID}`, {
        body,
        ...options
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * List federation rules in your organization.
     *
     * Optionally filter by issuer with `issuer_id`. Archived rules are excluded unless
     * `include_archived=true`.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const federationRule of client.organization.federation.rules.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
      return this._client.getAPIList("/v1/organizations/federation_rules", PageCursor, {
        query,
        ...options
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Archive a federation rule.
     *
     * Token exchange through this rule stops immediately. Idempotent; re-archiving
     * returns the rule with its original `archived_at`. Archiving clears the rule's
     * workspace targeting (`workspace_id` and `workspace_ids` are emptied). Tokens
     * already minted before archive remain valid until they expire. OAuth callers may
     * only manage rules whose `oauth_scope` is `workspace:developer` or
     * `workspace:inference`; other scopes require a Console session.
     *
     * @example
     * ```ts
     * const federationRule =
     *   await client.organization.federation.rules.archive(
     *     'federation_rule_id',
     *   );
     * ```
     */
    archive(federationRuleID, options) {
      return this._client.post(path2`/v1/organizations/federation_rules/${federationRuleID}/archive`, options);
    }
  }
  Rules3.Workspaces = Workspaces4;
  return Rules3;
})();

// node_modules/@anthropic-ai/sdk/resources/organization/federation/federation.mjs
var Federation2 = /* @__PURE__ */ (() => {
  class Federation3 extends APIResource {
    constructor() {
      super(...arguments);
      this.issuers = new Issuers2(this._client);
      this.rules = new Rules2(this._client);
    }
  }
  Federation3.Issuers = Issuers2;
  Federation3.Rules = Rules2;
  return Federation3;
})();

// node_modules/@anthropic-ai/sdk/resources/organization/service-accounts/workspaces.mjs
var Workspaces5 = class extends APIResource {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List the workspaces a service account is a member of.
   *
   * Each entry includes the service account's `workspace_role` in that workspace.
   * Use `limit` and the `next_page` cursor to paginate. When the service account has
   * no explicit default-workspace membership, the implicit (`implicit: true`)
   * membership is returned as the first entry on the first page; with `limit=1` the
   * first page may return up to 2 entries (the implicit entry plus one explicit
   * membership) so a pagination cursor can be derived. Memberships are returned only
   * while the service account is active. Without a `page` cursor, an archived
   * service account returns an empty list. A `page` cursor that does not match an
   * active membership returns a 400 invalid-request error. A cursor stops matching
   * when the membership is removed, the workspace is deleted, or the service account
   * is archived. Restart pagination from the first page to recover.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const serviceAccountWorkspaceMember of client.organization.serviceAccounts.workspaces.list(
   *   'service_account_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(serviceAccountID, query = {}, options) {
    return this._client.getAPIList(path2`/v1/organizations/service_accounts/${serviceAccountID}/workspaces`, PageCursor, { query, ...options });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Add a service account to a workspace with the given `workspace_role`.
   *
   * Mirror of `POST /workspaces/{workspace_id}/service_accounts`, addressed from the
   * service-account side; both create the same membership. If the service account is
   * already an explicit member of the workspace, its `workspace_role` is replaced
   * with the value supplied here. Archived workspaces return 400. Archived service
   * accounts cannot be added and are rejected.
   *
   * @example
   * ```ts
   * const serviceAccountWorkspaceMember =
   *   await client.organization.serviceAccounts.workspaces.add(
   *     'service_account_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(serviceAccountID, body, options) {
    return this._client.post(path2`/v1/organizations/service_accounts/${serviceAccountID}/workspaces`, {
      body,
      ...options
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Remove a service account from a workspace.
   *
   * Mirror of
   * `DELETE /workspaces/{workspace_id}/service_accounts/{service_account_id}`,
   * addressed from the service-account side. Removal is idempotent (returns 200 even
   * if the membership was already removed). A DELETE against the implicit
   * default-workspace membership returns 200 but is a no-op and the membership
   * persists; deleting an explicit default-workspace row reverts to the implicit
   * `workspace_user` membership. Archived workspaces return 400.
   *
   * @example
   * ```ts
   * const workspace =
   *   await client.organization.serviceAccounts.workspaces.remove(
   *     'workspace_id',
   *     { service_account_id: 'service_account_id' },
   *   );
   * ```
   */
  remove(workspaceID, params, options) {
    const { service_account_id } = params;
    return this._client.delete(path2`/v1/organizations/service_accounts/${service_account_id}/workspaces/${workspaceID}`, options);
  }
};

// node_modules/@anthropic-ai/sdk/resources/organization/service-accounts/service-accounts.mjs
var ServiceAccounts3 = /* @__PURE__ */ (() => {
  class ServiceAccounts5 extends APIResource {
    constructor() {
      super(...arguments);
      this.workspaces = new Workspaces5(this._client);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Create a service account.
     *
     * A service account is a named workload identity that federation rules target.
     * `organization_role` is `developer` (default) or `admin`; a rule may only be
     * created or retargeted to grant `org:admin` scope when the target's
     * `organization_role` is `admin`. Creating an `admin`-role service account
     * requires an interactive credential (a user OAuth token or a Console session) — a
     * workload may only create `developer`-role service accounts.
     *
     * @example
     * ```ts
     * const serviceAccount =
     *   await client.organization.serviceAccounts.create({
     *     name: 'ci-deploy-bot',
     *   });
     * ```
     */
    create(body, options) {
      return this._client.post("/v1/organizations/service_accounts", { body, ...options });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Retrieve a service account by its ID (`svac_...`).
     *
     * @example
     * ```ts
     * const serviceAccount =
     *   await client.organization.serviceAccounts.retrieve(
     *     'service_account_id',
     *   );
     * ```
     */
    retrieve(serviceAccountID, options) {
      return this._client.get(path2`/v1/organizations/service_accounts/${serviceAccountID}`, options);
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Update a service account.
     *
     * Only `description` and `organization_role` are mutable; `name` cannot be
     * changed. Archived service accounts cannot be updated; this returns 400. Setting
     * `organization_role` to `admin` (even when unchanged) requires an interactive
     * credential (a user OAuth token or a Console session).
     *
     * @example
     * ```ts
     * const serviceAccount =
     *   await client.organization.serviceAccounts.update(
     *     'service_account_id',
     *   );
     * ```
     */
    update(serviceAccountID, body, options) {
      return this._client.post(path2`/v1/organizations/service_accounts/${serviceAccountID}`, {
        body,
        ...options
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * List service accounts in the caller's organization.
     *
     * Results are ordered by creation time, newest first. Use `limit` and the
     * `next_page` cursor to paginate; set `include_archived=true` to include archived
     * service accounts.
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const serviceAccount of client.organization.serviceAccounts.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
      return this._client.getAPIList("/v1/organizations/service_accounts", PageCursor, {
        query,
        ...options
      });
    }
    /**
     * **Requires an OAuth access token with the `org:admin` scope**, from
     * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
     * API keys are not accepted. See
     * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
     *
     * Archive a service account.
     *
     * Idempotent; re-archiving returns the service account with its original
     * `archived_at`. Rejected with 400 if any live (non-archived) federation rule
     * still targets this service account, same as issuer archival; archive those rules
     * first or change their target to another service account.
     *
     * @example
     * ```ts
     * const serviceAccount =
     *   await client.organization.serviceAccounts.archive(
     *     'service_account_id',
     *   );
     * ```
     */
    archive(serviceAccountID, options) {
      return this._client.post(path2`/v1/organizations/service_accounts/${serviceAccountID}/archive`, options);
    }
  }
  ServiceAccounts5.Workspaces = Workspaces5;
  return ServiceAccounts5;
})();

// node_modules/@anthropic-ai/sdk/resources/organization/workspaces/members.mjs
var Members3 = class extends APIResource {
  /**
   * Get Workspace Member
   *
   * @example
   * ```ts
   * const workspaceMember =
   *   await client.organization.workspaces.members.retrieve(
   *     'user_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  retrieve(userID, params, options) {
    const { workspace_id } = params;
    return this._client.get(path2`/v1/organizations/workspaces/${workspace_id}/members/${userID}`, options);
  }
  /**
   * Update Workspace Member
   *
   * @example
   * ```ts
   * const workspaceMember =
   *   await client.organization.workspaces.members.update(
   *     'user_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  update(userID, params, options) {
    const { workspace_id, ...body } = params;
    return this._client.post(path2`/v1/organizations/workspaces/${workspace_id}/members/${userID}`, {
      body,
      ...options
    });
  }
  /**
   * List Workspace Members
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const workspaceMember of client.organization.workspaces.members.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(workspaceID, query = {}, options) {
    return this._client.getAPIList(path2`/v1/organizations/workspaces/${workspaceID}/members`, Page, { query, ...options });
  }
  /**
   * Create Workspace Member
   *
   * @example
   * ```ts
   * const workspaceMember =
   *   await client.organization.workspaces.members.add(
   *     'workspace_id',
   *     {
   *       user_id: 'user_01WCz1FkmYMm4gnmykNKUu3Q',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(workspaceID, body, options) {
    return this._client.post(path2`/v1/organizations/workspaces/${workspaceID}/members`, { body, ...options });
  }
  /**
   * Delete Workspace Member
   *
   * @example
   * ```ts
   * const member =
   *   await client.organization.workspaces.members.remove(
   *     'user_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  remove(userID, params, options) {
    const { workspace_id } = params;
    return this._client.delete(path2`/v1/organizations/workspaces/${workspace_id}/members/${userID}`, options);
  }
};

// node_modules/@anthropic-ai/sdk/resources/organization/workspaces/rate-limits.mjs
var RateLimits4 = class extends APIResource {
  /**
   * List a workspace's rate limits.
   *
   * By default, returns only the groups and limiter types that have a
   * workspace-level override. With `include_inherited=true`, returns every group
   * with organization-level limits the workspace can see, listing for each the
   * values it inherits from the organization as well as its own overrides. Each
   * value's `source` says which it is.
   *
   * When `limit` is omitted, every matching entry is returned in a single page; when
   * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const workspaceRateLimit of client.organization.workspaces.rateLimits.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(workspaceID, query = {}, options) {
    return this._client.getAPIList(path2`/v1/organizations/workspaces/${workspaceID}/rate_limits`, PageCursor, { query, ...options });
  }
};

// node_modules/@anthropic-ai/sdk/resources/organization/workspaces/service-accounts.mjs
var ServiceAccounts4 = class extends APIResource {
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Retrieve a service account's membership in a workspace.
   *
   * Returns the membership record, including the service account's `workspace_role`
   * in this workspace. Archived workspaces return 400. For the default workspace,
   * returns the implicit (`implicit: true`) membership when no explicit membership
   * exists; an explicitly added membership is returned with its assigned role. An
   * archived service account returns 404.
   *
   * @example
   * ```ts
   * const serviceAccountWorkspaceMember =
   *   await client.organization.workspaces.serviceAccounts.retrieve(
   *     'service_account_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  retrieve(serviceAccountID, params, options) {
    const { workspace_id } = params;
    return this._client.get(path2`/v1/organizations/workspaces/${workspace_id}/service_accounts/${serviceAccountID}`, options);
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Change a service account's role in a workspace.
   *
   * The new `workspace_role` replaces the current one. Only explicit memberships can
   * be updated; to set a role on the implicit default-workspace membership, add the
   * service account explicitly with
   * `POST /workspaces/{workspace_id}/service_accounts`. Archived workspaces
   * return 400. Archived service accounts cannot be updated and are rejected.
   *
   * @example
   * ```ts
   * const serviceAccountWorkspaceMember =
   *   await client.organization.workspaces.serviceAccounts.update(
   *     'service_account_id',
   *     {
   *       workspace_id: 'workspace_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  update(serviceAccountID, params, options) {
    const { workspace_id, ...body } = params;
    return this._client.post(path2`/v1/organizations/workspaces/${workspace_id}/service_accounts/${serviceAccountID}`, { body, ...options });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * List the service accounts that are members of a workspace.
   *
   * Each entry includes the service account's `workspace_role`. Use `limit` and the
   * `next_page` cursor to paginate. Archived workspaces return 400; use
   * `GET /service_accounts/{id}/workspaces` to audit memberships of an archived
   * workspace. The implicit default-workspace membership is not included in this
   * list. Memberships of archived service accounts are omitted from the results.
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const serviceAccountWorkspaceMember of client.organization.workspaces.serviceAccounts.list(
   *   'workspace_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(workspaceID, query = {}, options) {
    return this._client.getAPIList(path2`/v1/organizations/workspaces/${workspaceID}/service_accounts`, PageCursor, { query, ...options });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Add a service account to a workspace with the given `workspace_role`.
   *
   * The role determines what the service account can do in the workspace and which
   * workspace-scoped permissions it can be granted when authenticating through
   * federation. Every service account is already an implicit `workspace_user` member
   * of the default workspace; adding it explicitly assigns a chosen role. If the
   * service account is already an explicit member of the workspace, its
   * `workspace_role` is replaced with the value supplied here. Archived workspaces
   * return 400. Archived service accounts cannot be added and are rejected.
   *
   * @example
   * ```ts
   * const serviceAccountWorkspaceMember =
   *   await client.organization.workspaces.serviceAccounts.add(
   *     'workspace_id',
   *     {
   *       service_account_id: 'service_account_id',
   *       workspace_role: 'workspace_admin',
   *     },
   *   );
   * ```
   */
  add(workspaceID, body, options) {
    return this._client.post(path2`/v1/organizations/workspaces/${workspaceID}/service_accounts`, {
      body,
      ...options
    });
  }
  /**
   * **Requires an OAuth access token with the `org:admin` scope**, from
   * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
   * API keys are not accepted. See
   * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
   *
   * Remove a service account from a workspace.
   *
   * Removal is idempotent (returns 200 even if the membership was already removed).
   * A DELETE against the implicit default-workspace membership returns 200 but is a
   * no-op and the membership persists; deleting an explicit default-workspace row
   * reverts to the implicit `workspace_user` membership. Archived workspaces
   * return 400.
   *
   * @example
   * ```ts
   * const serviceAccount =
   *   await client.organization.workspaces.serviceAccounts.remove(
   *     'service_account_id',
   *     { workspace_id: 'workspace_id' },
   *   );
   * ```
   */
  remove(serviceAccountID, params, options) {
    const { workspace_id } = params;
    return this._client.delete(path2`/v1/organizations/workspaces/${workspace_id}/service_accounts/${serviceAccountID}`, options);
  }
};

// node_modules/@anthropic-ai/sdk/resources/organization/workspaces/workspaces.mjs
var Workspaces6 = /* @__PURE__ */ (() => {
  class Workspaces7 extends APIResource {
    constructor() {
      super(...arguments);
      this.rateLimits = new RateLimits4(this._client);
      this.members = new Members3(this._client);
      this.serviceAccounts = new ServiceAccounts4(this._client);
    }
    /**
     * Create Workspace
     *
     * @example
     * ```ts
     * const workspace =
     *   await client.organization.workspaces.create({
     *     name: 'x',
     *   });
     * ```
     */
    create(body, options) {
      return this._client.post("/v1/organizations/workspaces", { body, ...options });
    }
    /**
     * Get Workspace
     *
     * @example
     * ```ts
     * const workspace =
     *   await client.organization.workspaces.retrieve(
     *     'workspace_id',
     *   );
     * ```
     */
    retrieve(workspaceID, options) {
      return this._client.get(path2`/v1/organizations/workspaces/${workspaceID}`, options);
    }
    /**
     * Update Workspace
     *
     * @example
     * ```ts
     * const workspace =
     *   await client.organization.workspaces.update(
     *     'workspace_id',
     *   );
     * ```
     */
    update(workspaceID, body, options) {
      return this._client.post(path2`/v1/organizations/workspaces/${workspaceID}`, { body, ...options });
    }
    /**
     * List Workspaces
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const workspace of client.organization.workspaces.list()) {
     *   // ...
     * }
     * ```
     */
    list(query = {}, options) {
      return this._client.getAPIList("/v1/organizations/workspaces", Page, { query, ...options });
    }
    /**
     * Archive Workspace
     *
     * @example
     * ```ts
     * const workspace =
     *   await client.organization.workspaces.archive(
     *     'workspace_id',
     *   );
     * ```
     */
    archive(workspaceID, options) {
      return this._client.post(path2`/v1/organizations/workspaces/${workspaceID}/archive`, options);
    }
  }
  Workspaces7.RateLimits = RateLimits4;
  Workspaces7.Members = Members3;
  Workspaces7.ServiceAccounts = ServiceAccounts4;
  return Workspaces7;
})();

// node_modules/@anthropic-ai/sdk/resources/organization/organization.mjs
var Organization2 = /* @__PURE__ */ (() => {
  class Organization3 extends APIResource {
    constructor() {
      super(...arguments);
      this.apiKeys = new APIKeys2(this._client);
      this.externalKeys = new ExternalKeys2(this._client);
      this.federation = new Federation2(this._client);
      this.invites = new Invites2(this._client);
      this.serviceAccounts = new ServiceAccounts3(this._client);
      this.users = new Users3(this._client);
      this.workspaces = new Workspaces6(this._client);
      this.rateLimits = new RateLimits3(this._client);
      this.complianceSettings = new ComplianceSettings2(this._client);
    }
    /**
     * Retrieve information about the organization associated with the authenticated
     * API key.
     *
     * @example
     * ```ts
     * const organizationInfo =
     *   await client.organization.retrieve();
     * ```
     */
    retrieve(options) {
      return this._client.get("/v1/organizations/me", options);
    }
  }
  Organization3.APIKeys = APIKeys2;
  Organization3.ExternalKeys = ExternalKeys2;
  Organization3.Federation = Federation2;
  Organization3.Invites = Invites2;
  Organization3.ServiceAccounts = ServiceAccounts3;
  Organization3.Users = Users3;
  Organization3.Workspaces = Workspaces6;
  Organization3.RateLimits = RateLimits3;
  Organization3.ComplianceSettings = ComplianceSettings2;
  return Organization3;
})();

// node_modules/@anthropic-ai/sdk/resources/skills/versions.mjs
var Versions4 = class extends APIResource {
  /**
   * Create Skill Version
   *
   * @example
   * ```ts
   * const skillVersion = await client.skills.versions.create(
   *   'skill_id',
   *   { files: [fs.createReadStream('path/to/file')] },
   * );
   * ```
   */
  create(skillID, params, options) {
    const { workspace_id, ...body } = params;
    return this._client.post(path2`/v1/skills/${skillID}/versions`, multipartFormRequestOptions({
      body,
      ...options,
      headers: buildHeaders([
        { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
        options?.headers
      ])
    }, this._client, false));
  }
  /**
   * Get Skill Version
   *
   * @example
   * ```ts
   * const skillVersion = await client.skills.versions.retrieve(
   *   'version',
   *   { skill_id: 'skill_id' },
   * );
   * ```
   */
  retrieve(version, params, options) {
    const { skill_id, workspace_id } = params;
    return this._client.get(path2`/v1/skills/${skill_id}/versions/${version}`, {
      ...options,
      headers: buildHeaders([
        { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * List Skill Versions
   *
   * @example
   * ```ts
   * // Automatically fetches more pages as needed.
   * for await (const skillVersion of client.skills.versions.list(
   *   'skill_id',
   * )) {
   *   // ...
   * }
   * ```
   */
  list(skillID, params = {}, options) {
    const { workspace_id, ...query } = params ?? {};
    return this._client.getAPIList(path2`/v1/skills/${skillID}/versions`, PageCursor, {
      query,
      ...options,
      headers: buildHeaders([
        { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
        options?.headers
      ])
    });
  }
  /**
   * Delete Skill Version
   *
   * @example
   * ```ts
   * const deletedSkillVersion =
   *   await client.skills.versions.delete('version', {
   *     skill_id: 'skill_id',
   *   });
   * ```
   */
  delete(version, params, options) {
    const { skill_id, workspace_id } = params;
    return this._client.delete(path2`/v1/skills/${skill_id}/versions/${version}`, {
      ...options,
      headers: buildHeaders([
        { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
        options?.headers
      ])
    });
  }
};

// node_modules/@anthropic-ai/sdk/resources/skills/skills.mjs
var Skills3 = /* @__PURE__ */ (() => {
  class Skills4 extends APIResource {
    constructor() {
      super(...arguments);
      this.versions = new Versions4(this._client);
    }
    /**
     * Create Skill
     *
     * @example
     * ```ts
     * const skill = await client.skills.create({
     *   files: [fs.createReadStream('path/to/file')],
     * });
     * ```
     */
    create(params, options) {
      const { workspace_id, ...body } = params;
      return this._client.post("/v1/skills", multipartFormRequestOptions({
        body,
        ...options,
        headers: buildHeaders([
          { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
          options?.headers
        ])
      }, this._client, false));
    }
    /**
     * Get Skill
     *
     * @example
     * ```ts
     * const skill = await client.skills.retrieve('skill_id');
     * ```
     */
    retrieve(skillID, params = {}, options) {
      const { workspace_id } = params ?? {};
      return this._client.get(path2`/v1/skills/${skillID}`, {
        ...options,
        headers: buildHeaders([
          { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
          options?.headers
        ])
      });
    }
    /**
     * List Skills
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const skill of client.skills.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
      const { workspace_id, ...query } = params ?? {};
      return this._client.getAPIList("/v1/skills", PageCursor, {
        query,
        ...options,
        headers: buildHeaders([
          { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
          options?.headers
        ])
      });
    }
    /**
     * Delete Skill
     *
     * @example
     * ```ts
     * const deletedSkill = await client.skills.delete('skill_id');
     * ```
     */
    delete(skillID, params = {}, options) {
      const { workspace_id } = params ?? {};
      return this._client.delete(path2`/v1/skills/${skillID}`, {
        ...options,
        headers: buildHeaders([
          { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
          options?.headers
        ])
      });
    }
  }
  Skills4.Versions = Versions4;
  return Skills4;
})();

// node_modules/@anthropic-ai/sdk/client.mjs
var _BaseAnthropic_instances;
var _a;
var _BaseAnthropic_encoder;
var _BaseAnthropic_baseURLOverridden;
var HUMAN_PROMPT = "\\n\\nHuman:";
var AI_PROMPT = "\\n\\nAssistant:";
var BaseAnthropic = /* @__PURE__ */ (() => {
  class BaseAnthropic2 {
    /**
     * The active credential provider. Default credential resolution runs once
     * at construction time. If it fails, the error is surfaced on every
     * request and the client must be reconstructed — there is no retry path.
     *
     * Clones returned by {@link withOptions} share the parent's auth state
     * (provider, token cache, pending resolution, and any resolution error)
     * unless the caller passes an explicit `apiKey`, `authToken`,
     * `credentials`, `config`, or `profile` override.
     */
    get credentials() {
      return this._authState.provider;
    }
    /**
     * API Client for interfacing with the Anthropic API.
     *
     * @param {string | null | undefined} [opts.apiKey=process.env['ANTHROPIC_API_KEY'] ?? null]
     * @param {string | null | undefined} [opts.authToken=process.env['ANTHROPIC_AUTH_TOKEN'] ?? null]
     * @param {string | null | undefined} [opts.webhookKey=process.env['ANTHROPIC_WEBHOOK_SIGNING_KEY'] ?? null]
     * @param {string} [opts.baseURL=process.env['ANTHROPIC_BASE_URL'] ?? https://api.anthropic.com] - Override the default base URL for the API.
     * @param {number} [opts.timeout=10 minutes] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
     * @param {MergedRequestInit} [opts.fetchOptions] - Additional `RequestInit` options to be passed to `fetch` calls.
     * @param {Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
     * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
     * @param {HeadersLike} opts.defaultHeaders - Default headers to include with every request to the API.
     * @param {Record<string, string | undefined>} opts.defaultQuery - Default query parameters to include with every request to the API.
     * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
     */
    constructor({ baseURL = readEnv("ANTHROPIC_BASE_URL"), apiKey, authToken, webhookKey = readEnv("ANTHROPIC_WEBHOOK_SIGNING_KEY") ?? null, ...opts } = {}) {
      _BaseAnthropic_instances.add(this);
      this._requestAuthFlags = /* @__PURE__ */ new WeakMap();
      _BaseAnthropic_encoder.set(this, void 0);
      if (apiKey === void 0) {
        apiKey = opts.profile != null ? null : readEnv("ANTHROPIC_API_KEY") ?? null;
      }
      if (authToken === void 0) {
        authToken = opts.profile != null ? null : readEnv("ANTHROPIC_AUTH_TOKEN") ?? null;
      }
      if (opts.profile != null && (opts.credentials != null || opts.config != null)) {
        throw new TypeError("Pass at most one of `profile`, `credentials`, or `config`.");
      }
      const options = {
        apiKey,
        authToken,
        webhookKey,
        ...opts,
        baseURL: baseURL || `https://api.anthropic.com`
      };
      if (!options.dangerouslyAllowBrowser && isRunningInBrowser()) {
        throw new AnthropicError("It looks like you're running in a browser-like environment.\n\nThis is disabled by default, as it risks exposing your secret API credentials to attackers.\nIf you understand the risks and have appropriate mitigations in place,\nyou can set the `dangerouslyAllowBrowser` option to `true`, e.g.,\n\nnew Anthropic({ apiKey, dangerouslyAllowBrowser: true });\n");
      }
      this.baseURL = options.baseURL;
      this._baseURLIsExplicit = opts.__baseURLIsExplicit ?? !!baseURL;
      this.timeout = options.timeout ?? _a.DEFAULT_TIMEOUT;
      this.logger = options.logger ?? console;
      this.logLevel = defaultLogLevel;
      this.logLevel = parseLogLevel(options.logLevel, "ClientOptions.logLevel", loggerFor(this)) ?? parseLogLevel(readEnv("ANTHROPIC_LOG"), "process.env['ANTHROPIC_LOG']", loggerFor(this)) ?? defaultLogLevel;
      this.fetchOptions = options.fetchOptions;
      this.maxRetries = validatePositiveInteger("maxRetries", options.maxRetries ?? 2);
      this.fetch = options.fetch ?? getDefaultFetch();
      __classPrivateFieldSet(this, _BaseAnthropic_encoder, FallbackEncoder, "f");
      this.middleware = [...options.middleware ?? []];
      const customHeadersEnv = readEnv("ANTHROPIC_CUSTOM_HEADERS");
      if (customHeadersEnv) {
        const parsed = {};
        for (const line of customHeadersEnv.split("\n")) {
          const colon = line.indexOf(":");
          if (colon >= 0) {
            parsed[line.substring(0, colon).trim()] = line.substring(colon + 1).trim();
          }
        }
        options.defaultHeaders = { ...parsed, ...options.defaultHeaders };
      }
      const inherited = opts.__auth;
      delete options.__auth;
      delete options.__baseURLIsExplicit;
      this._options = options;
      this.apiKey = typeof apiKey === "string" ? apiKey : null;
      this.authToken = authToken;
      this.webhookKey = webhookKey;
      if (inherited) {
        this._authState = inherited;
        if (!this._baseURLIsExplicit && inherited.baseURL) {
          this.baseURL = inherited.baseURL;
        }
      } else {
        this._authState = { provider: null, tokenCache: null, resolution: null, error: null, extraHeaders: {} };
        if (this.apiKey == null && this.authToken == null) {
          const credentials = options.credentials ?? null;
          if (credentials) {
            this._authState.provider = credentials;
            this._authState.tokenCache = this._makeTokenCache(credentials);
          } else if (options.config != null) {
            const result = resolveCredentialsFromConfig(options.config, this._credentialResolverOptions());
            this._authState.provider = result.provider;
            this._authState.tokenCache = this._makeTokenCache(result.provider);
            this._authState.extraHeaders = result.extraHeaders;
            this._applyCredentialBaseURL(result.baseURL);
          } else if (options.profile != null) {
            this._authState.resolution = this._resolveDefaultCredentials(options.profile);
          } else if (this._shouldResolveDefaultCredentials()) {
            this._authState.resolution = this._resolveDefaultCredentials();
          }
        }
      }
    }
    /**
     * Whether to lazily resolve auth from the default credential chain when no
     * explicit auth is configured. Called once from the constructor, so
     * overrides must not depend on subclass instance state. Subclasses that
     * bring their own auth scheme return false so unrelated local credentials
     * are never resolved or allowed to supply a base URL.
     */
    _shouldResolveDefaultCredentials() {
      return true;
    }
    /**
     * Stores a profile/config-supplied base URL on the shared auth state and, if
     * the caller did not pin `baseURL` via constructor option or env, adopts it
     * as this client's outbound API host. Precedence: ctor opt > env > profile >
     * hardcoded default.
     */
    _applyCredentialBaseURL(baseURL) {
      if (!baseURL)
        return;
      const normalized = baseURL.replace(/\/+$/, "");
      this._authState.baseURL = normalized;
      if (!this._baseURLIsExplicit) {
        this.baseURL = normalized;
      }
    }
    /**
     * Options bag passed into the credential chain. `baseURL` here is only the
     * fallback host for the token-exchange POST when the config itself omits
     * `base_url`; the chain returns the config's own `base_url` (if any) on
     * {@link CredentialResult.baseURL}, which {@link _applyCredentialBaseURL}
     * then adopts for outbound API requests. The two are deliberately decoupled
     * so this fallback never round-trips into precedence.
     */
    _credentialResolverOptions() {
      return {
        baseURL: this.baseURL,
        fetch: this._credentialsFetch(),
        userAgent: this.getUserAgent(),
        onCacheWriteError: (err) => {
          loggerFor(this).debug("credential cache write failed (best-effort)", err);
        },
        onSafetyWarning: (msg) => {
          loggerFor(this).warn(msg);
        }
      };
    }
    /**
     * A `Fetch` for first-party credential token-exchange requests (OIDC
     * federation jwt-bearer grants, user-OAuth refresh grants) that routes
     * through this client's middleware chain, so middleware observes token
     * traffic like any other request. Only client-level middleware applies:
     * a minted token is shared across requests, so attributing the exchange
     * to any one request's per-request middleware would be arbitrary. For the
     * same reason, `ctx.options` is undefined for these requests.
     */
    _credentialsFetch() {
      return wrapFetchWithMiddleware(this.fetch, this.middleware, void 0, this);
    }
    _makeTokenCache(provider) {
      return new TokenCache(provider, (err) => {
        loggerFor(this).debug("advisory token refresh failed; serving cached token", err);
      });
    }
    /**
     * Create a new client instance re-using the same options given to the
     * current client with optional overriding.
     */
    withOptions(options) {
      const overridesStructuredAuth = "credentials" in options || "config" in options || "profile" in options;
      const overridesAuth = "apiKey" in options || "authToken" in options || overridesStructuredAuth;
      const internal = {
        ...this._options,
        // Only forward baseURL when the caller (or env) explicitly chose it.
        // For a non-explicit parent, this.baseURL may have been mutated to the
        // profile-resolved host; pinning that as the clone's options.baseURL
        // would make _options on the clone misreport caller intent and would
        // leave the clone stuck on the parent's host across an auth override.
        // The clone instead receives the construction-time value via
        // ...this._options above and re-adopts the profile host through the
        // shared _authState.baseURL + __baseURLIsExplicit=false path.
        ...this._baseURLIsExplicit ? { baseURL: this.baseURL } : {},
        maxRetries: this.maxRetries,
        timeout: this.timeout,
        logger: this.logger,
        logLevel: this.logLevel,
        fetch: this.fetch,
        fetchOptions: this.fetchOptions,
        middleware: this.middleware,
        apiKey: this.apiKey,
        authToken: this.authToken,
        webhookKey: this.webhookKey,
        // credentials: this.credentials is a no-op when __auth is shared (the
        // ctor takes the inherited path and ignores options.credentials); when
        // overridesAuth is true via apiKey/authToken only, it lets the clone
        // build a fresh TokenCache around the parent's provider.
        credentials: this.credentials,
        // When the caller passes a structured-credential override, drop inherited
        // structured-credential options so only `...options` supplies them —
        // otherwise an inherited `credentials`/`config`/`profile` would trip the
        // mutual-exclusion check or precedence over the override.
        ...overridesStructuredAuth ? { credentials: void 0, config: void 0, profile: void 0 } : {},
        ...options,
        // Always set __auth so any stale value from ...this._options is
        // overwritten. undefined means "build fresh auth from these options".
        __auth: overridesAuth ? void 0 : this._authState,
        __baseURLIsExplicit: "baseURL" in options ? true : this._baseURLIsExplicit
      };
      return new this.constructor(internal);
    }
    /**
     * Lazily resolves credentials from config files or environment variables.
     * Called once from the constructor when no explicit auth is provided, or
     * when an explicit `profile` was passed (in which case a missing/unresolved
     * profile is surfaced as an error instead of falling through to "no auth").
     * The returned promise is stored and awaited on the first request.
     */
    async _resolveDefaultCredentials(profile) {
      try {
        const result = await defaultCredentials(this._credentialResolverOptions(), profile);
        if (result) {
          this._authState.provider = result.provider;
          this._authState.tokenCache = this._makeTokenCache(result.provider);
          this._authState.extraHeaders = result.extraHeaders;
          this._applyCredentialBaseURL(result.baseURL);
        } else if (profile != null) {
          throw new AnthropicError(`Profile "${profile}" could not be resolved (no <config_dir>/configs/${profile}.json found).`);
        }
      } catch (err) {
        this._authState.error = err;
      } finally {
        this._authState.resolution = null;
      }
    }
    defaultQuery() {
      return this._options.defaultQuery;
    }
    validateHeaders({ values, nulls }) {
      if (values.get("x-api-key") || values.get("authorization")) {
        return;
      }
      if (this._authState.error) {
        throw this._authState.error;
      }
      if (this._authState.tokenCache || this._authState.resolution) {
        return;
      }
      if (this.apiKey && values.get("x-api-key")) {
        return;
      }
      if (nulls.has("x-api-key")) {
        return;
      }
      if (this.authToken && values.get("authorization")) {
        return;
      }
      if (nulls.has("authorization")) {
        return;
      }
      throw new Error('Could not resolve authentication method. Expected one of apiKey, authToken, credentials, config, or profile to be set. Or for one of the "X-Api-Key" or "Authorization" headers to be explicitly omitted');
    }
    _authFlags(opts) {
      let flags = this._requestAuthFlags.get(opts);
      if (!flags) {
        flags = { usedTokenCache: false, didRefreshFor401: false };
        this._requestAuthFlags.set(opts, flags);
      }
      return flags;
    }
    async authHeaders(opts) {
      if (this._authState.resolution) {
        await this._authState.resolution;
      }
      if (this._authState.error) {
        return void 0;
      }
      if (this._authState.tokenCache && this.apiKey == null) {
        const token = await this._authState.tokenCache.getToken();
        this._authFlags(opts).usedTokenCache = true;
        return buildHeaders([{ Authorization: `Bearer ${token}` }]);
      }
      return buildHeaders([await this.apiKeyAuth(opts), await this.bearerAuth(opts)]);
    }
    async apiKeyAuth(opts) {
      if (this.apiKey == null) {
        return void 0;
      }
      return buildHeaders([{ "X-Api-Key": this.apiKey }]);
    }
    async bearerAuth(opts) {
      if (this.authToken == null) {
        return void 0;
      }
      return buildHeaders([{ Authorization: `Bearer ${this.authToken}` }]);
    }
    stringifyQuery(query) {
      return stringifyQuery(query);
    }
    getUserAgent() {
      return `Anthropic/JS ${VERSION}`;
    }
    makeStatusError(status, error, message, headers) {
      return APIError.generate(status, error, message, headers);
    }
    buildURL(path3, query, defaultBaseURL) {
      const baseURL = !__classPrivateFieldGet(this, _BaseAnthropic_instances, "m", _BaseAnthropic_baseURLOverridden).call(this) && defaultBaseURL || this.baseURL;
      const url = isAbsoluteURL(path3) ? new URL(path3) : new URL(baseURL + (baseURL.endsWith("/") && path3.startsWith("/") ? path3.slice(1) : path3));
      const defaultQuery = this.defaultQuery();
      const pathQuery = Object.fromEntries(url.searchParams);
      if (!isEmptyObj(defaultQuery) || !isEmptyObj(pathQuery)) {
        query = { ...pathQuery, ...defaultQuery, ...query };
      }
      if (typeof query === "object" && query && !Array.isArray(query)) {
        url.search = this.stringifyQuery(query);
      }
      return url.toString();
    }
    _calculateNonstreamingTimeout(maxTokens) {
      const defaultTimeout = 10 * 60;
      const expectedTimeout = 60 * 60 * maxTokens / 128e3;
      if (expectedTimeout > defaultTimeout) {
        throw new AnthropicError("Streaming is required for operations that may take longer than 10 minutes. See https://github.com/anthropics/anthropic-sdk-typescript#streaming-responses for more details");
      }
      return defaultTimeout * 1e3;
    }
    /**
     * Used as a callback for mutating the given `FinalRequestOptions` object.
     */
    async prepareOptions(options) {
    }
    /**
     * Used as a callback for mutating the given `RequestInit` object.
     *
     * This is useful for cases where you want to add certain headers based off of
     * the request properties, e.g. `method` or `url`.
     *
     * Runs after all middleware (including {@link backendMiddleware}),
     * immediately before each underlying fetch call, so it sees exactly what
     * goes over the wire. Middleware may replay a request by calling `next()`
     * more than once, so this hook can run multiple times per attempt:
     * overrides must be idempotent and overwrite headers from a previous
     * invocation rather than append to them.
     */
    async prepareRequest(request, { url, options }) {
      if (this._authState.tokenCache && this.apiKey == null) {
        const headers = request.headers instanceof Headers ? request.headers : new Headers(request.headers);
        for (const [k, v] of Object.entries(this._authState.extraHeaders)) {
          if (!headers.has(k))
            headers.set(k, v);
        }
        const existing = headers.get("anthropic-beta")?.split(",").map((s) => s.trim());
        if (!existing?.includes(OAUTH_API_BETA_HEADER)) {
          headers.set("anthropic-beta", [...existing ?? [], OAUTH_API_BETA_HEADER].join(","));
        }
        request.headers = headers;
      }
    }
    /**
     * Internal {@link Middleware} composed innermost in the chain — inside both
     * client-level and per-request middleware, immediately around the underlying
     * `fetch`. Subclasses for third-party backends override this to adapt the
     * canonical Anthropic-shaped request to the backend's wire shape (URL/body
     * rewriting, request signing) and to normalize the wire response back to the
     * canonical shape (e.g. AWS EventStream to SSE).
     *
     * Running inside the user's middleware means user middleware always observes
     * canonical Anthropic-shaped traffic, and the adaptation re-runs (e.g.
     * re-signs) on every `next()` invocation, covering whatever the middleware
     * mutated.
     *
     * Errors thrown here follow the middleware error policy: they propagate to
     * the caller as-is — no retries, no `APIConnectionError` wrapping — unless
     * retryable (see {@link Middleware}); throw a `RetryableError` to opt into
     * the retry path.
     */
    backendMiddleware() {
      return [];
    }
    get(path3, opts) {
      return this.methodRequest("get", path3, opts);
    }
    post(path3, opts) {
      return this.methodRequest("post", path3, opts);
    }
    patch(path3, opts) {
      return this.methodRequest("patch", path3, opts);
    }
    put(path3, opts) {
      return this.methodRequest("put", path3, opts);
    }
    delete(path3, opts) {
      return this.methodRequest("delete", path3, opts);
    }
    methodRequest(method, path3, opts) {
      return this.request(Promise.resolve(opts).then((opts2) => {
        return { method, path: path3, ...opts2 };
      }));
    }
    request(options, remainingRetries = null) {
      return new APIPromise(this, this.makeRequest(options, remainingRetries, void 0));
    }
    async makeRequest(optionsInput, retriesRemaining, retryOfRequestLogID) {
      const options = await optionsInput;
      let maxRetries = validatePositiveInteger("maxRetries", options.maxRetries ?? this.maxRetries);
      if (this.isStreamBody(options.body)) {
        maxRetries = 0;
      }
      if (retriesRemaining == null) {
        retriesRemaining = maxRetries;
        this._requestAuthFlags.delete(options);
      }
      await this.prepareOptions(options);
      const { req, url, timeout } = await this.buildRequest(options, {
        retryCount: maxRetries - retriesRemaining
      });
      const requestLogID = "log_" + (Math.random() * (1 << 24) | 0).toString(16).padStart(6, "0");
      const retryLogStr = retryOfRequestLogID === void 0 ? "" : `, retryOf: ${retryOfRequestLogID}`;
      const startTime = Date.now();
      if (options.signal?.aborted) {
        throw new APIUserAbortError();
      }
      const controller = new AbortController();
      const response = await this.fetchWithTimeout(url, req, timeout, controller, options, {
        requestLogID,
        retryOfRequestLogID
      }).catch(castToError);
      const headersTime = Date.now();
      if (response instanceof globalThis.Error) {
        releaseRequestSignal(controller);
        const retryMessage = `retrying, ${retriesRemaining} attempts remaining`;
        if (options.signal?.aborted) {
          throw new APIUserAbortError();
        }
        const isTimeout = isAbortError(response) || /timed? ?out/i.test(String(response) + ("cause" in response ? String(response.cause) : ""));
        const hasMiddleware = this.middleware.length > 0 || !!options.middleware?.length || this.backendMiddleware().length > 0;
        if (hasMiddleware && !isTimeout && !isRetryableError(response)) {
          loggerFor(this).info(`[${requestLogID}] middleware error (not retryable)`);
          debugLogRequestDetails(loggerFor(this), `[${requestLogID}] middleware error (not retryable)`, {
            retryOfRequestLogID,
            url,
            durationMs: headersTime - startTime,
            message: response.message
          });
          throw response;
        }
        if (retriesRemaining) {
          loggerFor(this).info(`[${requestLogID}] connection ${isTimeout ? "timed out" : "failed"} - ${retryMessage}`);
          debugLogRequestDetails(loggerFor(this), `[${requestLogID}] connection ${isTimeout ? "timed out" : "failed"} (${retryMessage})`, {
            retryOfRequestLogID,
            url,
            durationMs: headersTime - startTime,
            message: response.message
          });
          return this.retryRequest(options, retriesRemaining, retryOfRequestLogID ?? requestLogID);
        }
        loggerFor(this).info(`[${requestLogID}] connection ${isTimeout ? "timed out" : "failed"} - error; no more retries left`);
        debugLogRequestDetails(loggerFor(this), `[${requestLogID}] connection ${isTimeout ? "timed out" : "failed"} (error; no more retries left)`, {
          retryOfRequestLogID,
          url,
          durationMs: headersTime - startTime,
          message: response.message
        });
        if (isTimeout) {
          throw new APIConnectionTimeoutError();
        }
        if (hasMiddleware && !isFetchOriginError(response)) {
          throw response;
        }
        throw new APIConnectionError({ cause: response });
      }
      const specialHeaders = [...response.headers.entries()].filter(([name]) => name === "request-id" || name === "anthropic-workspace-id").map(([name, value]) => ", " + name + ": " + JSON.stringify(value)).join("");
      const responseInfo = `[${requestLogID}${retryLogStr}${specialHeaders}] ${req.method} ${url} ${response.ok ? "succeeded" : "failed"} with status ${response.status} in ${headersTime - startTime}ms`;
      if (!response.ok) {
        const shouldRetry = await this.shouldRetry(response, options);
        if (retriesRemaining && shouldRetry) {
          const retryMessage2 = `retrying, ${retriesRemaining} attempts remaining`;
          await CancelReadableStream(response.body);
          releaseRequestSignal(controller);
          loggerFor(this).info(`${responseInfo} - ${retryMessage2}`);
          debugLogRequestDetails(loggerFor(this), `[${requestLogID}] response error (${retryMessage2})`, {
            retryOfRequestLogID,
            url: response.url,
            status: response.status,
            headers: response.headers,
            durationMs: headersTime - startTime
          });
          return this.retryRequest(options, retriesRemaining, retryOfRequestLogID ?? requestLogID, response.headers);
        }
        const retryMessage = shouldRetry ? `error; no more retries left` : `error; not retryable`;
        loggerFor(this).info(`${responseInfo} - ${retryMessage}`);
        const errText = await response.text().catch((err2) => castToError(err2).message);
        const errJSON = safeJSON(errText);
        const errMessage = errJSON ? void 0 : errText;
        debugLogRequestDetails(loggerFor(this), `[${requestLogID}] response error (${retryMessage})`, {
          retryOfRequestLogID,
          url: response.url,
          status: response.status,
          headers: response.headers,
          message: errMessage,
          durationMs: Date.now() - startTime
        });
        releaseRequestSignal(controller);
        const err = this.makeStatusError(response.status, errJSON, errMessage, response.headers);
        throw err;
      }
      loggerFor(this).info(responseInfo);
      debugLogRequestDetails(loggerFor(this), `[${requestLogID}] response start`, {
        retryOfRequestLogID,
        url: response.url,
        status: response.status,
        headers: response.headers,
        durationMs: headersTime - startTime
      });
      armAbandonmentBackstop(response.body ?? response, controller);
      return { response, options, controller, requestLogID, retryOfRequestLogID, startTime };
    }
    getAPIList(path3, Page2, opts) {
      return this.requestAPIList(Page2, opts && "then" in opts ? opts.then((opts2) => ({ method: "get", path: path3, ...opts2 })) : { method: "get", path: path3, ...opts });
    }
    requestAPIList(Page2, options) {
      const request = this.makeRequest(options, null, void 0);
      return new PagePromise(this, request, Page2);
    }
    async fetchWithTimeout(url, init, ms, controller, requestOptions, logCtx) {
      const { signal, method, ...options } = init || {};
      const abort = this._makeAbort(controller);
      if (signal) {
        signal.addEventListener("abort", abort, { once: true });
        registerRequestSignalCleanup(controller, signal, abort);
      }
      const isReadableBody = globalThis.ReadableStream && options.body instanceof globalThis.ReadableStream || typeof options.body === "object" && options.body !== null && Symbol.asyncIterator in options.body;
      const fetchOptions = {
        signal: controller.signal,
        ...isReadableBody ? { duplex: "half" } : {},
        method: "GET",
        ...options
      };
      if (method) {
        fetchOptions.method = method.toUpperCase();
      }
      const baseFetch = this.fetch;
      const timedFetch = async (innerUrl, innerInit) => {
        const timeout = setTimeout(abort, ms);
        try {
          return await baseFetch.call(void 0, innerUrl, innerInit);
        } finally {
          clearTimeout(timeout);
        }
      };
      const innerFetch = requestOptions === void 0 ? timedFetch : (async (innerUrl, innerInit = {}) => {
        const innerUrlStr = typeof innerUrl === "string" ? innerUrl : innerUrl instanceof URL ? innerUrl.href : innerUrl.url;
        innerInit.headers = innerInit.headers instanceof Headers ? innerInit.headers : new Headers(innerInit.headers);
        await this.prepareRequest(innerInit, { url: innerUrlStr, options: requestOptions });
        if (logCtx) {
          debugLogRequestDetails(loggerFor(this), `[${logCtx.requestLogID}] sending request`, {
            retryOfRequestLogID: logCtx.retryOfRequestLogID,
            method: innerInit.method,
            url: innerUrlStr,
            options: requestOptions,
            headers: innerInit.headers
          });
        }
        return timedFetch(innerUrl, innerInit);
      });
      const requestMiddleware = requestOptions?.middleware;
      const backendMiddleware = this.backendMiddleware();
      const allMiddleware = requestMiddleware?.length || backendMiddleware.length ? [...this.middleware, ...requestMiddleware ?? [], ...backendMiddleware] : this.middleware;
      return await wrapFetchWithMiddleware(innerFetch, allMiddleware, requestOptions, this)(url, fetchOptions);
    }
    async shouldRetry(response, options) {
      const flags = this._authFlags(options);
      if (response.status === 401 && this._authState.tokenCache && flags.usedTokenCache && !flags.didRefreshFor401) {
        flags.didRefreshFor401 = true;
        this._authState.tokenCache.invalidate();
        return true;
      }
      const shouldRetryHeader = response.headers.get("x-should-retry");
      if (shouldRetryHeader === "true")
        return true;
      if (shouldRetryHeader === "false")
        return false;
      if (response.status === 408)
        return true;
      if (response.status === 409)
        return true;
      if (response.status === 429)
        return true;
      if (response.status >= 500)
        return true;
      return false;
    }
    async retryRequest(options, retriesRemaining, requestLogID, responseHeaders) {
      let timeoutMillis;
      const retryAfterMillisHeader = responseHeaders?.get("retry-after-ms");
      if (retryAfterMillisHeader) {
        const timeoutMs = parseFloat(retryAfterMillisHeader);
        if (!Number.isNaN(timeoutMs)) {
          timeoutMillis = timeoutMs;
        }
      }
      const retryAfterHeader = responseHeaders?.get("retry-after");
      if (retryAfterHeader && !timeoutMillis) {
        const timeoutSeconds = parseFloat(retryAfterHeader);
        if (!Number.isNaN(timeoutSeconds)) {
          timeoutMillis = timeoutSeconds * 1e3;
        } else {
          timeoutMillis = Date.parse(retryAfterHeader) - Date.now();
        }
      }
      if (timeoutMillis === void 0 || !(timeoutMillis > 0 && timeoutMillis <= 2 ** 31 - 1)) {
        const maxRetries = options.maxRetries ?? this.maxRetries;
        timeoutMillis = this.calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries);
      }
      await sleep(timeoutMillis, options.signal ?? void 0);
      return this.makeRequest(options, retriesRemaining - 1, requestLogID);
    }
    calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries) {
      const initialRetryDelay = 0.5;
      const maxRetryDelay = 8;
      const numRetries = maxRetries - retriesRemaining;
      const sleepSeconds = Math.min(initialRetryDelay * Math.pow(2, numRetries), maxRetryDelay);
      const jitter2 = 1 - Math.random() * 0.25;
      return sleepSeconds * jitter2 * 1e3;
    }
    calculateNonstreamingTimeout(maxTokens, maxNonstreamingTokens) {
      const maxTime = 60 * 60 * 1e3;
      const defaultTime = 60 * 10 * 1e3;
      const expectedTime = maxTime * maxTokens / 128e3;
      if (expectedTime > defaultTime || maxNonstreamingTokens != null && maxTokens > maxNonstreamingTokens) {
        throw new AnthropicError("Streaming is required for operations that may take longer than 10 minutes. See https://github.com/anthropics/anthropic-sdk-typescript#long-requests for more details");
      }
      return defaultTime;
    }
    async buildRequest(inputOptions, { retryCount = 0 } = {}) {
      const options = { ...inputOptions };
      const { method, path: path3, query, defaultBaseURL } = options;
      if (this._authState.resolution) {
        await this._authState.resolution;
      }
      if (!this._baseURLIsExplicit && this._authState.baseURL && this.baseURL !== this._authState.baseURL) {
        this.baseURL = this._authState.baseURL;
      }
      const url = this.buildURL(path3, query, defaultBaseURL);
      if ("timeout" in options)
        validatePositiveInteger("timeout", options.timeout);
      options.timeout = options.timeout ?? this.timeout;
      const { bodyHeaders, body } = this.buildBody({ options });
      const reqHeaders = await this.buildHeaders({
        options: inputOptions,
        method,
        bodyHeaders,
        retryCount,
        timeout: options.timeout
      });
      const req = {
        method,
        headers: reqHeaders,
        ...options.signal && { signal: options.signal },
        ...globalThis.ReadableStream && body instanceof globalThis.ReadableStream && { duplex: "half" },
        ...body && { body },
        ...this.fetchOptions ?? {},
        ...options.fetchOptions ?? {}
      };
      return { req, url, timeout: options.timeout };
    }
    async buildHeaders({ options, method, bodyHeaders, retryCount, timeout }) {
      const headers = buildHeaders([
        {
          Accept: "application/json",
          "User-Agent": this.getUserAgent(),
          "X-Stainless-Retry-Count": String(retryCount),
          "X-Stainless-Timeout": String(Math.trunc(timeout / 1e3)),
          ...getPlatformHeaders(),
          ...this._options.dangerouslyAllowBrowser ? { "anthropic-dangerous-direct-browser-access": "true" } : void 0,
          "anthropic-version": "2023-06-01"
        },
        await this.authHeaders(options),
        this._options.defaultHeaders,
        bodyHeaders,
        options.headers
      ]);
      this.validateHeaders(headers);
      return headers.values;
    }
    _makeAbort(controller) {
      return () => controller.abort();
    }
    buildBody({ options: { body, headers: rawHeaders } }) {
      if (!body) {
        return { bodyHeaders: void 0, body: void 0 };
      }
      const headers = buildHeaders([rawHeaders]);
      if (
        // Pass raw type verbatim
        ArrayBuffer.isView(body) || body instanceof ArrayBuffer || body instanceof DataView || typeof body === "string" && // Preserve legacy string encoding behavior for now
        headers.values.has("content-type") || // `Blob` is superset of `File`
        globalThis.Blob && body instanceof globalThis.Blob || // `FormData` -> `multipart/form-data`
        body instanceof FormData || // `URLSearchParams` -> `application/x-www-form-urlencoded`
        body instanceof URLSearchParams || // Send chunked stream (each chunk has own `length`)
        globalThis.ReadableStream && body instanceof globalThis.ReadableStream
      ) {
        return { bodyHeaders: void 0, body };
      } else if (this.isStreamBody(body)) {
        return { bodyHeaders: void 0, body: ReadableStreamFrom(body) };
      } else if (typeof body === "object" && headers.values.get("content-type") === "application/x-www-form-urlencoded") {
        return {
          bodyHeaders: { "content-type": "application/x-www-form-urlencoded" },
          body: this.stringifyQuery(body)
        };
      } else {
        return __classPrivateFieldGet(this, _BaseAnthropic_encoder, "f").call(this, { body, headers });
      }
    }
    /**
     * Whether `body` is sent as a stream, which can be read only once:
     * a `ReadableStream`, an async iterable or an iterator.
     */
    isStreamBody(body) {
      if (globalThis.ReadableStream && body instanceof globalThis.ReadableStream) {
        return true;
      }
      return typeof body === "object" && body !== null && (Symbol.asyncIterator in body || Symbol.iterator in body && "next" in body && typeof body.next === "function");
    }
  }
  _a = BaseAnthropic2, _BaseAnthropic_encoder = /* @__PURE__ */ new WeakMap(), _BaseAnthropic_instances = /* @__PURE__ */ new WeakSet(), _BaseAnthropic_baseURLOverridden = function _BaseAnthropic_baseURLOverridden2() {
    return this.baseURL !== "https://api.anthropic.com";
  };
  BaseAnthropic2.Anthropic = _a;
  BaseAnthropic2.DEFAULT_TIMEOUT = 6e5;
  BaseAnthropic2.AnthropicError = AnthropicError;
  BaseAnthropic2.APIError = APIError;
  BaseAnthropic2.APIConnectionError = APIConnectionError;
  BaseAnthropic2.APIConnectionTimeoutError = APIConnectionTimeoutError;
  BaseAnthropic2.APIUserAbortError = APIUserAbortError;
  BaseAnthropic2.NotFoundError = NotFoundError;
  BaseAnthropic2.ConflictError = ConflictError;
  BaseAnthropic2.RateLimitError = RateLimitError;
  BaseAnthropic2.BadRequestError = BadRequestError;
  BaseAnthropic2.AuthenticationError = AuthenticationError;
  BaseAnthropic2.InternalServerError = InternalServerError;
  BaseAnthropic2.PermissionDeniedError = PermissionDeniedError;
  BaseAnthropic2.UnprocessableEntityError = UnprocessableEntityError;
  BaseAnthropic2.toFile = toFile;
  BaseAnthropic2.HUMAN_PROMPT = HUMAN_PROMPT;
  BaseAnthropic2.AI_PROMPT = AI_PROMPT;
  return BaseAnthropic2;
})();
var Anthropic = /* @__PURE__ */ (() => {
  class Anthropic2 extends BaseAnthropic {
    constructor() {
      super(...arguments);
      this.completions = new Completions(this);
      this.messages = new Messages(this);
      this.models = new Models2(this);
      this.files = new Files2(this);
      this.skills = new Skills3(this);
      this.organization = new Organization2(this);
      this.beta = new Beta(this);
    }
  }
  Anthropic2.Completions = Completions;
  Anthropic2.Messages = Messages;
  Anthropic2.Models = Models2;
  Anthropic2.Files = Files2;
  Anthropic2.Skills = Skills3;
  Anthropic2.Organization = Organization2;
  Anthropic2.Beta = Beta;
  return Anthropic2;
})();

// src/background/providers/types.ts
var ProviderError = class extends Error {
  retryable;
  constructor(message, retryable = false) {
    super(message);
    this.retryable = retryable;
  }
};

// src/background/providers/anthropic.ts
function supportsFallbacks(model) {
  return /^claude-(opus|sonnet|fable)-5/.test(model);
}
function isThinkingBlock(b) {
  const t = b?.type;
  return t === "thinking" || t === "redacted_thinking";
}
function toAnthropicMessages(messages, model) {
  const out = [];
  for (const m of messages) {
    if (m.role === "user") {
      if (m.images?.length) {
        out.push({
          role: "user",
          content: [
            ...m.images.map((img) => ({ type: "image", source: { type: "base64", media_type: img.mediaType, data: img.data } })),
            { type: "text", text: m.content }
          ]
        });
      } else out.push({ role: "user", content: m.content });
    } else if (m.role === "assistant") {
      if (m.rawProvider === "anthropic" && Array.isArray(m.raw) && m.raw.length) {
        let blocks2 = m.raw;
        if (m.rawModel && m.rawModel !== model) blocks2 = blocks2.filter((b) => !isThinkingBlock(b));
        if (blocks2.length) {
          out.push({ role: "assistant", content: blocks2 });
          continue;
        }
      }
      const blocks = [];
      if (m.content.trim()) blocks.push({ type: "text", text: m.content });
      for (const c of m.toolCalls ?? []) blocks.push({ type: "tool_use", id: c.id, name: c.name, input: c.input ?? {} });
      if (!blocks.length) blocks.push({ type: "text", text: "(empty)" });
      out.push({ role: "assistant", content: blocks });
    } else {
      out.push({
        role: "user",
        content: m.results.map((r) => ({
          type: "tool_result",
          tool_use_id: r.id,
          content: r.content,
          is_error: r.isError ?? false
        }))
      });
    }
  }
  return out;
}
var AnthropicProvider = class {
  id = "anthropic";
  rawKey = "anthropic";
  model;
  effort;
  client;
  constructor(apiKey, model, effort) {
    this.model = model;
    this.effort = effort;
    this.client = new Anthropic({ apiKey, dangerouslyAllowBrowser: true, maxRetries: 2 });
  }
  async run(req) {
    const tools = req.tools.map((t) => ({
      name: t.name,
      description: t.description,
      input_schema: t.input_schema,
      // Stream large tool inputs as they are generated; inputs are validated client-side before running.
      eager_input_streaming: true
    }));
    const betas = ["thinking-binding-controls-2026-08-01"];
    const fallbacks = supportsFallbacks(this.model);
    if (fallbacks) betas.push("server-side-fallback-2026-07-01");
    let message;
    for (let attempt = 0; attempt < 2; attempt++) {
      const stream2 = this.client.beta.messages.stream(
        {
          model: this.model,
          max_tokens: 32e3,
          betas,
          system: [{ type: "text", text: req.system, cache_control: { type: "ephemeral" } }],
          messages: toAnthropicMessages(req.messages, this.model),
          tools,
          // Adaptive thinking; if replayed thinking blocks no longer match the history (e.g. settings changed
          // mid-chat), drop them instead of failing the request.
          thinking: { type: "adaptive", block_binding: { prefix_mismatch_behavior: "drop_block" } },
          output_config: { effort: this.effort },
          ...fallbacks ? { fallbacks: "default" } : {}
        },
        { signal: req.signal }
      );
      stream2.on("text", (delta) => req.onText(delta));
      try {
        message = await stream2.finalMessage();
        break;
      } catch (err) {
        if (req.signal.aborted) throw err;
        if (err instanceof Anthropic.APIError) throw new ProviderError(describeApiError(err), err.status === 429 || (err.status ?? 0) >= 500);
        if (err instanceof Error && /abort/i.test(err.message)) throw err;
        if (attempt === 0) continue;
        throw new ProviderError(err instanceof Error ? err.message : String(err));
      }
    }
    if (!message) throw new ProviderError("No response from Claude");
    const text = message.content.filter((b) => b.type === "text").map((b) => b.text).join("");
    const toolCalls = message.content.filter((b) => b.type === "tool_use").map((b) => ({ id: b.id, name: b.name, input: b.input }));
    let stop = "end";
    let refusalReason;
    switch (message.stop_reason) {
      case "tool_use":
        stop = "tool_use";
        break;
      case "max_tokens":
        stop = "max_tokens";
        break;
      case "refusal":
        stop = "refusal";
        refusalReason = message.stop_details?.type === "refusal" ? message.stop_details.category ?? void 0 : void 0;
        break;
      default:
        stop = toolCalls.length ? "tool_use" : "end";
    }
    return { text, toolCalls, stop, raw: message.content, model: message.model, refusalReason };
  }
};
function describeApiError(err) {
  if (err instanceof Anthropic.AuthenticationError) return "Claude API: invalid API key (check Settings).";
  if (err instanceof Anthropic.PermissionDeniedError) return "Claude API: permission denied for this key/model.";
  if (err instanceof Anthropic.RateLimitError) return "Claude API: rate limit reached \u2014 wait a moment and retry.";
  if (err instanceof Anthropic.NotFoundError) return `Claude API: model not found (${err.message}).`;
  if (err instanceof Anthropic.BadRequestError) return `Claude API rejected the request: ${err.message}`;
  if (err instanceof Anthropic.APIConnectionError) return "Could not reach api.anthropic.com (network, VPN or firewall?).";
  return `Claude API error${err.status ? " " + err.status : ""}: ${err.message}`;
}

// src/background/providers/openai.ts
async function readSse(res, onData) {
  if (!res.body) throw new ProviderError("Empty response body");
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  const handleLine = (line) => {
    if (!line.startsWith("data:")) return;
    const data = line.slice(5).trim();
    if (!data || data === "[DONE]") return;
    try {
      onData(JSON.parse(data));
    } catch {
    }
  };
  for (; ; ) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    let nl;
    while ((nl = buf.indexOf("\n")) >= 0) {
      handleLine(buf.slice(0, nl).trim());
      buf = buf.slice(nl + 1);
    }
  }
  const rest = buf.trim();
  if (rest.startsWith("data:")) handleLine(rest);
  else if (rest.startsWith("{")) {
    try {
      onData(JSON.parse(rest));
    } catch {
    }
  }
}
async function describeHttpError(res, label) {
  const txt = await res.text().catch(() => "");
  let msg = txt.slice(0, 400);
  try {
    msg = JSON.parse(txt)?.error?.message ?? msg;
  } catch {
  }
  if (res.status === 401 || res.status === 403) return new ProviderError(`${label}: invalid API key or no access (${msg})`);
  if (res.status === 404) return new ProviderError(`${label}: endpoint not found (HTTP 404). Check the base URL (it should end with /v1) and the protocol (Chat Completions vs Responses API). ${msg}`);
  return new ProviderError(`${label} HTTP ${res.status}: ${msg}`, res.status === 429 || res.status >= 500);
}
var OpenAICompatProvider = class {
  id;
  rawKey;
  model;
  protocol;
  baseUrl;
  apiKey;
  label;
  constructor(opts) {
    this.id = opts.id;
    this.baseUrl = opts.baseUrl.replace(/\/+$/, "");
    this.apiKey = opts.apiKey;
    this.model = opts.model;
    this.protocol = opts.protocol ?? "chat";
    this.label = opts.label ?? opts.id;
    this.rawKey = this.protocol === "responses" ? "openai-responses" : "openai-chat";
  }
  async post(path3, body, signal) {
    const headers = { "Content-Type": "application/json" };
    if (this.apiKey) headers.Authorization = `Bearer ${this.apiKey}`;
    let res;
    try {
      res = await fetch(`${this.baseUrl}${path3}`, { method: "POST", headers, body: JSON.stringify(body), signal });
    } catch (err) {
      if (signal.aborted) throw err;
      const m = err instanceof Error ? err.message : String(err);
      const hint = /Failed to fetch/i.test(m) ? ' (network error \u2014 if this is a custom provider, press "Grant access" for its host in Settings)' : "";
      throw new ProviderError(`Could not reach ${this.baseUrl}${hint}`);
    }
    if (!res.ok) throw await describeHttpError(res, this.label);
    return res;
  }
  run(req) {
    return this.protocol === "responses" ? this.runResponses(req) : this.runChat(req);
  }
  // ---- Chat Completions -----------------------------------------------------
  toChatMessages(system, messages) {
    const out = [{ role: "system", content: system }];
    for (const m of messages) {
      if (m.role === "user") {
        if (m.images?.length) {
          out.push({
            role: "user",
            content: [...m.images.map((img) => ({ type: "image_url", image_url: { url: `data:${img.mediaType};base64,${img.data}` } })), { type: "text", text: m.content }]
          });
        } else out.push({ role: "user", content: m.content });
      } else if (m.role === "assistant") {
        const raw = m.rawProvider === "openai-chat" ? m.raw : void 0;
        const toolCalls = raw?.tool_calls ?? (m.toolCalls ?? []).map((c) => ({ id: c.id, type: "function", function: { name: c.name, arguments: JSON.stringify(c.input ?? {}) } }));
        const msg = { role: "assistant", content: raw?.content ?? m.content ?? "" };
        if (toolCalls.length) msg.tool_calls = toolCalls;
        out.push(msg);
      } else {
        for (const r of m.results) out.push({ role: "tool", tool_call_id: r.id, content: r.content });
      }
    }
    return out;
  }
  async runChat(req) {
    const body = { model: this.model, messages: this.toChatMessages(req.system, req.messages), stream: true };
    if (req.tools.length) {
      body.tools = req.tools.map((t) => ({ type: "function", function: { name: t.name, description: t.description, parameters: t.input_schema } }));
    }
    const res = await this.post("/chat/completions", body, req.signal);
    let text = "";
    const calls = /* @__PURE__ */ new Map();
    let finish;
    await readSse(res, (json2) => {
      const choice = json2?.choices?.[0];
      if (!choice) return;
      const delta = choice.delta ?? choice.message ?? {};
      if (typeof delta.content === "string" && delta.content) {
        text += delta.content;
        req.onText(delta.content);
      }
      for (const tc of delta.tool_calls ?? []) {
        const idx = tc.index ?? calls.size;
        const cur = calls.get(idx) ?? { id: tc.id ?? "", name: "", args: "" };
        if (tc.id) cur.id = tc.id;
        if (tc.function?.name) cur.name += tc.function.name;
        if (tc.function?.arguments) cur.args += tc.function.arguments;
        calls.set(idx, cur);
      }
      if (choice.finish_reason) finish = choice.finish_reason;
    });
    const toolCalls = [];
    const rawCalls = [];
    let n = 0;
    for (const c of calls.values()) {
      const id = c.id || `call_${Date.now()}_${n++}`;
      toolCalls.push({ id, name: c.name, input: parseArgs(c.args) });
      rawCalls.push({ id, type: "function", function: { name: c.name, arguments: c.args || "{}" } });
    }
    const raw = { content: text, ...rawCalls.length ? { tool_calls: rawCalls } : {} };
    return { text, toolCalls, stop: stopFromFinish(finish, toolCalls.length), raw, model: this.model };
  }
  // ---- Responses API ---------------------------------------------------------
  toResponsesInput(messages) {
    const out = [];
    for (const m of messages) {
      if (m.role === "user") {
        if (m.images?.length) {
          out.push({
            role: "user",
            content: [...m.images.map((img) => ({ type: "input_image", image_url: `data:${img.mediaType};base64,${img.data}` })), { type: "input_text", text: m.content }]
          });
        } else out.push({ role: "user", content: m.content });
      } else if (m.role === "assistant") {
        const raw = m.rawProvider === "openai-responses" && Array.isArray(m.raw) ? m.raw : void 0;
        if (raw?.length) {
          out.push(...raw);
          continue;
        }
        if (m.content.trim()) out.push({ role: "assistant", content: [{ type: "output_text", text: m.content }] });
        for (const c of m.toolCalls ?? []) out.push({ type: "function_call", call_id: c.id, name: c.name, arguments: JSON.stringify(c.input ?? {}) });
      } else {
        for (const r of m.results) out.push({ type: "function_call_output", call_id: r.id, output: r.content });
      }
    }
    return out;
  }
  async runResponses(req) {
    const body = { model: this.model, instructions: req.system, input: this.toResponsesInput(req.messages), stream: true };
    if (req.tools.length) {
      body.tools = req.tools.map((t) => ({ type: "function", name: t.name, description: t.description, parameters: t.input_schema }));
    }
    const res = await this.post("/responses", body, req.signal);
    let streamedText = "";
    let finalResponse = null;
    let failure;
    await readSse(res, (ev) => {
      switch (ev?.type) {
        case "response.output_text.delta":
          if (typeof ev.delta === "string") {
            streamedText += ev.delta;
            req.onText(ev.delta);
          }
          break;
        case "response.completed":
        case "response.incomplete":
          finalResponse = ev.response ?? null;
          break;
        case "response.failed":
          failure = ev.response?.error?.message ?? "response failed";
          break;
        case "error":
          failure = ev.error?.message ?? ev.message ?? "stream error";
          break;
      }
    });
    if (failure) throw new ProviderError(`${this.label}: ${failure}`);
    const output = Array.isArray(finalResponse?.output) ? finalResponse.output : [];
    let text = "";
    const toolCalls = [];
    const raw = [];
    for (const item of output) {
      if (item?.type === "message") {
        const t = (item.content ?? []).filter((c) => c?.type === "output_text").map((c) => c.text ?? "").join("");
        text += t;
        raw.push({ role: "assistant", content: [{ type: "output_text", text: t }] });
      } else if (item?.type === "function_call") {
        const callId = item.call_id ?? item.id ?? `call_${Date.now()}_${toolCalls.length}`;
        toolCalls.push({ id: callId, name: item.name, input: parseArgs(item.arguments) });
        raw.push({ type: "function_call", call_id: callId, name: item.name, arguments: item.arguments ?? "{}" });
      }
    }
    if (!output.length) text = streamedText;
    let stop = toolCalls.length ? "tool_use" : "end";
    if (finalResponse?.status === "incomplete" && finalResponse?.incomplete_details?.reason === "max_output_tokens") stop = "max_tokens";
    if (finalResponse?.status === "incomplete" && finalResponse?.incomplete_details?.reason === "content_filter") stop = "refusal";
    return { text, toolCalls, stop, raw, model: finalResponse?.model ?? this.model };
  }
};
function parseArgs(args) {
  if (!args) return {};
  try {
    return JSON.parse(args);
  } catch {
    return { __invalid_json: args };
  }
}
function stopFromFinish(finish, calls) {
  if (calls || finish === "tool_calls") return "tool_use";
  if (finish === "length") return "max_tokens";
  if (finish === "content_filter") return "refusal";
  return "end";
}

// src/background/providers/index.ts
function createProvider(s) {
  switch (s.provider) {
    case "anthropic":
      if (!s.anthropicApiKey) throw new ProviderError("Claude API key is missing \u2014 add it in Settings.");
      return new AnthropicProvider(s.anthropicApiKey, s.anthropicModel || "claude-opus-5-5", s.effort);
    case "openai":
      if (!s.openaiApiKey) throw new ProviderError("OpenAI API key is missing \u2014 add it in Settings.");
      return new OpenAICompatProvider({ id: "openai", baseUrl: s.openaiBaseUrl || "https://api.openai.com/v1", apiKey: s.openaiApiKey, model: s.openaiModel, label: "OpenAI" });
    case "gemini":
      if (!s.geminiApiKey) throw new ProviderError("Gemini API key is missing \u2014 add it in Settings.");
      return new OpenAICompatProvider({
        id: "gemini",
        baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai",
        apiKey: s.geminiApiKey,
        model: s.geminiModel,
        label: "Gemini"
      });
    case "ollama":
      return new OpenAICompatProvider({ id: "ollama", baseUrl: s.ollamaBaseUrl || "http://localhost:11434/v1", apiKey: "", model: s.ollamaModel, label: "Ollama" });
    case "custom": {
      const p = activeCustomProvider(s);
      if (!p) throw new ProviderError("No custom provider is configured \u2014 add one in Settings \u2192 Custom providers.");
      if (!p.baseUrl) throw new ProviderError(`Custom provider "${p.name}": base URL is missing.`);
      if (!p.model) throw new ProviderError(`Custom provider "${p.name}": model name is missing.`);
      return new OpenAICompatProvider({ id: "custom", baseUrl: p.baseUrl, apiKey: p.apiKey, model: p.model, protocol: p.protocol, label: p.name || "Custom provider" });
    }
  }
}

// src/background/prompts.ts
var LANG_NAME = { ru: "Russian", en: "English" };
function buildSystemPrompt(s, capabilities) {
  const lines = [];
  lines.push(
    `You are Nubit, an expert YouTube growth analyst built into a Chrome extension. You help creators understand why videos perform, research keywords and topics, write titles/descriptions/tags, study competitors and plan content.`,
    ``,
    `You can see the page the user has open on YouTube (it is attached to messages as <page_context>), and you have tools to search YouTube, read video details, channel uploads, transcripts, comments and keyword suggestions.`,
    ``,
    `How to work:`,
    `- Lead with the insight, then the evidence. Be concrete: numbers, examples, rewritten titles. No filler, no generic advice that ignores the data.`,
    `- Use tools when the answer depends on data you do not have yet (competitors, channel baseline, transcript, comments). Do not call tools for things already in the page context. Prefer a few well-chosen calls; run independent calls in parallel.`,
    `- Metric definitions: VPH = views per hour since publish (lifetime average; "vphRecent" is measured by the extension between two visits). Outlier = views divided by the median views of the channel's recent uploads (\u22652x means the video beat its own channel; <0.5x underperformed). Engagement = (likes + comments) / views; 3\u20136% is typical, >8% is strong. SEO score is a checklist (title length, keyword reuse, tags, chapters\u2026), not a ranking prediction.`,
    `- "Demand" and "competition" from analyze_keyword are estimates derived from autocomplete and the top results \u2014 YouTube publishes no search volume. Say so when it matters.`,
    `- Titles: give 5\u20138 variants, \u2264 70 characters, specific, in the video's language; one short note on the angle of each. Avoid misleading clickbait.`,
    `- Tags: 10\u201320, mix exact phrase, broad topic and spelling variants. Descriptions: the first two lines carry the main keyword and the hook; then chapters, links, hashtags.`,
    `- When comparing videos or channels, use a compact table.`,
    `- Be honest about uncertainty and about missing data (e.g. comments need a YouTube Data API key; a private video cannot be read). Suggest the concrete setting to enable when a tool is unavailable.`,
    `- Format with short headings, bullet lists and tables. Keep answers compact.`,
    `- Respond in ${LANG_NAME[s.language]} unless the user writes in another language \u2014 then answer in the user's language. Keep video titles, tags and quotes in their original language.`
  );
  lines.push(``, `Environment:`);
  lines.push(`- YouTube Data API key: ${capabilities.youtubeApi ? "configured (comments, exact statistics and search available)" : "not configured (public page data only; comments only from the open page)"}.`);
  lines.push(
    capabilities.nativeTools.length ? `- Local programs available through run_local_tool: ${capabilities.nativeTools.join(", ")}.` : `- No local programs configured (the user can add yt-dlp/ffmpeg in Settings \u2192 Local tools).`
  );
  lines.push(
    capabilities.customApis.length ? `- Custom APIs available through call_custom_api: ${capabilities.customApis.join(", ")}.` : `- No custom APIs configured.`
  );
  return lines.join("\n");
}
var ACTION_PROMPTS = {
  analyze_video: {
    ru: "\u0421\u0434\u0435\u043B\u0430\u0439 \u043F\u043E\u043B\u043D\u044B\u0439 \u0440\u0430\u0437\u0431\u043E\u0440 \u044D\u0442\u043E\u0433\u043E \u0432\u0438\u0434\u0435\u043E: \u043A\u0430\u043A \u043E\u043D\u043E \u043D\u0430\u0431\u0438\u0440\u0430\u0435\u0442 (VPH, outlier \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u043A\u0430\u043D\u0430\u043B\u0430, \u0432\u043E\u0432\u043B\u0435\u0447\u0451\u043D\u043D\u043E\u0441\u0442\u044C), \u0447\u0442\u043E \u0432 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0438/\u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0438/\u0442\u0435\u0433\u0430\u0445 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0438 \u0447\u0442\u043E \u043D\u0435\u0442, 3\u20135 \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u044B\u0445 \u0443\u043B\u0443\u0447\u0448\u0435\u043D\u0438\u0439. \u0415\u0441\u043B\u0438 \u043D\u0443\u0436\u0435\u043D \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \u043A\u0430\u043D\u0430\u043B\u0430 \u2014 \u043F\u043E\u043B\u0443\u0447\u0438 \u0435\u0433\u043E \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u043E\u043C.",
    en: "Give a full breakdown of this video: how it is performing (VPH, outlier vs the channel, engagement), what works and what does not in the title/description/tags, and 3\u20135 concrete improvements. Fetch channel context with a tool if needed."
  },
  why_performing: {
    ru: "\u041E\u0431\u044A\u044F\u0441\u043D\u0438, \u043F\u043E\u0447\u0435\u043C\u0443 \u044D\u0442\u043E \u0432\u0438\u0434\u0435\u043E \u043D\u0430\u0431\u0438\u0440\u0430\u0435\u0442 \u0438\u043C\u0435\u043D\u043D\u043E \u0442\u0430\u043A (\u0441\u0438\u043B\u044C\u043D\u043E \u043B\u0443\u0447\u0448\u0435 \u0438\u043B\u0438 \u0445\u0443\u0436\u0435 \u043A\u0430\u043D\u0430\u043B\u0430). \u0421\u0440\u0430\u0432\u043D\u0438 \u0441 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u043C\u0438 \u0432\u0438\u0434\u0435\u043E \u043A\u0430\u043D\u0430\u043B\u0430 (\u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442 get_channel_videos), \u043F\u043E\u0441\u043C\u043E\u0442\u0440\u0438 \u0442\u0435\u043C\u0443, \u043F\u043E\u0434\u0430\u0447\u0443 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F, \u043F\u0440\u0435\u0432\u044C\u044E-\u0441\u043B\u043E\u0432\u0430, \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C. \u0414\u0430\u0439 \u0432\u044B\u0432\u043E\u0434: \u0447\u0442\u043E \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C, \u0447\u0435\u0433\u043E \u0438\u0437\u0431\u0435\u0433\u0430\u0442\u044C.",
    en: "Explain why this video performs the way it does (much better or worse than the channel). Compare with the channel's recent uploads (get_channel_videos), look at the topic, title framing, duration. Conclude: what to repeat, what to avoid."
  },
  titles: {
    ru: "\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0438 8 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u043E\u0432 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u0434\u043B\u044F \u044D\u0442\u043E\u0433\u043E \u0432\u0438\u0434\u0435\u043E \u043F\u043E\u0434 \u0440\u0430\u0437\u043D\u044B\u0435 \u0443\u0433\u043B\u044B (\u043F\u043E\u043B\u044C\u0437\u0430, \u043B\u044E\u0431\u043E\u043F\u044B\u0442\u0441\u0442\u0432\u043E, \u0446\u0438\u0444\u0440\u044B, \u0432\u043E\u043F\u0440\u043E\u0441, \u043A\u043E\u043D\u0442\u0440\u0430\u0441\u0442). \u041A\u043E\u0440\u043E\u0442\u043A\u043E \u043E\u0431\u044A\u044F\u0441\u043D\u0438 \u043B\u043E\u0433\u0438\u043A\u0443 \u043A\u0430\u0436\u0434\u043E\u0433\u043E. \u0423\u0447\u0438\u0442\u044B\u0432\u0430\u0439, \u0447\u0442\u043E \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u0432 \u043F\u043E\u0438\u0441\u043A\u0435 \u043E\u0431\u0440\u0435\u0437\u0430\u044E\u0442\u0441\u044F \u043F\u043E\u0441\u043B\u0435 ~60 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432.",
    en: "Propose 8 title options for this video with different angles (benefit, curiosity, numbers, question, contrast). Briefly explain each. Remember titles get cut after ~60 characters in search."
  },
  tags_description: {
    ru: "\u041D\u0430\u043F\u0438\u0448\u0438 \u043E\u043F\u0442\u0438\u043C\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 (\u043F\u0435\u0440\u0432\u044B\u0435 2 \u0441\u0442\u0440\u043E\u043A\u0438 \u2014 \u043A\u043B\u044E\u0447\u0435\u0432\u043E\u0439 \u0437\u0430\u043F\u0440\u043E\u0441 \u0438 \u043A\u0440\u044E\u0447\u043E\u043A, \u0437\u0430\u0442\u0435\u043C \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430, \u0433\u043B\u0430\u0432\u044B \u0435\u0441\u043B\u0438 \u0443\u043C\u0435\u0441\u0442\u043D\u043E, \u0445\u044D\u0448\u0442\u0435\u0433\u0438) \u0438 \u0441\u043F\u0438\u0441\u043E\u043A \u0438\u0437 15\u201320 \u0442\u0435\u0433\u043E\u0432 \u0434\u043B\u044F \u044D\u0442\u043E\u0433\u043E \u0432\u0438\u0434\u0435\u043E. \u0415\u0441\u043B\u0438 \u0432\u0438\u0434\u0435\u043E \u0443\u0436\u0435 \u0438\u043C\u0435\u0435\u0442 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0438 \u0442\u0435\u0433\u0438 \u2014 \u0443\u043A\u0430\u0436\u0438, \u0447\u0442\u043E \u0438\u043C\u0435\u043D\u043D\u043E \u0443\u043B\u0443\u0447\u0448\u0435\u043D\u043E.",
    en: "Write an optimized description (first 2 lines: main keyword and hook, then structure, chapters if relevant, hashtags) and a list of 15\u201320 tags for this video. If it already has them, point out what changed and why."
  },
  keyword_research: {
    ru: "\u041F\u0440\u043E\u0430\u043D\u0430\u043B\u0438\u0437\u0438\u0440\u0443\u0439 \u044D\u0442\u043E\u0442 \u043F\u043E\u0438\u0441\u043A\u043E\u0432\u044B\u0439 \u0437\u0430\u043F\u0440\u043E\u0441 \u043A\u0430\u043A \u0442\u0435\u043C\u0443 \u0434\u043B\u044F \u0432\u0438\u0434\u0435\u043E: \u0441\u043F\u0440\u043E\u0441 \u0438 \u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0446\u0438\u044F (analyze_keyword), \u043A\u0442\u043E \u0432 \u0442\u043E\u043F\u0435 \u0438 \u043F\u043E\u0447\u0435\u043C\u0443, \u043A\u0430\u043A\u0438\u0435 \u043D\u0435\u0431\u043E\u043B\u044C\u0448\u0438\u0435 \u043A\u0430\u043D\u0430\u043B\u044B \u043F\u0440\u043E\u0431\u0438\u043B\u0438\u0441\u044C, 5\u201310 \u0441\u043C\u0435\u0436\u043D\u044B\u0445 \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432 \u0438\u0437 \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043E\u043A, \u0438 \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u044F \u2014 \u0441\u0442\u043E\u0438\u0442 \u043B\u0438 \u0441\u043D\u0438\u043C\u0430\u0442\u044C \u0438 \u043F\u043E\u0434 \u043A\u0430\u043A\u0438\u043C \u0443\u0433\u043B\u043E\u043C.",
    en: "Analyze this search query as a video topic: demand and competition (analyze_keyword), who ranks and why, which small channels broke through, 5\u201310 related queries from suggestions, and a recommendation on whether and how to make it."
  },
  channel_review: {
    ru: "\u0421\u0434\u0435\u043B\u0430\u0439 \u0440\u0430\u0437\u0431\u043E\u0440 \u044D\u0442\u043E\u0433\u043E \u043A\u0430\u043D\u0430\u043B\u0430 \u043F\u043E \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u043C \u0432\u0438\u0434\u0435\u043E: \u0447\u0430\u0441\u0442\u043E\u0442\u0430 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0439, \u043C\u0435\u0434\u0438\u0430\u043D\u0430 \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u043E\u0432, \u043A\u0430\u043A\u0438\u0435 \u0432\u0438\u0434\u0435\u043E \u0441\u0442\u0430\u043B\u0438 outlier \u0438 \u0447\u0442\u043E \u0438\u0445 \u043E\u0431\u044A\u0435\u0434\u0438\u043D\u044F\u0435\u0442 (\u0442\u0435\u043C\u044B, \u0444\u043E\u0440\u043C\u0430\u0442\u044B, \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F), \u043A\u0430\u043A\u0438\u0435 \u043F\u0440\u043E\u0432\u0430\u043B\u0438\u043B\u0438\u0441\u044C, 5 \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u0439 \u043F\u043E \u043A\u043E\u043D\u0442\u0435\u043D\u0442-\u043F\u043B\u0430\u043D\u0443.",
    en: "Review this channel from its recent uploads: upload cadence, median views, which videos became outliers and what they share (topics, formats, titles), which flopped, and 5 content-plan recommendations."
  },
  competitors: {
    ru: "\u041D\u0430\u0439\u0434\u0438 5\u20138 \u043A\u043E\u043D\u043A\u0443\u0440\u0438\u0440\u0443\u044E\u0449\u0438\u0445 \u0432\u0438\u0434\u0435\u043E \u043F\u043E \u0442\u0435\u043C\u0435 \u044D\u0442\u043E\u0433\u043E \u0432\u0438\u0434\u0435\u043E (search_youtube), \u0441\u0440\u0430\u0432\u043D\u0438 \u0438\u0445 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 (\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u044B, \u0432\u043E\u0437\u0440\u0430\u0441\u0442, VPH, \u043A\u0430\u043D\u0430\u043B, \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C, \u0443\u0433\u043E\u043B \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F) \u0438 \u0441\u043A\u0430\u0436\u0438, \u0447\u0435\u043C \u044D\u0442\u043E \u0432\u0438\u0434\u0435\u043E \u043C\u043E\u0436\u0435\u0442 \u0432\u044B\u0434\u0435\u043B\u0438\u0442\u044C\u0441\u044F.",
    en: "Find 5\u20138 competing videos on this video's topic (search_youtube), compare them in a table (views, age, VPH, channel, duration, title angle) and say how this video can stand out."
  },
  content_ideas: {
    ru: "\u041D\u0430 \u043E\u0441\u043D\u043E\u0432\u0435 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0430 (\u043A\u0430\u043D\u0430\u043B \u0438\u043B\u0438 \u0442\u0435\u043C\u0430) \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0438 10 \u0438\u0434\u0435\u0439 \u0434\u043B\u044F \u043D\u043E\u0432\u044B\u0445 \u0432\u0438\u0434\u0435\u043E, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0441 \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0432\u0435\u0440\u043E\u044F\u0442\u043D\u043E\u0441\u0442\u044C\u044E \u043D\u0430\u0431\u0435\u0440\u0443\u0442: \u0434\u043B\u044F \u043A\u0430\u0436\u0434\u043E\u0439 \u2014 \u0440\u0430\u0431\u043E\u0447\u0435\u0435 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435, \u043F\u043E\u0447\u0435\u043C\u0443 \u0441\u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 (\u0434\u0430\u043D\u043D\u044B\u0435 \u0438\u0437 \u043F\u043E\u0438\u0441\u043A\u0430/\u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043E\u043A), \u0444\u043E\u0440\u043C\u0430\u0442 \u0438 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C. \u041F\u0440\u043E\u0432\u0435\u0440\u044C \u0441\u043F\u0440\u043E\u0441 \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u0430\u043C\u0438 \u0445\u043E\u0442\u044F \u0431\u044B \u0434\u043B\u044F 3 \u043B\u0443\u0447\u0448\u0438\u0445.",
    en: "Based on the context (channel or topic), propose 10 new video ideas likely to perform: for each a working title, why it will work (search/suggestion data), format and length. Verify demand with tools for at least the top 3."
  },
  summarize: {
    ru: "\u041F\u043E\u043B\u0443\u0447\u0438 \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u044B \u044D\u0442\u043E\u0433\u043E \u0432\u0438\u0434\u0435\u043E (get_transcript) \u0438 \u043A\u0440\u0430\u0442\u043A\u043E \u043F\u0435\u0440\u0435\u0441\u043A\u0430\u0436\u0438: \u043E \u0447\u0451\u043C \u0432\u0438\u0434\u0435\u043E, \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u0435 \u0442\u0435\u0437\u0438\u0441\u044B \u043F\u043E \u0442\u0430\u0439\u043C\u043A\u043E\u0434\u0430\u043C, \u0433\u043B\u0430\u0432\u043D\u044B\u0439 \u0432\u044B\u0432\u043E\u0434. \u0415\u0441\u043B\u0438 \u0441\u0443\u0431\u0442\u0438\u0442\u0440\u043E\u0432 \u043D\u0435\u0442 \u2014 \u0441\u043A\u0430\u0436\u0438, \u043A\u0430\u043A \u0438\u0445 \u0432\u043A\u043B\u044E\u0447\u0438\u0442\u044C.",
    en: "Get this video's transcript (get_transcript) and summarize it: what it is about, key points with timestamps, main takeaway. If there is no transcript, explain how to enable one."
  },
  daily_ideas: {
    ru: "\u0421\u043E\u0441\u0442\u0430\u0432\u044C \xAB\u0438\u0434\u0435\u0438 \u0434\u043D\u044F\xBB: \u0432\u044B\u0437\u043E\u0432\u0438 get_competitors (\u0447\u0442\u043E \u0441\u0435\u0439\u0447\u0430\u0441 \u0432\u044B\u0441\u0442\u0440\u0435\u043B\u0438\u0432\u0430\u0435\u0442 \u0443 \u043E\u0442\u0441\u043B\u0435\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0445 \u043A\u0430\u043D\u0430\u043B\u043E\u0432) \u0438, \u0435\u0441\u043B\u0438 \u0435\u0441\u0442\u044C \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B, \u0443\u0447\u0442\u0438 \u0435\u0433\u043E; \u0434\u043B\u044F 2\u20133 \u0441\u0430\u043C\u044B\u0445 \u0441\u0438\u043B\u044C\u043D\u044B\u0445 \u0442\u0435\u043C \u043F\u0440\u043E\u0432\u0435\u0440\u044C \u0441\u043F\u0440\u043E\u0441 \u0447\u0435\u0440\u0435\u0437 suggest_keywords \u0438\u043B\u0438 analyze_keyword. \u0412\u044B\u0434\u0430\u0439 10 \u0438\u0434\u0435\u0439 \u0434\u043B\u044F \u0432\u0438\u0434\u0435\u043E, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0441 \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0432\u0435\u0440\u043E\u044F\u0442\u043D\u043E\u0441\u0442\u044C\u044E \u043D\u0430\u0431\u0435\u0440\u0443\u0442: \u0434\u043B\u044F \u043A\u0430\u0436\u0434\u043E\u0439 \u2014 \u0440\u0430\u0431\u043E\u0447\u0435\u0435 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 (\u2264 70 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432), \u043F\u043E\u0447\u0435\u043C\u0443 \u0441\u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 (\u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u043E\u0435 \u0432\u0438\u0434\u0435\u043E-outlier \u0438\u043B\u0438 \u0437\u0430\u043F\u0440\u043E\u0441), \u0444\u043E\u0440\u043C\u0430\u0442 \u0438 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C, \u0447\u0435\u043C \u043E\u0442\u043B\u0438\u0447\u0438\u0442\u044C\u0441\u044F \u043E\u0442 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u0430. \u041D\u0430\u0447\u043D\u0438 \u0441 3 \u043B\u0443\u0447\u0448\u0438\u0445. \u0415\u0441\u043B\u0438 \u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442\u043E\u0432 \u043D\u0435\u0442 \u2014 \u0441\u043A\u0430\u0436\u0438, \u043A\u0430\u043A \u0438\u0445 \u0434\u043E\u0431\u0430\u0432\u0438\u0442\u044C, \u0438 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0438 \u0438\u0434\u0435\u0438 \u043F\u043E \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0443 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B.",
    en: 'Build "daily ideas": call get_competitors (what is breaking out on the tracked channels) and use the page context if present; verify demand for the 2\u20133 strongest topics with suggest_keywords or analyze_keyword. Give 10 video ideas likely to perform: for each a working title (\u2264 70 chars), why it will work (the specific outlier video or query), format and length, and how to differ from the original. Lead with the top 3. If no competitors are tracked, explain how to add them and propose ideas from the page context.'
  },
  // Studio actions must answer with JSON only: the Studio panel parses the reply and offers one-click insertion.
  studio_titles: {
    ru: '\u0422\u0432\u043E\u0440\u0435\u0446 \u0437\u0430\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u0444\u043E\u0440\u043C\u0443 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u0432 YouTube Studio (\u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0432 page_context: \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435, \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435, \u0442\u0435\u0433\u0438, \u0444\u043E\u043A\u0443\u0441-\u0437\u0430\u043F\u0440\u043E\u0441). \u0415\u0441\u043B\u0438 \u0444\u043E\u043A\u0443\u0441-\u0437\u0430\u043F\u0440\u043E\u0441 \u0435\u0441\u0442\u044C, \u043F\u0440\u043E\u0432\u0435\u0440\u044C \u0441\u043F\u0440\u043E\u0441 \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u043E\u043C analyze_keyword (\u043E\u0434\u0438\u043D \u0432\u044B\u0437\u043E\u0432). \u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0438 8 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0439 \u2264 70 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432 \u043D\u0430 \u044F\u0437\u044B\u043A\u0435 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430 \u043F\u043E\u0434 \u0440\u0430\u0437\u043D\u044B\u0435 \u0443\u0433\u043B\u044B (\u043F\u043E\u043B\u044C\u0437\u0430, \u0446\u0438\u0444\u0440\u044B, \u0432\u043E\u043F\u0440\u043E\u0441, \u043A\u043E\u043D\u0442\u0440\u0430\u0441\u0442, \u043E\u0448\u0438\u0431\u043A\u0430/\u0441\u0435\u043A\u0440\u0435\u0442, \xAB\u043A\u0430\u043A\xBB), \u0441 \u043A\u043B\u044E\u0447\u0435\u0432\u044B\u043C \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u043C \u0431\u043B\u0438\u0436\u0435 \u043A \u043D\u0430\u0447\u0430\u043B\u0443. \u041E\u0442\u0432\u0435\u0442\u044C \u0422\u041E\u041B\u042C\u041A\u041E JSON \u0431\u0435\u0437 \u043F\u043E\u044F\u0441\u043D\u0435\u043D\u0438\u0439: {"titles":[{"title":"...","angle":"\u043A\u0440\u0430\u0442\u043A\u043E \u043F\u043E\u0447\u0435\u043C\u0443 \u0441\u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442"}]}',
    en: `The creator is filling the upload form in YouTube Studio (draft in page_context: title, description, tags, focus keyword). If a focus keyword is set, check demand with analyze_keyword (one call). Propose 8 titles \u2264 70 characters in the draft's language with different angles (benefit, numbers, question, contrast, mistake/secret, "how to"), keyword near the start. Answer with JSON ONLY, no prose: {"titles":[{"title":"...","angle":"why it works, briefly"}]}`
  },
  studio_description: {
    ru: '\u0422\u0432\u043E\u0440\u0435\u0446 \u0437\u0430\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u0444\u043E\u0440\u043C\u0443 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u0432 YouTube Studio (\u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0432 page_context). \u041D\u0430\u043F\u0438\u0448\u0438 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043D\u0430 \u044F\u0437\u044B\u043A\u0435 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430: \u043F\u0435\u0440\u0432\u044B\u0435 2 \u0441\u0442\u0440\u043E\u043A\u0438 \u2014 \u0433\u043B\u0430\u0432\u043D\u044B\u0439 \u0437\u0430\u043F\u0440\u043E\u0441 \u0438 \u043A\u0440\u044E\u0447\u043E\u043A (\u043E\u043D\u0438 \u0432\u0438\u0434\u043D\u044B \u0432 \u043F\u043E\u0438\u0441\u043A\u0435), \u0437\u0430\u0442\u0435\u043C 2\u20134 \u043A\u043E\u0440\u043E\u0442\u043A\u0438\u0445 \u0430\u0431\u0437\u0430\u0446\u0430 \u043E \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u043D\u0438\u0438, \u043F\u0440\u0438 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u0438 \u0437\u0430\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u0434\u043B\u044F \u0433\u043B\u0430\u0432 (0:00 \u2026), 3 \u0445\u044D\u0448\u0442\u0435\u0433\u0430 \u0432 \u043A\u043E\u043D\u0446\u0435. 600\u20131500 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432. \u0421\u043E\u0445\u0440\u0430\u043D\u0438 \u0441\u0441\u044B\u043B\u043A\u0438 \u0438 \u0442\u0430\u0439\u043C\u043A\u043E\u0434\u044B \u0438\u0437 \u0442\u0435\u043A\u0443\u0449\u0435\u0433\u043E \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u044F, \u0435\u0441\u043B\u0438 \u043E\u043D\u0438 \u0435\u0441\u0442\u044C. \u041E\u0442\u0432\u0435\u0442\u044C \u0422\u041E\u041B\u042C\u041A\u041E JSON: {"description":"..."}',
    en: `The creator is filling the upload form in YouTube Studio (draft in page_context). Write a description in the draft's language: first 2 lines carry the main keyword and the hook (visible in search), then 2\u20134 short paragraphs, a chapters placeholder (0:00 \u2026) if useful, 3 hashtags at the end. 600\u20131500 characters. Keep links and timestamps from the current description if present. Answer with JSON ONLY: {"description":"..."}`
  },
  studio_compare: {
    ru: '\u0422\u0432\u043E\u0440\u0435\u0446 \u0437\u0430\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u0444\u043E\u0440\u043C\u0443 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u0432 YouTube Studio (\u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0432 page_context). \u041E\u0446\u0435\u043D\u0438, \u043D\u0430\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0435\u0433\u043E \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0432\u044B\u0434\u0435\u043B\u0438\u0442\u0441\u044F \u0441\u0440\u0435\u0434\u0438 \u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442\u043E\u0432: \u0432\u044B\u0437\u043E\u0432\u0438 search_youtube \u043F\u043E \u0444\u043E\u043A\u0443\u0441-\u0437\u0430\u043F\u0440\u043E\u0441\u0443 (\u0438\u043B\u0438 \u043F\u043E \u0441\u0443\u0442\u0438 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F) \u0441 max_results 12 \u0438 analyze_keyword. \u0421\u0440\u0430\u0432\u043D\u0438 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430 \u0441 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F\u043C\u0438 \u0442\u043E\u043F-\u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u043E\u0432: \u043F\u043E\u0432\u0442\u043E\u0440\u044F\u0435\u0442 \u043B\u0438 \u043E\u043D\u043E \u0448\u0430\u0431\u043B\u043E\u043D\u044B, \u0435\u0441\u0442\u044C \u043B\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0443\u0433\u043E\u043B, \u0432\u0438\u0434\u043D\u043E \u043B\u0438 \u043A\u043B\u044E\u0447\u0435\u0432\u043E\u0435 \u0441\u043B\u043E\u0432\u043E, \u043A\u0430\u043A\u043E\u0432\u0430 \u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0446\u0438\u044F. \u0414\u0430\u0439 \u043E\u0446\u0435\u043D\u043A\u0443 \u0432\u044B\u0434\u0435\u043B\u044F\u0435\u043C\u043E\u0441\u0442\u0438 0\u2013100, 3\u20135 \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u044B\u0445 \u043F\u0440\u0430\u0432\u043E\u043A \u0438 3 \u0430\u043B\u044C\u0442\u0435\u0440\u043D\u0430\u0442\u0438\u0432\u043D\u044B\u0445 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0441\u0438\u043B\u044C\u043D\u0435\u0435 \u043E\u0442\u043B\u0438\u0447\u0430\u044E\u0442\u0441\u044F. \u041E\u0442\u0432\u0435\u0442\u044C \u0422\u041E\u041B\u042C\u041A\u041E JSON: {"score":0-100,"verdict":"1\u20132 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F","competitors":[{"title":"...","views":0,"vph":0,"channel":"..."}],"fixes":["..."],"alternatives":["..."]}',
    en: 'The creator is filling the upload form in YouTube Studio (draft in page_context). Judge how much their title will stand out among competitors: call search_youtube for the focus keyword (or the gist of the title) with max_results 12 and analyze_keyword. Compare the draft title with the top results: does it repeat their patterns, does it have a unique angle, is the keyword visible, how strong is the competition. Give a stand-out score 0\u2013100, 3\u20135 concrete fixes and 3 alternative titles that differ more. Answer with JSON ONLY: {"score":0-100,"verdict":"1\u20132 sentences","competitors":[{"title":"...","views":0,"vph":0,"channel":"..."}],"fixes":["..."],"alternatives":["..."]}'
  },
  studio_magic_fill: {
    ru: '\u0422\u0432\u043E\u0440\u0435\u0446 \u0437\u0430\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u0444\u043E\u0440\u043C\u0443 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u0432 YouTube Studio (\u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0432 page_context: \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435, \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435, \u0442\u0435\u0433\u0438, \u0444\u043E\u043A\u0443\u0441-\u0437\u0430\u043F\u0440\u043E\u0441). \u0417\u0430\u043F\u043E\u043B\u043D\u0438 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0435 \u0446\u0435\u043B\u0438\u043A\u043E\u043C. \u0415\u0441\u043B\u0438 \u0444\u043E\u043A\u0443\u0441-\u0437\u0430\u043F\u0440\u043E\u0441 \u0435\u0441\u0442\u044C \u2014 \u043E\u0434\u0438\u043D \u0432\u044B\u0437\u043E\u0432 analyze_keyword \u0438\u043B\u0438 suggest_keywords, \u0447\u0442\u043E\u0431\u044B \u043E\u043F\u0435\u0440\u0435\u0442\u044C\u0441\u044F \u043D\u0430 \u0440\u0435\u0430\u043B\u044C\u043D\u044B\u0435 \u0437\u0430\u043F\u0440\u043E\u0441\u044B. \u0412\u0435\u0440\u043D\u0438: \u043B\u0443\u0447\u0448\u0435\u0435 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 (\u2264 70 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432, \u043A\u043B\u044E\u0447 \u0432 \u043D\u0430\u0447\u0430\u043B\u0435, \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u0438\u043A\u0430), \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 600\u20131500 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432 (\u043F\u0435\u0440\u0432\u044B\u0435 2 \u0441\u0442\u0440\u043E\u043A\u0438 \u2014 \u043A\u043B\u044E\u0447 \u0438 \u043A\u0440\u044E\u0447\u043E\u043A, \u0430\u0431\u0437\u0430\u0446\u044B \u043F\u043E \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u043D\u0438\u044E, \u0437\u0430\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u0433\u043B\u0430\u0432 \u0435\u0441\u043B\u0438 \u0443\u043C\u0435\u0441\u0442\u043D\u043E, 3 \u0445\u044D\u0448\u0442\u0435\u0433\u0430 \u0432 \u043A\u043E\u043D\u0446\u0435; \u0441\u043E\u0445\u0440\u0430\u043D\u0438 \u0441\u0441\u044B\u043B\u043A\u0438/\u0442\u0430\u0439\u043C\u043A\u043E\u0434\u044B \u0438\u0437 \u0442\u0435\u043A\u0443\u0449\u0435\u0433\u043E \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u044F), 15\u201320 \u0442\u0435\u0433\u043E\u0432 (\u0442\u043E\u0447\u043D\u044B\u0439 \u0437\u0430\u043F\u0440\u043E\u0441, \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B, \u0448\u0438\u0440\u043E\u043A\u0438\u0435 \u0442\u0435\u043C\u044B, \xAB\u0445\u0432\u043E\u0441\u0442\u044B\xBB; \u0434\u043E 450 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432). \u0412\u0441\u0451 \u043D\u0430 \u044F\u0437\u044B\u043A\u0435 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430. \u041E\u0442\u0432\u0435\u0442\u044C \u0422\u041E\u041B\u042C\u041A\u041E JSON: {"title":"...","description":"...","tags":["..."]}',
    en: `The creator is filling the upload form in YouTube Studio (draft in page_context: title, description, tags, focus keyword). Fill in all metadata. If a focus keyword exists, make one analyze_keyword or suggest_keywords call to ground it in real queries. Return: the best title (\u2264 70 chars, keyword first, specific), a 600\u20131500 character description (first 2 lines keyword + hook, paragraphs on the content, chapters placeholder if useful, 3 hashtags at the end; keep links/timestamps from the current description), 15\u201320 tags (exact query, variants, broad topics, long-tails; under 450 chars). All in the draft's language. Answer with JSON ONLY: {"title":"...","description":"...","tags":["..."]}`
  },
  studio_thumbnail: {
    ru: '\u041A \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044E \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0430 \u043A\u0430\u0440\u0442\u0438\u043D\u043A\u0430 \u2014 \u043F\u0440\u0435\u0432\u044C\u044E (thumbnail) \u0432\u0438\u0434\u0435\u043E \u0438\u0437 YouTube Studio; \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F/\u043E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u2014 \u0432 page_context. \u041E\u0446\u0435\u043D\u0438 \u043F\u0440\u0435\u0432\u044C\u044E \u043A\u0430\u043A \u044D\u043A\u0441\u043F\u0435\u0440\u0442 \u043F\u043E CTR \u043D\u0430 YouTube: \u0447\u0438\u0442\u0430\u0435\u043C\u043E\u0441\u0442\u044C \u043F\u0440\u0438 \u0440\u0430\u0437\u043C\u0435\u0440\u0435 168\xD794 (\u043C\u043E\u0431\u0438\u043B\u044C\u043D\u0430\u044F \u043B\u0435\u043D\u0442\u0430), \u043A\u043E\u043D\u0442\u0440\u0430\u0441\u0442 \u0438 \u0444\u043E\u043A\u0443\u0441, \u043B\u0438\u0446\u043E/\u044D\u043C\u043E\u0446\u0438\u044F, \u043A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0438 \u0440\u0430\u0437\u043C\u0435\u0440 \u0442\u0435\u043A\u0441\u0442\u0430 (\u2264 3\u20134 \u0441\u043B\u043E\u0432\u0430), \u0434\u0443\u0431\u043B\u0438\u0440\u0443\u0435\u0442 \u043B\u0438 \u0442\u0435\u043A\u0441\u0442 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 (\u043F\u043B\u043E\u0445\u043E) \u0438\u043B\u0438 \u0434\u043E\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u0435\u0433\u043E (\u0445\u043E\u0440\u043E\u0448\u043E), \u0446\u0432\u0435\u0442\u043E\u0432\u043E\u0439 \u0430\u043A\u0446\u0435\u043D\u0442, \u0437\u0430\u0433\u0440\u043E\u043C\u043E\u0436\u0434\u0451\u043D\u043D\u043E\u0441\u0442\u044C, \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 \u0442\u0435\u043C\u0435. \u0414\u0430\u0439 \u043E\u0446\u0435\u043D\u043A\u0443 0\u2013100, 3 \u0441\u0438\u043B\u044C\u043D\u044B\u0435 \u0441\u0442\u043E\u0440\u043E\u043D\u044B, 3\u20135 \u043F\u0440\u043E\u0431\u043B\u0435\u043C, 3\u20135 \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u044B\u0445 \u043F\u0440\u0430\u0432\u043E\u043A \u0438 3 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u0430 \u043A\u043E\u0440\u043E\u0442\u043A\u043E\u0433\u043E \u0442\u0435\u043A\u0441\u0442\u0430 \u043D\u0430 \u043F\u0440\u0435\u0432\u044C\u044E. \u041E\u0442\u0432\u0435\u0442\u044C \u0422\u041E\u041B\u042C\u041A\u041E JSON: {"score":0-100,"verdict":"1\u20132 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F","text_on_thumbnail":"\u0447\u0442\u043E \u043D\u0430\u043F\u0438\u0441\u0430\u043D\u043E \u0441\u0435\u0439\u0447\u0430\u0441 \u0438\u043B\u0438 \u043F\u0443\u0441\u0442\u043E","strengths":["..."],"issues":["..."],"suggestions":["..."],"text_ideas":["..."]}',
    en: 'The message has an image attached \u2014 the video thumbnail from YouTube Studio; the title/description draft is in page_context. Evaluate the thumbnail as a YouTube CTR expert: legibility at 168\xD794 (mobile feed), contrast and focal point, face/emotion, amount and size of text (\u2264 3\u20134 words), whether the text duplicates the title (bad) or complements it (good), color accent, clutter, fit with the topic. Give a 0\u2013100 score, 3 strengths, 3\u20135 issues, 3\u20135 concrete fixes and 3 short text ideas. Answer with JSON ONLY: {"score":0-100,"verdict":"1\u20132 sentences","text_on_thumbnail":"current text or empty","strengths":["..."],"issues":["..."],"suggestions":["..."],"text_ideas":["..."]}'
  },
  studio_tags: {
    ru: '\u0422\u0432\u043E\u0440\u0435\u0446 \u0437\u0430\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u0444\u043E\u0440\u043C\u0443 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u0432 YouTube Studio (\u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u0432 page_context). \u0415\u0441\u043B\u0438 \u0435\u0441\u0442\u044C \u0444\u043E\u043A\u0443\u0441-\u0437\u0430\u043F\u0440\u043E\u0441, \u0432\u044B\u0437\u043E\u0432\u0438 suggest_keywords \u0441 expand=true \u0438, \u043F\u043E \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0438, search_youtube \u043F\u043E \u0437\u0430\u043F\u0440\u043E\u0441\u0443, \u0447\u0442\u043E\u0431\u044B \u0443\u0432\u0438\u0434\u0435\u0442\u044C, \u043A\u0430\u043A \u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442\u044B \u043D\u0430\u0437\u044B\u0432\u0430\u044E\u0442 \u0442\u0435\u043C\u0443. \u0421\u043E\u0441\u0442\u0430\u0432\u044C 20 \u0442\u0435\u0433\u043E\u0432 \u043D\u0430 \u044F\u0437\u044B\u043A\u0435 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430: \u0442\u043E\u0447\u043D\u044B\u0439 \u0437\u0430\u043F\u0440\u043E\u0441, \u0435\u0433\u043E \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B \u043D\u0430\u043F\u0438\u0441\u0430\u043D\u0438\u044F, \u0448\u0438\u0440\u043E\u043A\u0438\u0435 \u0442\u0435\u043C\u044B, 3\u20135 \u0434\u043B\u0438\u043D\u043D\u044B\u0445 \xAB\u0445\u0432\u043E\u0441\u0442\u043E\u0432\xBB. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u0430\u043C\u044B\u0435 \u0432\u0430\u0436\u043D\u044B\u0435. \u0421\u0443\u043C\u043C\u0430\u0440\u043D\u043E \u0434\u043E 450 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432. \u041E\u0442\u0432\u0435\u0442\u044C \u0422\u041E\u041B\u042C\u041A\u041E JSON: {"tags":["...","..."]}',
    en: `The creator is filling the upload form in YouTube Studio (draft in page_context). If a focus keyword exists, call suggest_keywords with expand=true and, if useful, search_youtube to see how competitors name the topic. Produce 20 tags in the draft's language: the exact query, spelling variants, broad topics, 3\u20135 long-tail phrases. Most important first. Under 450 characters total. Answer with JSON ONLY: {"tags":["...","..."]}`
  }
};
function actionPrompt(action, lang) {
  return ACTION_PROMPTS[action][lang];
}
function renderPageContext(ctx) {
  if (!ctx) return "<page_context>none (no YouTube tab is active)</page_context>";
  const c = {
    kind: ctx.kind,
    url: ctx.url,
    page_title: ctx.title,
    captured_at: ctx.capturedAt
  };
  if (ctx.draft) c.studio_draft = ctx.draft;
  if (ctx.video) {
    const v = { ...ctx.video };
    if (v.description && v.description.length > 2e3) v.description = v.description.slice(0, 2e3) + " \u2026[truncated]";
    delete v.captionTracks;
    c.video = v;
    if (ctx.video.captionTracks?.length) c.caption_languages = ctx.video.captionTracks.map((t) => `${t.lang}${t.auto ? " (auto)" : ""}`);
  }
  if (ctx.metrics) {
    const m = { ...ctx.metrics };
    if (m.seo) c.seo = { score: m.seo.score, failed_checks: m.seo.checks.filter((x) => !x.ok).map((x) => x.id) };
    delete m.seo;
    c.metrics = roundNumbers(m);
  }
  if (ctx.query) c.search_query = ctx.query;
  if (ctx.results?.length) c.search_results = ctx.results.slice(0, 20).map(compactListVideo);
  if (ctx.related?.length) c.related_videos = ctx.related.slice(0, 12).map(compactListVideo);
  if (ctx.channel) c.channel = ctx.channel;
  if (ctx.channelVideos?.length) c.channel_videos = ctx.channelVideos.slice(0, 30).map(compactListVideo);
  if (ctx.comments?.length) c.visible_comments = ctx.comments.slice(0, 20);
  return `<page_context>
${JSON.stringify(c, null, 0)}
</page_context>`;
}
function compactListVideo(v) {
  return roundNumbers({
    id: v.videoId,
    title: v.title,
    channel: v.channelName,
    channel_id: v.channelId,
    views: v.views,
    age_hours: v.ageHours,
    vph: v.vph,
    duration_sec: v.durationSec,
    subscribers: v.subscribers,
    live: v.isLive || void 0,
    short: v.isShort || void 0
  });
}
function roundNumbers(obj) {
  const out = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v === void 0) continue;
    out[k] = typeof v === "number" && !Number.isInteger(v) ? Math.round(v * 1e3) / 1e3 : v;
  }
  return out;
}

// src/background/keyword.ts
async function keywordReport(youtube2, query, lang, maxResults = 20) {
  const [results, suggestions] = await Promise.all([
    youtube2.search(query, maxResults, "relevance"),
    youtube2.suggestions(query, lang).catch(() => [])
  ]);
  const a = analyzeKeyword(query, results);
  return { ...a, suggestions, topResults: results.slice(0, 12) };
}
async function videoTags(youtube2, ids, limit2 = 6) {
  const out = {};
  await Promise.all(
    ids.slice(0, limit2).map(async (id) => {
      try {
        const v = await youtube2.pageVideo(id);
        out[id] = v.tags ?? [];
      } catch {
        out[id] = [];
      }
    })
  );
  return out;
}

// src/shared/competitors.ts
var ALERT_MAX_AGE_HOURS = 14 * 24;
var ALERT_MIN_OUTLIER = 2;
var ALERT_MIN_VPH = 500;
function competitorKey(c) {
  return (c.channelId ?? c.handle ?? "").toLowerCase();
}
function snapshotFromStats(key, stats, now = Date.now()) {
  const med = stats.medianViews ?? 0;
  const videos = stats.videos.map((v) => ({ ...v, ageHours: v.ageHours ?? ageHoursFromIso(v.publishedAt, now), outlier: med && v.views !== void 0 ? v.views / med : void 0 })).filter((v) => v.views !== void 0);
  const ages = videos.map((v) => v.ageHours).filter((x) => x !== void 0);
  const top = [...videos].sort((a, b) => (b.outlier ?? 0) - (a.outlier ?? 0)).slice(0, 6);
  return {
    key,
    name: stats.channel.name ?? stats.channel.handle ?? key,
    channelId: stats.channel.channelId,
    handle: stats.channel.handle,
    subscribers: stats.channel.subscribers,
    medianViews: stats.medianViews,
    uploadsPerWeek: stats.uploadsPerWeek,
    lastUploadAgeHours: ages.length ? Math.min(...ages) : void 0,
    topVideos: top.map(compactVideo),
    fetchedAt: now
  };
}
function compactVideo(v) {
  return { videoId: v.videoId, title: v.title, views: v.views, ageHours: v.ageHours, vph: v.vph, outlier: v.outlier };
}
function computeAlerts(snapshot, stats, known, now = Date.now()) {
  const med = stats.medianViews ?? 0;
  const out = [];
  for (const v of stats.videos) {
    if (v.views === void 0 || known.has(v.videoId)) continue;
    const age = v.ageHours ?? ageHoursFromIso(v.publishedAt, now);
    if (age === void 0 || age > ALERT_MAX_AGE_HOURS) continue;
    const outlier = med ? v.views / med : void 0;
    const vph = v.vph ?? (age ? v.views / Math.max(age, 1) : void 0);
    if ((outlier ?? 0) >= ALERT_MIN_OUTLIER || (vph ?? 0) >= ALERT_MIN_VPH) {
      out.push({ channelKey: snapshot.key, channelName: snapshot.name, videoId: v.videoId, title: v.title, views: v.views, ageHours: age, vph, outlier, seenAt: now, unseen: true });
    }
  }
  return out.sort((a, b) => (b.outlier ?? 0) - (a.outlier ?? 0));
}

// src/background/competitors.ts
var SNAP_KEY2 = "competitorSnapshots";
var ALERTS_KEY = "competitorAlerts";
var ALARM = "nubit-competitors";
var MAX_ALERTS = 120;
async function getCompetitorsState() {
  const s = await loadSettings();
  const stored = await chrome.storage.local.get([SNAP_KEY2, ALERTS_KEY]);
  return {
    competitors: s.competitors,
    snapshots: stored[SNAP_KEY2] ?? {},
    alerts: stored[ALERTS_KEY] ?? []
  };
}
async function addCompetitor(youtube2, channel) {
  const s = await loadSettings();
  if (s.competitors.length >= 30) return { ok: false, message: "limit:30" };
  const stats = await youtube2.channelStats(channel, 25);
  const c = { channelId: stats.channel.channelId, handle: stats.channel.handle, name: stats.channel.name ?? stats.channel.handle ?? channel, addedAt: Date.now() };
  const key = competitorKey(c);
  if (!key) return { ok: false, message: "unresolved" };
  if (s.competitors.some((x) => competitorKey(x) === key)) return { ok: true, message: "exists", competitor: c };
  s.competitors.push(c);
  await saveSettings(s);
  const snapshots = (await chrome.storage.local.get(SNAP_KEY2))[SNAP_KEY2] ?? {};
  snapshots[key] = snapshotFromStats(key, stats);
  await chrome.storage.local.set({ [SNAP_KEY2]: snapshots });
  ensureAlarm();
  return { ok: true, message: "added", competitor: c };
}
async function removeCompetitor(key) {
  const s = await loadSettings();
  s.competitors = s.competitors.filter((x) => competitorKey(x) !== key);
  await saveSettings(s);
  const stored = await chrome.storage.local.get([SNAP_KEY2, ALERTS_KEY]);
  const snapshots = stored[SNAP_KEY2] ?? {};
  delete snapshots[key];
  const alerts = (stored[ALERTS_KEY] ?? []).filter((a) => a.channelKey !== key);
  await chrome.storage.local.set({ [SNAP_KEY2]: snapshots, [ALERTS_KEY]: alerts });
  await updateBadge(alerts);
}
async function refreshCompetitors(youtube2, settings) {
  const s = settings ?? await loadSettings();
  const stored = await chrome.storage.local.get([SNAP_KEY2, ALERTS_KEY]);
  const snapshots = stored[SNAP_KEY2] ?? {};
  let alerts = stored[ALERTS_KEY] ?? [];
  const known = new Set(alerts.map((a) => a.videoId));
  for (const c of s.competitors) {
    const key = competitorKey(c);
    if (!key) continue;
    try {
      const stats = await youtube2.channelStats(c.channelId ?? c.handle, 25, false);
      const snap = snapshotFromStats(key, stats);
      snapshots[key] = snap;
      const fresh = computeAlerts(snap, stats, known).filter((a) => a.ageHours === void 0 || Date.now() - a.ageHours * 36e5 >= c.addedAt - 24 * 36e5);
      for (const a of fresh) known.add(a.videoId);
      alerts = [...fresh, ...alerts];
    } catch {
    }
  }
  alerts = alerts.slice(0, MAX_ALERTS);
  await chrome.storage.local.set({ [SNAP_KEY2]: snapshots, [ALERTS_KEY]: alerts });
  await updateBadge(alerts);
  return { competitors: s.competitors, snapshots, alerts };
}
async function markAlertsSeen() {
  const alerts = (await chrome.storage.local.get(ALERTS_KEY))[ALERTS_KEY] ?? [];
  for (const a of alerts) a.unseen = false;
  await chrome.storage.local.set({ [ALERTS_KEY]: alerts });
  await updateBadge(alerts);
}
async function updateBadge(alerts) {
  const n = alerts.filter((a) => a.unseen).length;
  try {
    await chrome.action.setBadgeBackgroundColor({ color: "#ea580c" });
    await chrome.action.setBadgeText({ text: n ? String(n) : "" });
  } catch {
  }
}
function ensureAlarm() {
  chrome.alarms.get(ALARM).then((a) => {
    if (!a) chrome.alarms.create(ALARM, { periodInMinutes: 360, delayInMinutes: 5 });
  });
}

// src/background/tools.ts
function validateInput(schema, input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return "input must be an object";
  const obj = input;
  for (const key of schema.required ?? []) if (obj[key] === void 0) return `missing required field "${key}"`;
  for (const [key, val] of Object.entries(obj)) {
    const prop = schema.properties[key];
    if (!prop) continue;
    if (val === void 0 || val === null) continue;
    const t = prop.type;
    const ok = t === "string" && typeof val === "string" || (t === "number" || t === "integer") && typeof val === "number" && isFinite(val) || t === "boolean" && typeof val === "boolean" || t === "array" && Array.isArray(val) || t === "object" && typeof val === "object";
    if (!ok) return `field "${key}" must be of type ${t}`;
    if (prop.enum && typeof val === "string" && !prop.enum.includes(val)) return `field "${key}" must be one of ${prop.enum.join(", ")}`;
    if (t === "array" && prop.items && val.some((x) => typeof x !== prop.items.type)) return `field "${key}" items must be ${prop.items.type}`;
  }
  return null;
}
var MAX_TEXT = 16e3;
function clip(text, max = MAX_TEXT) {
  return text.length > max ? text.slice(0, max) + `
\u2026[truncated ${text.length - max} characters]` : text;
}
function json(x) {
  return clip(JSON.stringify(x, (_k, v) => typeof v === "number" && !Number.isInteger(v) ? Math.round(v * 1e3) / 1e3 : v));
}
function listRow(v) {
  return roundNumbers({
    id: v.videoId,
    title: v.title,
    channel: v.channelName,
    channel_id: v.channelId ?? v.channelHandle,
    subscribers: v.subscribers,
    views: v.views,
    likes: v.likes,
    comments: v.comments,
    age_hours: v.ageHours,
    published: v.publishedAt ?? v.publishedText,
    vph: v.vph,
    duration_sec: v.durationSec,
    live: v.isLive || void 0,
    short: v.isShort || void 0
  });
}
function errorText2(err) {
  if (err instanceof YouTubeError || err instanceof NativeHostError) return `Error: ${err.message}`;
  if (err instanceof Error) return `Error: ${err.message}`;
  return `Error: ${String(err)}`;
}
var T = (ru, en) => (lang) => lang === "ru" ? ru : en;
function buildTools(settings) {
  const tools = [];
  tools.push({
    def: {
      name: "get_page_context",
      description: "Returns fresh data about the YouTube page currently open in the browser (video details and metrics, search results, channel, visible comments). Use when the context attached to the message is missing or stale.",
      input_schema: { type: "object", properties: {}, additionalProperties: false }
    },
    summary: (_i, l) => T("\u0427\u0438\u0442\u0430\u044E \u043E\u0442\u043A\u0440\u044B\u0442\u0443\u044E \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443", "Reading the open page")(l),
    run: async (_input, ctx) => {
      const pc = await ctx.getPageContext(ctx.tabId);
      if (!pc) return "No YouTube tab is active (open a video, search or channel on youtube.com).";
      return json(pc);
    }
  });
  tools.push({
    def: {
      name: "get_video",
      description: "Full details and metrics for one video: title, channel, views, likes, comments, publish date, duration, tags, description, VPH, engagement, SEO score, and outlier vs the channel (when include_channel is true).",
      input_schema: {
        type: "object",
        properties: {
          video: { type: "string", description: "Video id or URL" },
          include_channel: { type: "boolean", description: "Also fetch the channel baseline (median views) to compute the outlier score. Default true." }
        },
        required: ["video"],
        additionalProperties: false
      }
    },
    summary: (i, l) => T(`\u0414\u0430\u043D\u043D\u044B\u0435 \u0432\u0438\u0434\u0435\u043E ${i.video}`, `Video data ${i.video}`)(l),
    run: async (input, ctx) => {
      try {
        const v = await ctx.youtube.getVideo(input.video);
        let channelViews;
        let channelInfo;
        if (input.include_channel !== false && (v.channelId || v.channelHandle)) {
          try {
            const st = await ctx.youtube.channelStats(v.channelId ?? v.channelHandle, 25);
            channelViews = st.videos.filter((x) => x.videoId !== v.videoId).map((x) => x.views).filter((x) => x !== void 0);
            channelInfo = { subscribers: st.channel.subscribers ?? v.subscribers, median_views: st.medianViews, uploads_per_week: st.uploadsPerWeek, sample: st.videos.length };
            if (!v.subscribers) v.subscribers = st.channel.subscribers;
          } catch (err) {
            channelInfo = { error: errorText2(err) };
          }
        }
        const metrics = computeMetrics(v, ctx.lang, channelViews);
        const out = {
          ...v,
          description: v.description ? clip(v.description, 3e3) : void 0,
          captionTracks: void 0,
          caption_languages: v.captionTracks?.map((t) => `${t.lang}${t.auto ? " (auto)" : ""}`),
          metrics: { ...metrics, seo: metrics.seo ? { score: metrics.seo.score, failed: metrics.seo.checks.filter((c) => !c.ok).map((c) => c.id) } : void 0 },
          channel: channelInfo
        };
        return json(out);
      } catch (err) {
        return errorText2(err);
      }
    }
  });
  tools.push({
    def: {
      name: "search_youtube",
      description: "Searches YouTube and returns videos with views, age, VPH, duration and channel. Use for competitors, topic research and checking what ranks for a query.",
      input_schema: {
        type: "object",
        properties: {
          query: { type: "string" },
          max_results: { type: "integer", description: "1\u201330, default 15", minimum: 1, maximum: 30 },
          order: { type: "string", enum: ["relevance", "date", "viewCount"], description: "Default relevance" }
        },
        required: ["query"],
        additionalProperties: false
      }
    },
    summary: (i, l) => T(`\u041F\u043E\u0438\u0441\u043A YouTube: \xAB${i.query}\xBB`, `YouTube search: "${i.query}"`)(l),
    run: async (input, ctx) => {
      try {
        const res = await ctx.youtube.search(input.query, Math.min(30, input.max_results ?? 15), input.order ?? "relevance");
        return json({ query: input.query, count: res.length, results: res.map(listRow) });
      } catch (err) {
        return errorText2(err);
      }
    }
  });
  tools.push({
    def: {
      name: "get_channel_videos",
      description: "A channel's recent uploads with views/age/VPH plus the channel baseline: median and average views, uploads per week, subscribers. Use to judge whether a video is an outlier and to review a channel.",
      input_schema: {
        type: "object",
        properties: {
          channel: { type: "string", description: "Channel id (UC\u2026), @handle, or channel URL" },
          max_results: { type: "integer", description: "5\u201350, default 25", minimum: 5, maximum: 50 }
        },
        required: ["channel"],
        additionalProperties: false
      }
    },
    summary: (i, l) => T(`\u0412\u0438\u0434\u0435\u043E \u043A\u0430\u043D\u0430\u043B\u0430 ${i.channel}`, `Channel uploads ${i.channel}`)(l),
    run: async (input, ctx) => {
      try {
        const st = await ctx.youtube.channelStats(input.channel, Math.min(50, input.max_results ?? 25));
        const med = st.medianViews;
        const videos = st.videos.map((v) => ({ ...listRow(v), outlier: med && v.views !== void 0 ? Math.round(v.views / med * 100) / 100 : void 0 }));
        return json({
          channel: st.channel,
          median_views: st.medianViews,
          avg_views: st.avgViews,
          uploads_per_week: st.uploadsPerWeek,
          sample_size: st.videos.length,
          videos
        });
      } catch (err) {
        return errorText2(err);
      }
    }
  });
  tools.push({
    def: {
      name: "get_transcript",
      description: "Returns the transcript (subtitles) of a video as timestamped text. Prefers manual captions in the requested languages, falls back to auto-generated ones, then to yt-dlp if configured. Long transcripts are paginated with offset_chars.",
      input_schema: {
        type: "object",
        properties: {
          video: { type: "string", description: "Video id or URL" },
          languages: { type: "array", items: { type: "string" }, description: 'Preferred language codes in order, e.g. ["ru","en"]' },
          offset_chars: { type: "integer", description: "Start offset for long transcripts (default 0)", minimum: 0 }
        },
        required: ["video"],
        additionalProperties: false
      }
    },
    summary: (i, l) => T(`\u0421\u0443\u0431\u0442\u0438\u0442\u0440\u044B \u0432\u0438\u0434\u0435\u043E ${i.video}`, `Transcript of ${i.video}`)(l),
    run: async (input, ctx) => {
      try {
        const langs = input.languages?.length ? input.languages : [ctx.lang, "en"];
        const r = await ctx.youtube.transcript(input.video, langs);
        const offset = input.offset_chars ?? 0;
        const slice = r.text.slice(offset, offset + MAX_TEXT);
        const more = r.text.length > offset + MAX_TEXT;
        return `language: ${r.lang}${r.auto ? " (auto-generated)" : ""}; source: ${r.source}; available: ${r.available.join(", ") || "unknown"}; total_chars: ${r.text.length}` + (more ? `; next_offset_chars: ${offset + MAX_TEXT}` : "") + `

${slice}`;
      } catch (err) {
        return errorText2(err);
      }
    }
  });
  tools.push({
    def: {
      name: "get_comments",
      description: "Top comments of a video (author, text, likes). Needs a YouTube Data API key; without it only comments already visible on the open page are available via get_page_context.",
      input_schema: {
        type: "object",
        properties: {
          video: { type: "string", description: "Video id or URL" },
          max_results: { type: "integer", description: "1\u2013100, default 30", minimum: 1, maximum: 100 }
        },
        required: ["video"],
        additionalProperties: false
      }
    },
    summary: (i, l) => T(`\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0438 \u043A ${i.video}`, `Comments of ${i.video}`)(l),
    run: async (input, ctx) => {
      try {
        const list = await ctx.youtube.comments(input.video, input.max_results ?? 30);
        return json({ count: list.length, comments: list.map((c) => ({ ...c, text: clip(c.text, 600) })) });
      } catch (err) {
        const id = extractVideoId(input.video);
        const pc = await ctx.getPageContext(ctx.tabId).catch(() => null);
        if (pc && pc.video?.videoId === id && pc.comments?.length) {
          return json({ note: "From the open page (no API key): only comments already loaded on screen.", count: pc.comments.length, comments: pc.comments });
        }
        return errorText2(err);
      }
    }
  });
  tools.push({
    def: {
      name: "suggest_keywords",
      description: "YouTube autocomplete suggestions for a query \u2014 what people actually type. With expand=true also queries the phrase followed by each letter to get long-tail variants.",
      input_schema: {
        type: "object",
        properties: {
          query: { type: "string" },
          language: { type: "string", description: 'Interface language code for suggestions, e.g. "ru" or "en". Default: extension language.' },
          expand: { type: "boolean", description: 'Also fetch "<query> a", "<query> b", \u2026 (long-tail). Default false.' }
        },
        required: ["query"],
        additionalProperties: false
      }
    },
    summary: (i, l) => T(`\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438 \u043F\u043E \u0437\u0430\u043F\u0440\u043E\u0441\u0443 \xAB${i.query}\xBB`, `Suggestions for "${i.query}"`)(l),
    run: async (input, ctx) => {
      try {
        const lang = input.language ?? ctx.lang;
        const base = await ctx.youtube.suggestions(input.query, lang);
        const set = new Set(base);
        if (input.expand) {
          const letters = /[Ѐ-ӿ]/.test(input.query) ? "\u043A\u0430\u043A\u0447\u043F\u0441\u0432\u0434\u043D\u0442".split("") : "abcdefhimpstw".split("");
          const extra = await Promise.all(letters.map((ch) => ctx.youtube.suggestions(`${input.query} ${ch}`, lang).catch(() => [])));
          for (const list of extra) for (const s of list) set.add(s);
        }
        return json({ query: input.query, suggestions: [...set] });
      } catch (err) {
        return errorText2(err);
      }
    }
  });
  tools.push({
    def: {
      name: "analyze_keyword",
      description: "Keyword/topic analysis: searches the query, summarizes the top results (median views, age, how many titles contain the exact phrase, small channels that still rank), fetches autocomplete suggestions, and returns demand and competition estimates (0\u2013100).",
      input_schema: {
        type: "object",
        properties: {
          query: { type: "string" },
          language: { type: "string", description: "Language code for suggestions. Default: extension language." }
        },
        required: ["query"],
        additionalProperties: false
      }
    },
    summary: (i, l) => T(`\u0410\u043D\u0430\u043B\u0438\u0437 \u0437\u0430\u043F\u0440\u043E\u0441\u0430 \xAB${i.query}\xBB`, `Keyword analysis "${i.query}"`)(l),
    run: async (input, ctx) => {
      try {
        const r = await keywordReport(ctx.youtube, input.query, input.language ?? ctx.lang);
        return json({
          ...r,
          smallChannelWinners: r.smallChannelWinners.map(listRow),
          topResults: void 0,
          top_results: r.topResults.map(listRow),
          note: "demand/competition are heuristic estimates (YouTube publishes no search volume)."
        });
      } catch (err) {
        return errorText2(err);
      }
    }
  });
  tools.push({
    def: {
      name: "get_competitors",
      description: "The user's tracked competitor channels with their baseline (median views, uploads per week, subscribers), their best recent videos by outlier score, and recent alerts (new videos that beat the channel's baseline). Use for daily ideas, trend spotting and benchmarking.",
      input_schema: { type: "object", properties: {}, additionalProperties: false }
    },
    summary: (_i, l) => T("\u0427\u0438\u0442\u0430\u044E \u0441\u043F\u0438\u0441\u043E\u043A \u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442\u043E\u0432", "Reading tracked competitors")(l),
    run: async () => {
      const st = await getCompetitorsState();
      if (!st.competitors.length) return 'No competitors tracked yet. The user can add channels with the "+ Competitor" button on a video or channel page.';
      return json({
        competitors: Object.values(st.snapshots).map((s) => roundNumbers({ name: s.name, handle: s.handle, channel_id: s.channelId, subscribers: s.subscribers, median_views: s.medianViews, uploads_per_week: s.uploadsPerWeek, last_upload_age_hours: s.lastUploadAgeHours, top_recent_videos: s.topVideos.map((v) => roundNumbers({ id: v.videoId, title: v.title, views: v.views, age_hours: v.ageHours, vph: v.vph, outlier: v.outlier })) })),
        alerts: st.alerts.slice(0, 30).map((a) => roundNumbers({ channel: a.channelName, id: a.videoId, title: a.title, views: a.views, age_hours: a.ageHours, vph: a.vph, outlier: a.outlier }))
      });
    }
  });
  const apis = settings.customApis.filter((a) => a.name && a.baseUrl);
  if (apis.length) {
    tools.push({
      def: {
        name: "call_custom_api",
        description: "Calls one of the HTTP APIs the user registered in settings. Available APIs:\n" + apis.map((a) => `- "${a.name}": base ${a.baseUrl}. ${a.description}`).join("\n"),
        input_schema: {
          type: "object",
          properties: {
            api: { type: "string", enum: apis.map((a) => a.name), description: "API name" },
            method: { type: "string", enum: ["GET", "POST", "PUT", "PATCH", "DELETE"], description: "Default GET" },
            path: { type: "string", description: 'Path appended to the base URL, e.g. "/v1/search"' },
            query: { type: "object", description: "Query-string parameters" },
            body: { type: "object", description: "JSON body for POST/PUT/PATCH" }
          },
          required: ["api", "path"],
          additionalProperties: false
        }
      },
      summary: (i, l) => T(`\u0412\u044B\u0437\u043E\u0432 API ${i.api}: ${i.path}`, `API call ${i.api}: ${i.path}`)(l),
      run: async (input) => {
        const api = apis.find((a) => a.name === input.api);
        if (!api) return `Error: unknown API "${input.api}"`;
        try {
          const u = new URL(String(input.path).replace(/^\//, ""), api.baseUrl.replace(/\/?$/, "/"));
          for (const [k, v] of Object.entries(input.query ?? {})) u.searchParams.set(k, String(v));
          const origin = `${u.protocol}//${u.host}/*`;
          const allowed = await chrome.permissions.contains({ origins: [origin] }).catch(() => false);
          if (!allowed) return `Error: the extension has no permission for ${u.host}. Open Settings \u2192 Custom APIs and press "Grant access" for "${api.name}".`;
          const method = (input.method ?? "GET").toUpperCase();
          const headers = { ...api.headers };
          if (input.body && !headers["Content-Type"] && !headers["content-type"]) headers["Content-Type"] = "application/json";
          const res = await fetch(u.toString(), {
            method,
            headers,
            body: input.body && method !== "GET" ? JSON.stringify(input.body) : void 0
          });
          const text = await res.text();
          return `HTTP ${res.status}
${clip(text, 2e4)}`;
        } catch (err) {
          return errorText2(err);
        }
      }
    });
  }
  const local = settings.localTools.filter((t) => t.name && t.path);
  if (local.length) {
    tools.push({
      def: {
        name: "run_local_tool",
        description: "Runs a program installed on the user's computer (through the Nubit native host) and returns stdout/stderr. Available programs:\n" + local.map((t) => `- "${t.name}": ${t.description || t.path}`).join("\n") + '\nPass arguments as an array (no shell). Keep outputs small (use --print / -j / --quiet flags). Example: yt-dlp with ["--skip-download","--print","%(title)s","<url>"].',
        input_schema: {
          type: "object",
          properties: {
            tool: { type: "string", enum: local.map((t) => t.name) },
            args: { type: "array", items: { type: "string" }, description: "Command-line arguments" },
            timeout_sec: { type: "integer", description: "Default 120, max 600", minimum: 1, maximum: 600 }
          },
          required: ["tool", "args"],
          additionalProperties: false
        }
      },
      summary: (i, l) => T(`\u0417\u0430\u043F\u0443\u0441\u043A ${i.tool} ${(i.args ?? []).join(" ").slice(0, 80)}`, `Running ${i.tool} ${(i.args ?? []).join(" ").slice(0, 80)}`)(l),
      run: async (input, ctx) => {
        const tool = local.find((t) => t.name === input.tool);
        if (!tool) return `Error: unknown tool "${input.tool}"`;
        try {
          const r = await nativeExec(ctx.settings.nativeHostName, tool.path, input.args ?? [], {
            timeoutMs: Math.min(600, input.timeout_sec ?? 120) * 1e3,
            maxOutput: 6e4
          });
          return `exit code: ${r.code}${r.timedOut ? " (timed out)" : ""}
--- stdout ---
${clip(r.stdout, 3e4)}
--- stderr ---
${clip(r.stderr, 6e3)}`;
        } catch (err) {
          return errorText2(err);
        }
      }
    });
  }
  return tools;
}

// src/background/agent.ts
var MAX_STEPS = 14;
var MAX_HISTORY = 40;
async function runAgent(run) {
  const { settings, signal, emit } = run;
  const provider = createProvider(settings);
  const tools = buildTools(settings);
  const toolMap = new Map(tools.map((t) => [t.def.name, t]));
  const system = buildSystemPrompt(settings, {
    nativeTools: settings.localTools.filter((t) => t.path).map((t) => t.name),
    customApis: settings.customApis.filter((a) => a.name && a.baseUrl).map((a) => a.name),
    youtubeApi: !!settings.youtubeApiKey
  });
  const ctx = { ...run.ctx, settings, lang: settings.language };
  const messages = trimHistory(run.history);
  const appended = [];
  for (let step = 0; step < MAX_STEPS; step++) {
    if (signal.aborted) break;
    const result = await provider.run({
      system,
      messages,
      tools: tools.map((t) => t.def),
      onText: (delta) => emit({ type: "delta", text: delta }),
      signal
    });
    const assistant = {
      role: "assistant",
      content: result.text,
      toolCalls: result.toolCalls.length ? result.toolCalls : void 0,
      raw: result.raw,
      rawProvider: provider.rawKey,
      rawModel: result.model ?? provider.model
    };
    messages.push(assistant);
    appended.push(assistant);
    emit({ type: "assistant", message: assistant });
    if (result.stop === "max_tokens") {
      emit({ type: "notice", text: "max_tokens" });
      break;
    }
    if (result.stop === "refusal") {
      emit({ type: "notice", text: "refusal" });
      break;
    }
    if (result.stop !== "tool_use" || !result.toolCalls.length) break;
    const results = await Promise.all(
      result.toolCalls.map(async (call) => {
        const tool = toolMap.get(call.name);
        const label = tool ? safeSummary(tool.summary, call, settings.language) : call.name;
        emit({ type: "tool_status", id: call.id, name: call.name, status: "running", summary: label });
        if (!tool) {
          emit({ type: "tool_status", id: call.id, name: call.name, status: "error", summary: label });
          return { id: call.id, name: call.name, content: `Error: unknown tool "${call.name}"`, isError: true };
        }
        const invalid = validateInput(tool.def.input_schema, call.input);
        if (invalid) {
          emit({ type: "tool_status", id: call.id, name: call.name, status: "error", summary: label });
          return {
            id: call.id,
            name: call.name,
            content: JSON.stringify({ INVALID_INPUT: invalid, received: safeJson(call.input) }),
            isError: true
          };
        }
        try {
          const content = await tool.run(call.input, ctx);
          const isError = content.startsWith("Error:");
          emit({ type: "tool_status", id: call.id, name: call.name, status: isError ? "error" : "done", summary: label });
          return { id: call.id, name: call.name, content, isError };
        } catch (err) {
          emit({ type: "tool_status", id: call.id, name: call.name, status: "error", summary: label });
          return { id: call.id, name: call.name, content: `Error: ${err instanceof Error ? err.message : String(err)}`, isError: true };
        }
      })
    );
    const toolMsg = { role: "tool", results };
    messages.push(toolMsg);
    appended.push(toolMsg);
    emit({ type: "tool", message: toolMsg });
  }
  return appended;
}
function safeSummary(fn, call, lang) {
  try {
    return fn(call.input ?? {}, lang);
  } catch {
    return call.name;
  }
}
function safeJson(x) {
  try {
    return JSON.stringify(x).slice(0, 2e3);
  } catch {
    return String(x);
  }
}
function trimHistory(history) {
  if (history.length <= MAX_HISTORY) return [...history];
  let start = history.length - MAX_HISTORY;
  while (start < history.length && history[start].role !== "user") start++;
  const kept = history.slice(start);
  return kept.map((m) => {
    if (m.role !== "assistant" || !Array.isArray(m.raw)) return m;
    const raw = m.raw.filter((b) => b?.type !== "thinking" && b?.type !== "redacted_thinking");
    return { ...m, raw };
  });
}

// src/background/index.ts
var youtube = new YouTube(loadSettings);
chrome.runtime.onInstalled.addListener((details) => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => void 0);
  if (details.reason === "install") chrome.runtime.openOptionsPage().catch(() => void 0);
  ensureAlarm();
});
chrome.runtime.onStartup.addListener(() => ensureAlarm());
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM) refreshCompetitors(youtube).catch(() => void 0);
});
async function getPageContext(tabId) {
  const id = tabId ?? await activeYouTubeTabId();
  if (id === null) return null;
  try {
    const res = await chrome.tabs.sendMessage(id, { type: "getPageContext" });
    return res ?? null;
  } catch {
    return null;
  }
}
async function activeYouTubeTabId() {
  const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const tab = tabs[0];
  if (tab?.id !== void 0 && tab.url && /^https:\/\/(www|studio)\.youtube\.com\//.test(tab.url)) return tab.id;
  return null;
}
function contextSummary(ctx, s) {
  if (!ctx) return null;
  const ru = s.language === "ru";
  switch (ctx.kind) {
    case "watch":
      return ctx.video ? `${ru ? "\u0412\u0438\u0434\u0435\u043E" : "Video"}: ${ctx.video.title}` : ru ? "\u0412\u0438\u0434\u0435\u043E (\u0434\u0430\u043D\u043D\u044B\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0430\u044E\u0442\u0441\u044F)" : "Video (loading data)";
    case "search":
      return `${ru ? "\u041F\u043E\u0438\u0441\u043A" : "Search"}: ${ctx.query ?? ""}`;
    case "channel":
      return `${ru ? "\u041A\u0430\u043D\u0430\u043B" : "Channel"}: ${ctx.channel?.name ?? ctx.channel?.handle ?? ""}`;
    case "home":
      return ru ? "\u0413\u043B\u0430\u0432\u043D\u0430\u044F YouTube" : "YouTube home";
    case "shorts":
      return ru ? "Shorts" : "Shorts";
    case "studio":
      return ctx.draft?.title ? `${ru ? "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A" : "Draft"}: ${ctx.draft.title}` : ru ? "YouTube Studio" : "YouTube Studio";
    default:
      return ctx.title || null;
  }
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const reply = (p) => {
    p.then(
      (r) => sendResponse(r ?? null),
      (err) => sendResponse({ error: err instanceof Error ? err.message : String(err) })
    );
    return true;
  };
  switch (msg.type) {
    case "openSidePanel": {
      const tabId = sender.tab?.id;
      if (tabId === void 0) return;
      return reply(openPanel(tabId, msg.action));
    }
    case "getChannelStats":
      return reply(youtube.channelStats(msg.channel, 25));
    case "snapshot":
    case "getRecentVph":
      return reply(recordSnapshot(msg.videoId, msg.views).then((vph) => ({ vph })));
    case "getSettings":
      return reply(loadSettings());
    case "nativePing":
      return reply(loadSettings().then((s) => nativePing(s.nativeHostName)));
    case "nativeWhich":
      return reply(loadSettings().then((s) => nativeWhich(s.nativeHostName, msg.name)));
    case "testProvider":
      return reply(testProvider());
    case "fetchModels":
      return reply(fetchModels(msg.baseUrl, msg.apiKey));
    case "analyzeKeyword":
      return reply(keywordReport(youtube, msg.query, msg.lang, 20));
    case "getVideoTags":
      return reply(videoTags(youtube, msg.videoIds));
    case "fetchImage":
      return reply(fetchImage(msg.url));
    case "tagRanks":
      return reply(youtube.tagRanks(msg.videoId, msg.tags));
    case "addCompetitor":
      return reply(addCompetitor(youtube, msg.channel));
    case "removeCompetitor":
      return reply(removeCompetitor(msg.key).then(() => ({ ok: true })));
    case "getCompetitors":
      return reply(getCompetitorsState());
    case "refreshCompetitors":
      return reply(refreshCompetitors(youtube));
    case "markAlertsSeen":
      return reply(markAlertsSeen().then(() => ({ ok: true })));
    case "studioInsert": {
      return reply(activeYouTubeTabId().then((id) => id === null ? { error: "No YouTube Studio tab is active" } : chrome.tabs.sendMessage(id, msg)));
    }
    case "pageContextSummary":
      return reply(Promise.all([getPageContext(msg.tabId), loadSettings()]).then(([ctx, s]) => ({ summary: contextSummary(ctx, s), kind: ctx?.kind ?? "other" })));
  }
  return void 0;
});
var pendingActions = /* @__PURE__ */ new Map();
async function openPanel(tabId, action) {
  if (action) pendingActions.set(tabId, action);
  const port = panelPorts.get(tabId);
  if (port && action) {
    pendingActions.delete(tabId);
    port.postMessage({ type: "run_action", action });
  }
  await chrome.sidePanel.open({ tabId });
}
async function fetchImage(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status} loading image`);
  const blob = await res.blob();
  const buf = new Uint8Array(await blob.arrayBuffer());
  let bin = "";
  for (let i = 0; i < buf.length; i += 32768) bin += String.fromCharCode(...buf.subarray(i, i + 32768));
  const mediaType = /^image\/(jpeg|png|webp|gif)$/.test(blob.type) ? blob.type : "image/jpeg";
  return { mediaType, data: btoa(bin) };
}
async function fetchModels(baseUrl, apiKey) {
  const base = baseUrl.trim().replace(/\/+$/, "");
  if (!/^https?:\/\//.test(base)) throw new Error("Base URL must start with http(s)://");
  const headers = {};
  if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
  let res;
  try {
    res = await fetch(`${base}/models`, { headers });
  } catch (err) {
    throw new Error(`Could not reach ${base}/models (${err instanceof Error ? err.message : String(err)}). Press "Grant access" first.`);
  }
  const text = await res.text();
  if (!res.ok) {
    let msg = text.slice(0, 300);
    try {
      msg = JSON.parse(text)?.error?.message ?? msg;
    } catch {
    }
    throw new Error(`HTTP ${res.status}: ${msg}`);
  }
  let json2 = {};
  try {
    json2 = JSON.parse(text);
  } catch {
    throw new Error("The /models endpoint did not return JSON \u2014 check the base URL (it should end with /v1).");
  }
  const list = (json2.data ?? json2.models ?? []).map((m) => m.id ?? m.name ?? "").filter(Boolean);
  return { models: [...new Set(list)].sort() };
}
async function testProvider() {
  try {
    const s = await loadSettings();
    const provider = createProvider(s);
    const r = await provider.run({
      system: "You are a connectivity test. Reply with the single word OK.",
      messages: [{ role: "user", content: "ping" }],
      tools: [],
      onText: () => void 0,
      signal: new AbortController().signal
    });
    return { ok: true, message: `${provider.model}: ${r.text.trim().slice(0, 80) || "(empty reply)"}` };
  } catch (err) {
    return { ok: false, message: err instanceof Error ? err.message : String(err) };
  }
}
var panelPorts = /* @__PURE__ */ new Map();
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "chat") return;
  let controller = null;
  let tabId = port.sender?.tab?.id ?? null;
  const send = (ev) => {
    try {
      port.postMessage(ev);
    } catch {
    }
  };
  port.onMessage.addListener(async (msg) => {
    if (msg.type === "hello") {
      tabId = msg.tabId ?? tabId;
      if (tabId !== null) panelPorts.set(tabId, port);
      const [ctx, s] = await Promise.all([getPageContext(tabId), loadSettings()]);
      send({ type: "context", summary: contextSummary(ctx, s), kind: ctx?.kind ?? "other" });
      if (tabId !== null && pendingActions.has(tabId)) {
        const action = pendingActions.get(tabId);
        pendingActions.delete(tabId);
        send({ type: "run_action", action });
      }
      return;
    }
    if (msg.type === "abort") {
      controller?.abort();
      return;
    }
    if (msg.type === "send") {
      if (controller) controller.abort();
      controller = new AbortController();
      const signal = controller.signal;
      try {
        const settings = await loadSettings();
        tabId = msg.tabId ?? tabId;
        let content = msg.text.trim();
        let display;
        if (msg.action) {
          content = actionPrompt(msg.action, settings.language) + (content ? `

User note: ${content}` : "");
          display = msg.text.trim() || void 0;
        }
        if (msg.includeContext) {
          const ctx = await getPageContext(tabId);
          content += `

${renderPageContext(ctx)}`;
          send({ type: "context", summary: contextSummary(ctx, settings), kind: ctx?.kind ?? "other" });
        }
        const userMsg = { role: "user", content, display: display ?? (msg.action ? actionLabel(msg.action, settings) : void 0), images: msg.images?.length ? msg.images : void 0 };
        send({ type: "user", message: userMsg });
        const history = [...msg.history, userMsg];
        await runAgent({
          settings,
          history,
          ctx: { tabId, youtube, getPageContext },
          signal,
          emit: send
        });
        send({ type: "done" });
      } catch (err) {
        if (signal.aborted) send({ type: "notice", text: "aborted" });
        else if (err instanceof ProviderError) send({ type: "error", text: err.message });
        else send({ type: "error", text: err instanceof Error ? err.message : String(err) });
        send({ type: "done" });
      } finally {
        controller = null;
      }
    }
  });
  port.onDisconnect.addListener(() => {
    controller?.abort();
    if (tabId !== null && panelPorts.get(tabId) === port) panelPorts.delete(tabId);
  });
});
function actionLabel(action, s) {
  const ru = s.language === "ru";
  const labels = {
    analyze_video: ["\u0410\u043D\u0430\u043B\u0438\u0437 \u0432\u0438\u0434\u0435\u043E", "Analyze video"],
    why_performing: ["\u041F\u043E\u0447\u0435\u043C\u0443 \u0442\u0430\u043A \u043D\u0430\u0431\u0438\u0440\u0430\u0435\u0442?", "Why is it performing?"],
    titles: ["\u0412\u0430\u0440\u0438\u0430\u043D\u0442\u044B \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0439", "Title ideas"],
    tags_description: ["\u0422\u0435\u0433\u0438 \u0438 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435", "Tags & description"],
    keyword_research: ["\u0410\u043D\u0430\u043B\u0438\u0437 \u0437\u0430\u043F\u0440\u043E\u0441\u0430", "Keyword research"],
    channel_review: ["\u0420\u0430\u0437\u0431\u043E\u0440 \u043A\u0430\u043D\u0430\u043B\u0430", "Channel review"],
    competitors: ["\u041A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442\u044B", "Competitors"],
    content_ideas: ["\u0418\u0434\u0435\u0438 \u0434\u043B\u044F \u0432\u0438\u0434\u0435\u043E", "Content ideas"],
    summarize: ["\u041A\u0440\u0430\u0442\u043A\u043E \u043E \u0447\u0451\u043C \u0432\u0438\u0434\u0435\u043E", "Summarize video"],
    studio_titles: ["\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u0434\u043B\u044F \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430", "Titles for the draft"],
    studio_description: ["\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0434\u043B\u044F \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430", "Description for the draft"],
    studio_tags: ["\u0422\u0435\u0433\u0438 \u0434\u043B\u044F \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430", "Tags for the draft"],
    studio_compare: ["\u0421\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u0441 \u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442\u0430\u043C\u0438", "Title vs competitors"],
    studio_magic_fill: ["\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0432\u0441\u0451", "Magic fill"],
    studio_thumbnail: ["\u041E\u0446\u0435\u043D\u043A\u0430 \u043F\u0440\u0435\u0432\u044C\u044E", "Thumbnail review"],
    daily_ideas: ["\u0418\u0434\u0435\u0438 \u0434\u043D\u044F", "Daily ideas"]
  };
  return labels[action][ru ? 0 : 1];
}
